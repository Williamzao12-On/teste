/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: "class",
  content: [
    "./src/pages/**/*.{js,jsx,ts,tsx}",
    "./src/components/**/*.{js,jsx,ts,tsx}",
    "./src/app/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        heading: ["var(--font-heading)", "sans-serif"],
        sans: ["var(--font-body)", "sans-serif"],
      },
      colors: {
        brand: {
          50: "#eef4ff",
          100: "#d9e6ff",
          400: "#6d9bff",
          500: "#4d7fff",
          600: "#3763e8",
          700: "#2c4fc2",
        },
        // Acento secundário — usado com moderação pra tirar o "tudo azul"
        accent: {
          400: "#f0a35e",
          500: "#e8873a",
          600: "#c96e26",
        },
        surface: {
          base: "#0a0e1a",
          raised: "#111827",
          overlay: "#1a2333",
          border: "#26324a",
        },
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      boxShadow: {
        glow: "0 0 0 1px rgba(77, 127, 255, 0.15), 0 8px 24px -8px rgba(77, 127, 255, 0.45)",
        "glow-accent": "0 0 0 1px rgba(232, 135, 58, 0.2), 0 8px 24px -8px rgba(232, 135, 58, 0.4)",
      },
      backgroundImage: {
        "brand-gradient": "linear-gradient(135deg, #4d7fff 0%, #7a5cf0 100%)",
      },
    },
  },
  plugins: [],
};
