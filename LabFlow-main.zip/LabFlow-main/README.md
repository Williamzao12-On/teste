# LabFlow

PWA para gestão de reservas de carrinhos de notebooks, laboratórios e outros recursos escolares da rede SEDUC/SP. O sistema atende administradores da rede, equipes gestoras e docentes, com isolamento de dados por escola, controle de permissões e fluxo de check-in/check-out.

Aplicação publicada: [labflow-sp.vercel.app](https://labflow-sp.vercel.app)

## Principais recursos

- Login institucional com Google, e-mail/senha e link mágico por e-mail.
- Dashboard adaptado ao papel do usuário: administrador, diretor, gestor escolar ou docente.
- Cadastro e gerenciamento de escolas, usuários, turmas, horários e recursos.
- Grade de reservas por data, turno, recurso e horário.
- Prevenção de conflitos de agenda diretamente no banco de dados.
- Controle individual de equipamentos de carrinhos e laboratórios.
- Check-in, check-out, cancelamento e registro de incidentes.
- Restrição de recursos exclusivos para docentes autorizados do curso de Desenvolvimento de Sistemas.
- Navegação responsiva para desktop e mobile, com suporte a PWA.

## Stack

- **Frontend:** Next.js 14 com App Router e React 18.
- **Estilos:** Tailwind CSS 3, tema escuro e componentes utilitários próprios.
- **Backend e autenticação:** Supabase Auth, PostgreSQL, Server Actions e Row Level Security (RLS).
- **PWA:** `next-pwa` e `public/manifest.json`.
- **Ícones e utilitários:** Lucide React, `clsx`, `tailwind-merge` e `date-fns`.
- **Runtime:** Node.js 18.18 ou superior.

## Estrutura do projeto

```text
public/
  manifest.json                 Configuração do PWA

src/
  app/
    layout.js                   Layout raiz, fontes, metadados e providers
    globals.css                 Estilos globais, tema e componentes visuais
    login/                      Tela de autenticação
    auth/                       Callback OAuth e definição de senha
    (dashboard)/                Área autenticada da aplicação
      layout.js                 Layout protegido com sidebar e navegação mobile
      page.js                   Dashboard por perfil de usuário
      reservas/                 Grade, modal e ações de reservas
      gestor/                   Recursos, horários, turmas e usuários
      incidentes/               Registro e acompanhamento de incidentes
      perfil/                   Dados e preferências do usuário
      admin/                    Administração da rede, escolas e convites
  components/                  Componentes visuais compartilhados
  lib/
    auth.js                     Leitura do perfil e controle de papéis
    roles.js                    Rótulos dos papéis de acesso
    etapas.js                   Rótulos das etapas/modalidades de ensino
    supabase/                   Clientes browser, server e admin do Supabase
    utils.js                    Utilitários compartilhados, incluindo cn()
  middleware.js                 Renovação da sessão e proteção das rotas

supabase/
  schema.sql                    Schema base, triggers, funções e políticas RLS
  migration_*.sql               Migrações incrementais do banco
  bootstrap_*.sql               Scripts auxiliares para inicialização/admin
  email_template_invite.html    Template de convite de usuário

tailwind.config.js              Tokens de cores, fontes, sombras e tema
next.config.js                  Configuração do Next.js e PWA
package.json                    Scripts e dependências
```

## Como funciona

O middleware mantém a sessão do Supabase atualizada e redireciona usuários não autenticados para `/login`. Depois da autenticação, `src/app/(dashboard)/layout.js` carrega o perfil atual e monta a experiência responsiva com `Sidebar` no desktop e `BottomNav` no mobile.

As páginas usam Server Components e Server Actions para consultar e alterar dados com o cliente Supabase de servidor. Os componentes interativos, como `ReservasGrid` e `RecursoCard`, cuidam da interação no navegador e chamam as ações do servidor. O PostgreSQL reforça as regras importantes com constraints, triggers e RLS, incluindo isolamento por `escola_id`, prevenção de reservas duplicadas e autorização para recursos exclusivos de DS.

## Configuração local

### 1. Pré-requisitos

- Node.js 18.18 ou superior.
- Um projeto Supabase no plano adequado ao ambiente.
- Git e npm.

### 2. Variáveis de ambiente

Crie `.env.local` na raiz do projeto:

```env
NEXT_PUBLIC_SUPABASE_URL=https://seu-projeto.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua-chave-anon-publica
NEXT_PUBLIC_SITE_URL=http://localhost:3000
SUPABASE_SERVICE_ROLE_KEY=sua-service-role-key
```

`SUPABASE_SERVICE_ROLE_KEY` é obrigatória apenas para operações administrativas, como convites. Ela é secreta: não deve ser publicada, commitada ou usada com o prefixo `NEXT_PUBLIC_`.

### 3. Banco de dados e autenticação

1. Crie um projeto no [Supabase](https://supabase.com).
2. Execute `supabase/schema.sql` no SQL Editor.
3. Execute as migrações `supabase/migration_*.sql` necessárias para o estado atual do projeto, em ordem numérica.
4. Habilite os provedores de autenticação desejados, como Google e e-mail.
5. Em **Authentication > URL Configuration**, configure:
   - `http://localhost:3000/auth/callback`
   - a URL de produção correspondente, por exemplo `https://labflow-sp.vercel.app/auth/callback`
6. Para criar o primeiro administrador, use os scripts `supabase/bootstrap_admin*.sql` ou associe manualmente o perfil a uma escola e ao papel `ADMIN`.

### 4. Instalação e execução

```bash
npm install
npm run dev
```

Abra [http://localhost:3000](http://localhost:3000).

### Scripts disponíveis

```bash
npm run dev       # servidor de desenvolvimento
npm run build     # build de produção
npm run start     # inicia o build de produção
npm run lint      # validação de lint
```

## Nota para o frontend: arquivos de layout

Para alterações **somente visuais ou de layout**, o frontend pode trabalhar principalmente nestes arquivos:

- `src/app/globals.css` — estilos globais, classes reutilizáveis (`panel`, `btn-primary`), tipografia, scrollbar e animações.
- `tailwind.config.js` — cores `brand`, `accent` e `surface`, fontes, sombras, gradientes e bordas do design system.
- `src/app/layout.js` — fontes, idioma, metadados, viewport, tema PWA e providers globais.
- `src/app/(dashboard)/layout.js` — largura do conteúdo, espaçamentos e composição geral da área autenticada.
- `src/components/Sidebar.jsx` — sidebar desktop, cabeçalho/drawer mobile e navegação lateral.
- `src/components/BottomNav.jsx` — navegação fixa inferior em telas mobile.
- `src/components/SectionHeader.jsx` — cabeçalhos de seção compartilhados.
- `src/components/ActionForm.jsx`, `src/components/ToastProvider.jsx` — padrões visuais e feedback compartilhado de formulários/notificações.
- Os componentes `page.js`, `*.jsx` e `RecursoCard.jsx` dentro de cada funcionalidade — layout específico daquela tela.
- `public/manifest.json` e `public/icons/` — nome, cores e ícones instaláveis do PWA.

Ao alterar uma tela específica, prefira editar as classes Tailwind e a marcação do componente correspondente. Evite alterar a lógica de autenticação, permissões ou dados sem necessidade.

### Arquivos que exigem cuidado

Não altere como parte de um ajuste visual, salvo se a mudança for intencional e revisada:

- `src/middleware.js`, `src/lib/auth.js` e `src/lib/supabase/*` — sessão, autenticação e acesso ao banco.
- `actions.js` e arquivos com Server Actions — regras de negócio e mutações.
- `supabase/*.sql` — schema, triggers, constraints e políticas RLS.
- Variáveis `SUPABASE_SERVICE_ROLE_KEY` — concedem acesso administrativo e ignoram o RLS.

## Regras de segurança e domínio

- Usuários comuns ficam limitados à escola associada ao seu perfil; `ADMIN` possui visão da rede.
- A constraint `unique_reserva_horario` impede que um recurso seja reservado duas vezes no mesmo dia e horário.
- O trigger `check_exclusividade_ds` bloqueia reservas de recursos exclusivos para usuários não autorizados.
- Incidentes podem colocar um recurso em manutenção parcial automaticamente.
- O controle de acesso no frontend não substitui as políticas RLS do banco.

## Próximos passos

- Evoluir relatórios e indicadores de utilização dos recursos.
- Aprimorar notificações de reservas, incidentes e convites.
- Consolidar o fluxo de deploy e as migrações Supabase em ambientes separados.
- Gerar e versionar os ícones finais do PWA em `public/icons/`.
