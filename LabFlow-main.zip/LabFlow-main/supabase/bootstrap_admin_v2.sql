-- =========================================================
-- LABFLOW — Bootstrap do ADMIN (usuário JÁ EXISTE em auth.users)
-- Troque 'SUA_SENHA_AQUI' antes de rodar.
-- =========================================================

do $$
declare
  target_email text := 'thomaz.camargo30@gmail.com';
  nova_senha text := 'SUA_SENHA_AQUI'; -- <<< TROQUE AQUI
  uid uuid;
begin
  select id into uid from auth.users where email = target_email;

  if uid is null then
    raise exception 'Usuário % não encontrado em auth.users', target_email;
  end if;

  -- Define/reseta a senha e garante que o e-mail está confirmado
  -- (necessário para o login por senha funcionar)
  update auth.users
  set
    encrypted_password = crypt(nova_senha, gen_salt('bf')),
    email_confirmed_at = coalesce(email_confirmed_at, now()),
    updated_at = now()
  where id = uid;

  -- Garante que existe uma identidade de e-mail (caso o cadastro
  -- anterior não tenha chegado a criar uma)
  insert into auth.identities (
    id, user_id, provider_id, identity_data, provider,
    last_sign_in_at, created_at, updated_at
  )
  select
    gen_random_uuid(), uid, uid::text,
    jsonb_build_object('sub', uid::text, 'email', target_email),
    'email', now(), now(), now()
  where not exists (
    select 1 from auth.identities where user_id = uid and provider = 'email'
  );

  -- Promove o profile já criado pelo trigger para ADMIN
  update public.profiles
  set role = 'ADMIN'
  where id = uid;
end $$;
