-- =========================================================
-- LABFLOW — MIGRAÇÃO 007: Adicionar 'MEDIO_TECNICO' às etapas de ensino
--
-- Executar no SQL Editor do Supabase.
-- Como o PostgreSQL não permite rodar ALTER TYPE ... ADD VALUE
-- dentro de um bloco transacional com comandos subsequentes que
-- utilizem o novo valor, execute esta instrução de forma isolada.
-- =========================================================

alter type public.etapa_ensino_enum add value if not exists 'MEDIO_TECNICO';

comment on type public.etapa_ensino_enum is
  'Etapas de ensino suportadas: FUNDAMENTAL_I, FUNDAMENTAL_II, MEDIO, MEDIO_TECNICO, TECNICO, EJA.';
