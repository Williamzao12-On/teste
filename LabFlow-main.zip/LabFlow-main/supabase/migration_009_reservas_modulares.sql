﻿-- Migration 009 — Suporte a reserva modular de itens (faixa ou seleção de notebooks)
-- Rodar no Supabase Dashboard → SQL Editor

ALTER TABLE public.reservas
  ADD COLUMN IF NOT EXISTS itens_reservados text[] DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS faixa_itens text DEFAULT NULL;

COMMENT ON COLUMN public.reservas.itens_reservados IS 'Lista de patrimônios dos equipamentos específicos reservados (ex: Notebook 01 a 15)';
COMMENT ON COLUMN public.reservas.faixa_itens IS 'Resumo legível dos equipamentos reservados (ex: "Notebook 01 a 15 (15 unid.)")';