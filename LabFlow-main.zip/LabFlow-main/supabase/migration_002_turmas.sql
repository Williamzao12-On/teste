-- =========================================================
-- LABFLOW — MIGRAÇÃO 002: Séries/Turmas
-- Rode DEPOIS do schema.sql original, no SQL Editor do Supabase
-- =========================================================

-- ENUM de etapa de ensino (ajuste conforme a realidade da sua rede)
create type etapa_ensino_enum as enum (
  'FUNDAMENTAL_I',
  'FUNDAMENTAL_II',
  'MEDIO',
  'TECNICO',
  'EJA'
);

-- =========================================================
-- Tabela: turmas (as "séries" cadastráveis pelo Diretor/Gestor)
-- =========================================================

create table public.turmas (
  id uuid primary key default gen_random_uuid(),
  escola_id uuid not null references public.escolas (id) on delete cascade,
  ano_letivo smallint not null default extract(year from now()),
  etapa etapa_ensino_enum not null,
  serie text not null,             -- ex: "6º Ano", "3ª Série", "Módulo 3"
  identificador text not null,     -- ex: "A", "B", "Único"
  turno turno_enum not null,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),

  constraint unique_turma_por_ano unique (escola_id, ano_letivo, etapa, serie, identificador)
);

comment on table public.turmas is 'Séries/turmas cadastradas por ano letivo. Recriada/ajustada anualmente pelo Diretor — é o "destino" de uma reserva, não um recurso físico.';

create index idx_turmas_escola_ano on public.turmas (escola_id, ano_letivo);

alter table public.turmas enable row level security;

create policy "Ver turmas da própria escola"
  on public.turmas for select
  to authenticated
  using (escola_id = public.get_my_escola_id() or public.is_admin());

create policy "Gestores gerenciam turmas da própria escola"
  on public.turmas for all
  to authenticated
  using (
    (public.is_gestor_ou_diretor() and escola_id = public.get_my_escola_id())
    or public.is_admin()
  )
  with check (
    (public.is_gestor_ou_diretor() and escola_id = public.get_my_escola_id())
    or public.is_admin()
  );

-- =========================================================
-- Ajuste em reservas: troca campo texto livre por FK para turmas
-- =========================================================

-- 1. Adiciona a nova coluna (nullable por enquanto, para não quebrar dados existentes)
alter table public.reservas
  add column turma_id uuid references public.turmas (id) on delete restrict;

-- 2. Se você JÁ TEM reservas em produção com o campo "turma" (texto),
--    faça a migração de dados manualmente aqui antes do passo 3, por exemplo:
--
--    insert into public.turmas (escola_id, ano_letivo, etapa, serie, identificador, turno)
--    select distinct escola_id, extract(year from data_reserva)::smallint,
--           'FUNDAMENTAL_II', turma, 'A', 'MANHA'
--    from public.reservas
--    on conflict do nothing;
--
--    update public.reservas r
--    set turma_id = t.id
--    from public.turmas t
--    where t.escola_id = r.escola_id and t.serie = r.turma;
--
--    (Ajuste essa lógica conforme o formato real dos dados de "turma" já salvos.)

-- 3. Depois de confirmar que todo mundo tem turma_id preenchido, torne obrigatório
--    e remova a coluna antiga:
--
--    alter table public.reservas alter column turma_id set not null;
--    alter table public.reservas drop column turma;

-- Se este é um banco NOVO (ainda sem dados de reserva), pode rodar direto:
alter table public.reservas alter column turma_id set not null;
alter table public.reservas drop column turma;

create index idx_reservas_turma on public.reservas (turma_id);
