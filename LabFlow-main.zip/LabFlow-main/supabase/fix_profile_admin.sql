-- =========================================================
-- LABFLOW — Diagnóstico + correção do profile do ADMIN
-- =========================================================

do $$
declare
  target_email text := 'thomaz.camargo30@gmail.com';
  uid uuid;
begin
  select id into uid from auth.users where email = target_email;

  if uid is null then
    raise exception 'Usuário % não existe em auth.users.', target_email;
  end if;

  insert into public.profiles (id, email, nome_completo, role)
  values (uid, target_email, 'Thomaz Camargo', 'ADMIN')
  on conflict (id) do update set role = 'ADMIN';
end $$;

-- Conferência: rode isto separado pra ver o resultado
select
  u.id,
  u.email,
  (u.email_confirmed_at is not null) as email_confirmado,
  (u.encrypted_password is not null) as tem_senha,
  p.role,
  p.escola_id
from auth.users u
left join public.profiles p on p.id = u.id
where u.email = 'thomaz.camargo30@gmail.com';
