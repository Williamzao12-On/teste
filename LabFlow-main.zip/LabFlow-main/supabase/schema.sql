-- =========================================================
-- LABFLOW — SCHEMA COMPLETO (Supabase / PostgreSQL)
-- Fase 1: Estrutura, Enums, Triggers, RLS
-- Rode este script inteiro no SQL Editor do Supabase
-- =========================================================

-- Extensões necessárias
create extension if not exists "pgcrypto"; -- gen_random_uuid()

-- =========================================================
-- 1. ENUMS
-- =========================================================

create type turno_enum as enum ('MANHA', 'TARDE', 'NOITE', 'INTEGRAL');

create type recurso_tipo_enum as enum (
  'CARRINHO_NOTEBOOK',
  'LABORATORIO_INFORMATICA',
  'TABLET',
  'CHROMEBOOK',
  'OUTRO'
);

create type recurso_status_enum as enum (
  'DISPONIVEL',
  'MANUTENCAO_PARCIAL',
  'MANUTENCAO_TOTAL',
  'INATIVO'
);

create type reserva_status_enum as enum (
  'RESERVADO',
  'EM_USO',
  'CONCLUIDO',
  'CANCELADO',
  'NAO_COMPARECEU'
);

create type profile_role_enum as enum (
  'ADMIN',        -- gestor de TI / suporte, acesso multi-escola
  'DIRETOR',
  'GESTOR_ESCOLAR',
  'DOCENTE',
  'DOCENTE_DS'    -- Professor do curso técnico de Desenvolvimento de Sistemas
);

create type chamado_status_enum as enum ('ABERTO', 'EM_ANDAMENTO', 'RESOLVIDO', 'CANCELADO');

-- =========================================================
-- 2. TABELA: escolas
-- =========================================================

create table public.escolas (
  id uuid primary key default gen_random_uuid(),
  nome text not null,
  codigo_inep text unique,
  diretoria_ensino text,
  endereco text,
  ativo boolean not null default true,
  created_at timestamptz not null default now()
);

comment on table public.escolas is 'Escolas da rede SEDUC/SP que utilizam o LabFlow';

-- =========================================================
-- 3. TABELA: profiles (espelha auth.users)
-- =========================================================

create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  escola_id uuid references public.escolas (id) on delete set null,
  nome_completo text,
  email text not null,
  avatar_url text,
  role profile_role_enum not null default 'DOCENTE',
  is_ds_authorized boolean not null default false,
  ativo boolean not null default true,
  created_at timestamptz not null default now()
);

comment on table public.profiles is 'Perfis de usuário, 1:1 com auth.users. Role define permissões e escola_id define o escopo multi-tenant.';

-- Trigger: cria profile automaticamente quando um usuário se cadastra
-- (Google OAuth ou E-mail/OTP)
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, nome_completo, avatar_url)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', new.email),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- =========================================================
-- 4. TABELA: grade_horarios
-- =========================================================

create table public.grade_horarios (
  id uuid primary key default gen_random_uuid(),
  escola_id uuid not null references public.escolas (id) on delete cascade,
  turno turno_enum not null,
  ordem smallint not null,          -- 1ª aula, 2ª aula, etc.
  label text not null,              -- ex: "1ª Aula", "Intervalo"
  hora_inicio time not null,
  hora_fim time not null,
  is_intervalo boolean not null default false,
  ativo boolean not null default true,
  created_at timestamptz not null default now(),
  constraint unique_ordem_turno_escola unique (escola_id, turno, ordem)
);

comment on table public.grade_horarios is 'Grade de horários modular por escola/turno, usada para as reservas.';

-- =========================================================
-- 5. TABELA: recursos (carrinhos, laboratórios, etc.)
-- =========================================================

create table public.recursos (
  id uuid primary key default gen_random_uuid(),
  escola_id uuid not null references public.escolas (id) on delete cascade,
  tipo recurso_tipo_enum not null,
  nome text not null,               -- ex: "Carrinho Notebook 01"
  descricao text,
  quantidade_itens integer not null default 1, -- nº de notebooks no carrinho, por ex.
  localizacao text,
  exclusivo_ds boolean not null default false, -- trava de exclusividade DS
  status recurso_status_enum not null default 'DISPONIVEL',
  created_at timestamptz not null default now()
);

comment on table public.recursos is 'Ativos reserváveis: carrinhos de notebook, laboratórios, tablets etc.';

-- =========================================================
-- 6. TABELA: reservas
-- =========================================================

create table public.reservas (
  id uuid primary key default gen_random_uuid(),
  escola_id uuid not null references public.escolas (id) on delete cascade,
  recurso_id uuid not null references public.recursos (id) on delete cascade,
  horario_id uuid not null references public.grade_horarios (id) on delete restrict,
  professor_id uuid not null references public.profiles (id) on delete restrict,
  professor_substituto_id uuid references public.profiles (id) on delete set null,
  is_substituicao boolean not null default false,
  data_reserva date not null,
  turma text not null,
  disciplina text,
  status reserva_status_enum not null default 'RESERVADO',
  checkin_at timestamptz,
  checkout_at timestamptz,
  observacoes text,
  created_at timestamptz not null default now(),

  -- TRAVA DE DUPLICIDADE: um recurso não pode ser reservado duas vezes
  -- no mesmo dia e mesmo horário
  constraint unique_reserva_horario unique (recurso_id, data_reserva, horario_id)
);

comment on table public.reservas is 'Reservas de recursos por horário/dia. Constraint unique_reserva_horario evita choque de agenda.';

create index idx_reservas_escola_data on public.reservas (escola_id, data_reserva);
create index idx_reservas_professor on public.reservas (professor_id);

-- Trigger: valida a trava de exclusividade DS antes de inserir/atualizar reserva
create or replace function public.check_exclusividade_ds()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  v_exclusivo_ds boolean;
  v_prof_autorizado boolean;
  v_prof_role profile_role_enum;
begin
  select exclusivo_ds into v_exclusivo_ds
  from public.recursos where id = new.recurso_id;

  if v_exclusivo_ds then
    select is_ds_authorized, role into v_prof_autorizado, v_prof_role
    from public.profiles where id = new.professor_id;

    if not (coalesce(v_prof_autorizado, false) or v_prof_role = 'DOCENTE_DS') then
      raise exception 'Este recurso é exclusivo para o curso de Desenvolvimento de Sistemas.';
    end if;
  end if;

  return new;
end;
$$;

create trigger trg_check_exclusividade_ds
  before insert or update on public.reservas
  for each row execute function public.check_exclusividade_ds();

-- =========================================================
-- 7. TABELA: incidentes (reporte de zelo/checkout)
-- =========================================================

create table public.incidentes (
  id uuid primary key default gen_random_uuid(),
  reserva_id uuid references public.reservas (id) on delete set null,
  recurso_id uuid not null references public.recursos (id) on delete cascade,
  numero_equipamento text not null,  -- ex: patrimônio do notebook nº 07
  descricao text not null,
  reportado_por uuid not null references public.profiles (id),
  resolvido boolean not null default false,
  created_at timestamptz not null default now()
);

comment on table public.incidentes is 'Defeitos/quebras reportados no checkout de zelo. Dispara trigger que altera status do recurso.';

-- Trigger: ao inserir incidente, muda o status do recurso para MANUTENCAO_PARCIAL
create or replace function public.handle_new_incidente()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  update public.recursos
  set status = 'MANUTENCAO_PARCIAL'
  where id = new.recurso_id
    and status = 'DISPONIVEL'; -- não rebaixa quem já está em manutenção total

  return new;
end;
$$;

create trigger trg_new_incidente
  after insert on public.incidentes
  for each row execute function public.handle_new_incidente();

-- =========================================================
-- 8. TABELA: chamados_sala (chamados gerais de infraestrutura)
-- =========================================================

create table public.chamados_sala (
  id uuid primary key default gen_random_uuid(),
  escola_id uuid not null references public.escolas (id) on delete cascade,
  sala text not null,
  tipo_problema text not null,
  descricao text,
  status chamado_status_enum not null default 'ABERTO',
  aberto_por uuid not null references public.profiles (id),
  resolvido_por uuid references public.profiles (id),
  resolvido_at timestamptz,
  created_at timestamptz not null default now()
);

comment on table public.chamados_sala is 'Chamados de manutenção/infraestrutura não necessariamente ligados a um recurso reservável.';

-- =========================================================
-- 9. FUNÇÕES AUXILIARES PARA RLS
-- =========================================================

create or replace function public.get_my_escola_id()
returns uuid
language sql stable
security definer set search_path = public
as $$
  select escola_id from public.profiles where id = auth.uid();
$$;

create or replace function public.get_my_role()
returns profile_role_enum
language sql stable
security definer set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_admin()
returns boolean
language sql stable
security definer set search_path = public
as $$
  select coalesce((select role from public.profiles where id = auth.uid()) = 'ADMIN', false);
$$;

create or replace function public.is_gestor_ou_diretor()
returns boolean
language sql stable
security definer set search_path = public
as $$
  select coalesce(
    (select role from public.profiles where id = auth.uid()) in ('ADMIN', 'DIRETOR', 'GESTOR_ESCOLAR'),
    false
  );
$$;

-- =========================================================
-- 10. ROW LEVEL SECURITY (RLS)
-- =========================================================

alter table public.escolas enable row level security;
alter table public.profiles enable row level security;
alter table public.grade_horarios enable row level security;
alter table public.recursos enable row level security;
alter table public.reservas enable row level security;
alter table public.incidentes enable row level security;
alter table public.chamados_sala enable row level security;

-- ---------- escolas ----------
create policy "Usuários autenticados podem ver escolas"
  on public.escolas for select
  to authenticated
  using (true); -- necessário para telas de seleção de escola / cadastro

create policy "Somente admin gerencia escolas"
  on public.escolas for all
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- ---------- profiles ----------
create policy "Usuário vê o próprio perfil"
  on public.profiles for select
  to authenticated
  using (id = auth.uid());

create policy "Gestores veem perfis da própria escola"
  on public.profiles for select
  to authenticated
  using (
    public.is_gestor_ou_diretor()
    and escola_id = public.get_my_escola_id()
  );

create policy "Usuário atualiza o próprio perfil"
  on public.profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

create policy "Admin gerencia todos os perfis"
  on public.profiles for all
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- ---------- grade_horarios ----------
create policy "Ver grade da própria escola"
  on public.grade_horarios for select
  to authenticated
  using (escola_id = public.get_my_escola_id() or public.is_admin());

create policy "Gestores gerenciam grade da própria escola"
  on public.grade_horarios for all
  to authenticated
  using (
    (public.is_gestor_ou_diretor() and escola_id = public.get_my_escola_id())
    or public.is_admin()
  )
  with check (
    (public.is_gestor_ou_diretor() and escola_id = public.get_my_escola_id())
    or public.is_admin()
  );

-- ---------- recursos ----------
create policy "Ver recursos da própria escola"
  on public.recursos for select
  to authenticated
  using (escola_id = public.get_my_escola_id() or public.is_admin());

create policy "Gestores gerenciam recursos da própria escola"
  on public.recursos for all
  to authenticated
  using (
    (public.is_gestor_ou_diretor() and escola_id = public.get_my_escola_id())
    or public.is_admin()
  )
  with check (
    (public.is_gestor_ou_diretor() and escola_id = public.get_my_escola_id())
    or public.is_admin()
  );

-- ---------- reservas ----------
create policy "Ver reservas da própria escola"
  on public.reservas for select
  to authenticated
  using (escola_id = public.get_my_escola_id() or public.is_admin());

create policy "Docente cria reserva na própria escola"
  on public.reservas for insert
  to authenticated
  with check (
    escola_id = public.get_my_escola_id()
    and professor_id = auth.uid()
  );

create policy "Docente atualiza/cancela a própria reserva"
  on public.reservas for update
  to authenticated
  using (
    professor_id = auth.uid()
    or professor_substituto_id = auth.uid()
    or (public.is_gestor_ou_diretor() and escola_id = public.get_my_escola_id())
    or public.is_admin()
  )
  with check (
    escola_id = public.get_my_escola_id() or public.is_admin()
  );

create policy "Gestor exclui reservas da própria escola"
  on public.reservas for delete
  to authenticated
  using (
    (public.is_gestor_ou_diretor() and escola_id = public.get_my_escola_id())
    or public.is_admin()
  );

-- ---------- incidentes ----------
create policy "Ver incidentes da própria escola"
  on public.incidentes for select
  to authenticated
  using (
    exists (
      select 1 from public.recursos r
      where r.id = incidentes.recurso_id
        and (r.escola_id = public.get_my_escola_id() or public.is_admin())
    )
  );

create policy "Usuário reporta incidente"
  on public.incidentes for insert
  to authenticated
  with check (reportado_por = auth.uid());

create policy "Gestor resolve incidentes da própria escola"
  on public.incidentes for update
  to authenticated
  using (
    public.is_gestor_ou_diretor()
    and exists (
      select 1 from public.recursos r
      where r.id = incidentes.recurso_id and r.escola_id = public.get_my_escola_id()
    )
  );

-- ---------- chamados_sala ----------
create policy "Ver chamados da própria escola"
  on public.chamados_sala for select
  to authenticated
  using (escola_id = public.get_my_escola_id() or public.is_admin());

create policy "Usuário abre chamado na própria escola"
  on public.chamados_sala for insert
  to authenticated
  with check (
    escola_id = public.get_my_escola_id()
    and aberto_por = auth.uid()
  );

create policy "Gestor gerencia chamados da própria escola"
  on public.chamados_sala for update
  to authenticated
  using (
    (public.is_gestor_ou_diretor() and escola_id = public.get_my_escola_id())
    or public.is_admin()
  );

-- =========================================================
-- FIM DO SCRIPT
-- =========================================================
