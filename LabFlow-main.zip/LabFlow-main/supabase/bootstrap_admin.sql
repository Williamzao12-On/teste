-- =========================================================
-- LABFLOW — Bootstrap do primeiro usuário ADMIN via SQL
-- Rode no SQL Editor do Supabase.
-- Troque 'SUA_SENHA_AQUI' por uma senha forte antes de rodar.
-- =========================================================

do $$
declare
  new_user_id uuid := gen_random_uuid();
  novo_email text := 'thomaz.camargo30@gmail.com';
  nova_senha text := 'SUA_SENHA_AQUI'; -- <<< TROQUE AQUI
begin
  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password,
    email_confirmed_at, created_at, updated_at,
    raw_app_meta_data, raw_user_meta_data,
    confirmation_token, recovery_token
  ) values (
    '00000000-0000-0000-0000-000000000000',
    new_user_id,
    'authenticated',
    'authenticated',
    novo_email,
    crypt(nova_senha, gen_salt('bf')),
    now(), now(), now(),
    '{"provider":"email","providers":["email"]}'::jsonb,
    '{"full_name":"Thomaz Camargo"}'::jsonb,
    '', ''
  );

  insert into auth.identities (
    id, user_id, provider_id, identity_data, provider,
    last_sign_in_at, created_at, updated_at
  ) values (
    gen_random_uuid(),
    new_user_id,
    new_user_id::text,
    jsonb_build_object('sub', new_user_id::text, 'email', novo_email),
    'email',
    now(), now(), now()
  );

  -- O trigger on_auth_user_created já criou a linha em public.profiles
  -- automaticamente. Agora só promovemos para ADMIN.
  update public.profiles
  set role = 'ADMIN', nome_completo = 'Thomaz Camargo'
  where id = new_user_id;
end $$;
