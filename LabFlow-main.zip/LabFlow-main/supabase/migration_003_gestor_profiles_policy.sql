-- =========================================================
-- LABFLOW — MIGRAÇÃO 003: Gestor pode atualizar perfis da própria escola
-- =========================================================

create policy "Gestor atualiza perfis da própria escola (exceto para ADMIN)"
  on public.profiles for update
  to authenticated
  using (
    public.is_gestor_ou_diretor()
    and escola_id = public.get_my_escola_id()
  )
  with check (
    escola_id = public.get_my_escola_id()
    and role <> 'ADMIN'
  );
