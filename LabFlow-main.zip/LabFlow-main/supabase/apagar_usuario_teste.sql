-- Apaga o usuário de teste por completo (auth.users + profiles via cascade)
delete from auth.users where email = 'EMAIL_DO_DIRETOR_DE_TESTE_AQUI';
