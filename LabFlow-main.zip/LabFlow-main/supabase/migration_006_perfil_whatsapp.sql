-- =========================================================
-- LABFLOW — MIGRAÇÃO 006: telefone/WhatsApp no perfil
-- Preparação para notificações futuras (WhatsApp ou in-app —
-- decisão de canal ainda em aberto, isso só guarda o contato).
-- =========================================================

alter table public.profiles
  add column if not exists telefone_whatsapp text;

comment on column public.profiles.telefone_whatsapp is
  'Número de WhatsApp do usuário, informado por ele mesmo, para uso futuro em notificações.';
