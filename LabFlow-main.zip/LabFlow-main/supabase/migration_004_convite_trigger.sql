-- =========================================================
-- LABFLOW — MIGRAÇÃO 004: trigger aceita escola_id/role do convite
-- =========================================================

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  meta_escola_id uuid;
  meta_role public.profile_role_enum;
begin
  -- Os campos abaixo só existem quando o usuário foi criado via convite do
  -- ADMIN (auth.admin.inviteUserByEmail com "data: { escola_id, role }").
  -- Em qualquer outro fluxo (Google, magic link comum), ficam nulos e caem
  -- nos valores padrão da tabela profiles.
  begin
    meta_escola_id := (new.raw_user_meta_data->>'escola_id')::uuid;
  exception when others then
    meta_escola_id := null;
  end;

  begin
    meta_role := (new.raw_user_meta_data->>'role')::public.profile_role_enum;
  exception when others then
    meta_role := null;
  end;

  insert into public.profiles (id, email, nome_completo, avatar_url, escola_id, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', new.email),
    new.raw_user_meta_data->>'avatar_url',
    meta_escola_id,
    coalesce(meta_role, 'DOCENTE')
  )
  on conflict (id) do nothing;

  return new;
end;
$$;
