-- =========================================================
-- LABFLOW — MIGRAÇÃO 005: modalidades de ensino por escola
--
-- Usa o etapa_ensino_enum que já existe desde a migration_002
-- (FUNDAMENTAL_I, FUNDAMENTAL_II, MEDIO, TECNICO, EJA) — não precisa
-- alterar o enum, só adicionar a coluna em escolas.
-- =========================================================

alter table public.escolas
  add column if not exists modalidades_ensino etapa_ensino_enum[] not null default '{}';

comment on column public.escolas.modalidades_ensino is
  'Quais etapas de ensino a escola oferece (pode ter mais de uma: ex. Fundamental I + II, ou também EJA à noite). Controlado pelo ADMIN; usado para restringir as opções que o Gestor vê ao cadastrar turmas.';
