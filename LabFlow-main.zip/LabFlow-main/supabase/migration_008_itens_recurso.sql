﻿-- Migration 008 — Itens individuais de recurso (notebooks por patrimônio)
-- Rodar no Supabase Dashboard → SQL Editor

-- 1. Tabela de itens individuais dentro de um recurso
CREATE TABLE IF NOT EXISTS public.itens_recurso (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recurso_id         uuid NOT NULL REFERENCES public.recursos(id) ON DELETE CASCADE,
  numero_patrimonio  text NOT NULL,
  descricao          text,
  status             public.recurso_status_enum NOT NULL DEFAULT 'DISPONIVEL',
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT unique_item_por_recurso UNIQUE (recurso_id, numero_patrimonio)
);

-- 2. Trigger de updated_at
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_itens_recurso_updated_at
  BEFORE UPDATE ON public.itens_recurso
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- 3. RLS
ALTER TABLE public.itens_recurso ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Leitura itens da escola"
  ON public.itens_recurso FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.recursos r
      WHERE r.id = itens_recurso.recurso_id
        AND r.escola_id = public.get_my_escola_id()
    )
  );

CREATE POLICY "Gestores escrevem itens"
  ON public.itens_recurso FOR ALL
  TO authenticated
  USING (
    public.is_gestor_ou_diretor() AND EXISTS (
      SELECT 1 FROM public.recursos r
      WHERE r.id = itens_recurso.recurso_id
        AND r.escola_id = public.get_my_escola_id()
    )
  )
  WITH CHECK (
    public.is_gestor_ou_diretor() AND EXISTS (
      SELECT 1 FROM public.recursos r
      WHERE r.id = itens_recurso.recurso_id
        AND r.escola_id = public.get_my_escola_id()
    )
  );

CREATE POLICY "Admin total itens"
  ON public.itens_recurso FOR ALL
  TO authenticated
  USING (public.is_admin())
  WITH CHECK (public.is_admin());

-- 4. Trigger: ao inserir incidente, marca item como avariado
CREATE OR REPLACE FUNCTION public.marcar_item_avariado()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  UPDATE public.itens_recurso
    SET status = 'MANUTENCAO_PARCIAL'
  WHERE recurso_id = NEW.recurso_id
    AND numero_patrimonio = NEW.numero_equipamento
    AND status = 'DISPONIVEL';
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_incidente_marca_item
  AFTER INSERT ON public.incidentes
  FOR EACH ROW EXECUTE FUNCTION public.marcar_item_avariado();

-- 5. Trigger: ao resolver incidente, restaura o item
CREATE OR REPLACE FUNCTION public.restaurar_item_resolvido()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF NEW.resolvido = true AND OLD.resolvido = false THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.incidentes
      WHERE recurso_id = NEW.recurso_id
        AND numero_equipamento = NEW.numero_equipamento
        AND resolvido = false
        AND id <> NEW.id
    ) THEN
      UPDATE public.itens_recurso
        SET status = 'DISPONIVEL'
      WHERE recurso_id = NEW.recurso_id
        AND numero_patrimonio = NEW.numero_equipamento;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_incidente_restaura_item
  AFTER UPDATE ON public.incidentes
  FOR EACH ROW EXECUTE FUNCTION public.restaurar_item_resolvido();