"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Lock, LayoutGrid, Loader2, AlertTriangle, CheckCircle2 } from "lucide-react";

export default function DefinirSenhaPage() {
  const router = useRouter();
  const supabase = createClient();

  const [checandoSessao, setChecandoSessao] = useState(true);
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [sucesso, setSucesso] = useState(false);

  // Essa tela só faz sentido pra quem já tem uma sessão ativa (veio do
  // callback de convite/recuperação). Sem sessão, não tem o que definir.
  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) {
        router.replace("/login");
        return;
      }
      setEmail(user.email || "");
      setChecandoSessao(false);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleSubmit(e) {
    e.preventDefault();
    setErrorMsg("");

    if (senha.length < 6) {
      setErrorMsg("A senha precisa ter pelo menos 6 caracteres.");
      return;
    }
    if (senha !== confirmarSenha) {
      setErrorMsg("As senhas não coincidem.");
      return;
    }

    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: senha });
    setLoading(false);

    if (error) {
      setErrorMsg(error.message);
      return;
    }

    setSucesso(true);
    setTimeout(() => router.replace("/"), 1200);
  }

  if (checandoSessao) {
    return (
      <main className="flex min-h-screen flex-col items-center justify-center px-4">
        <Loader2 className="h-6 w-6 animate-spin text-brand-500" />
      </main>
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-gradient text-white shadow-glow">
            <LayoutGrid className="h-7 w-7" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Bem-vindo(a) ao LabFlow</h1>
            <p className="mt-1 text-sm text-slate-400">
              Crie uma senha para <span className="font-medium text-slate-200">{email}</span>
            </p>
          </div>
        </div>

        <div className="panel">
          {sucesso ? (
            <div className="flex flex-col items-center gap-3 py-4 text-center">
              <CheckCircle2 className="h-8 w-8 text-green-400" />
              <p className="text-sm text-slate-200">Senha criada! Redirecionando…</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              {errorMsg && (
                <p className="flex items-start gap-2 rounded-lg bg-red-950/40 px-3 py-2 text-sm text-red-400">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                  {errorMsg}
                </p>
              )}

              <FieldSenha
                label="Nova senha"
                value={senha}
                onChange={setSenha}
                autoFocus
              />
              <FieldSenha
                label="Confirmar senha"
                value={confirmarSenha}
                onChange={setConfirmarSenha}
              />

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full py-3"
              >
                {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Criar senha e entrar"}
              </button>

              <p className="text-center text-xs text-slate-500">
                Você vai usar essa senha (junto com seu e-mail) pra entrar da próxima vez,
                sem precisar de um novo link.
              </p>
            </form>
          )}
        </div>
      </div>
    </main>
  );
}

function FieldSenha({ label, value, onChange, autoFocus }) {
  return (
    <label className="block text-sm">
      <span className="mb-1.5 block font-medium text-slate-300">{label}</span>
      <div className="relative">
        <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        <input
          type="password"
          required
          minLength={6}
          autoFocus={autoFocus}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="••••••••"
          className="w-full rounded-xl border border-surface-border bg-surface-overlay py-3 pl-10 pr-4 text-sm text-white outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4"
        />
      </div>
    </label>
  );
}
