"use client";

import { useEffect, useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Loader2, AlertTriangle, LayoutGrid } from "lucide-react";

export default function AuthCallbackPage() {
  return (
    <Suspense fallback={<Shell><Loader2 className="h-6 w-6 animate-spin text-brand-500" /></Shell>}>
      <CallbackHandler />
    </Suspense>
  );
}

function CallbackHandler() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [error, setError] = useState(null);

  useEffect(() => {
    let cancelled = false;
    const supabase = createClient();

    async function run() {
      // 1) Erro explícito devolvido pelo Supabase (ex: link expirado/já usado)
      const authError = searchParams.get("error_description") || searchParams.get("error");
      if (authError) {
        if (!cancelled) setError(decodeURIComponent(authError.replace(/\+/g, " ")));
        return;
      }

      // 2) Checa se o client Supabase já consumiu a sessão automaticamente via detectSessionInUrl
      const { data: initialSessionData } = await supabase.auth.getSession();
      if (initialSessionData?.session) {
        if (cancelled) return;
        const hash = window.location.hash?.startsWith("#") ? window.location.hash.slice(1) : "";
        const hashParams = new URLSearchParams(hash);
        const type = hashParams.get("type");
        if (type === "invite" || type === "recovery") {
          window.location.replace("/auth/definir-senha");
        } else {
          window.location.replace(searchParams.get("next") || "/");
        }
        return;
      }

      // 3) Fluxo PKCE (?code=...) — Google OAuth e Magic Link "self-serve"
      const code = searchParams.get("code");
      if (code) {
        const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code);
        if (cancelled) return;

        if (exchangeError) {
          // Em caso de race-condition (o client já consumiu o token antes dessa chamada),
          // confere se a sessão foi gravada com sucesso.
          const { data: retrySession } = await supabase.auth.getSession();
          if (retrySession?.session) {
            window.location.replace(searchParams.get("next") || "/");
            return;
          }
          setError(exchangeError.message);
        } else {
          window.location.replace(searchParams.get("next") || "/");
        }
        return;
      }

      // 4) Fluxo implícito (#access_token=...) — convites e links gerados pelo Admin
      const hash = window.location.hash?.startsWith("#") ? window.location.hash.slice(1) : "";
      const hashParams = new URLSearchParams(hash);
      const access_token = hashParams.get("access_token");
      const refresh_token = hashParams.get("refresh_token");
      const hashErrorDesc = hashParams.get("error_description");

      if (hashErrorDesc) {
        if (!cancelled) setError(decodeURIComponent(hashErrorDesc.replace(/\+/g, " ")));
        return;
      }

      if (access_token && refresh_token) {
        const { error: sessionError } = await supabase.auth.setSession({
          access_token,
          refresh_token,
        });
        if (cancelled) return;
        if (sessionError) {
          setError(sessionError.message);
          return;
        }

        const type = hashParams.get("type");
        if (type === "invite" || type === "recovery") {
          window.location.replace("/auth/definir-senha");
        } else {
          window.location.replace("/");
        }
        return;
      }

      if (!cancelled) {
        setError("Nenhum código de autenticação recebido. O link pode ter expirado ou já ter sido usado.");
      }
    }

    run();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (error) {
    return (
      <Shell>
        <AlertTriangle className="h-8 w-8 text-red-400" />
        <p className="mt-3 max-w-sm text-center text-sm text-slate-300">{error}</p>
        <a
          href="/login"
          className="mt-5 btn-primary"
        >
          Voltar para o login
        </a>
      </Shell>
    );
  }

  return (
    <Shell>
      <Loader2 className="h-6 w-6 animate-spin text-brand-500" />
      <p className="mt-3 text-sm text-slate-400">Confirmando seu acesso…</p>
    </Shell>
  );
}

function Shell({ children }) {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-surface-base px-4 text-center">
      <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-gradient text-white shadow-glow">
        <LayoutGrid className="h-7 w-7" />
      </div>
      {children}
    </main>
  );
}
