"use client";

import { useState, useTransition } from "react";
import { criarEscola, atualizarEscola, alternarStatusEscola } from "./actions";
import { ETAPA_LABELS } from "@/lib/etapas";
import { useToast } from "@/components/ToastProvider";
import ActionForm from "@/components/ActionForm";
import SectionHeader from "@/components/SectionHeader";
import {
  School,
  Building2,
  Users,
  Pencil,
  Plus,
  Search,
  CheckCircle2,
  XCircle,
  MapPin,
  FileText,
  Filter,
  X,
  Loader2,
} from "lucide-react";

export default function EscolasList({ escolas = [], diretoresPorEscola = {} }) {
  const [busca, setBusca] = useState("");
  const [modalidadeFiltro, setModalidadeFiltro] = useState("TODAS");
  const [statusFiltro, setStatusFiltro] = useState("TODAS");
  const [diretoriaFiltro, setDiretoriaFiltro] = useState("TODAS");
  const [mostrarNovoForm, setMostrarNovoForm] = useState(false);
  const [escolaEditandoId, setEscolaEditandoId] = useState(null);
  const [isPending, startTransition] = useTransition();
  const toast = useToast();

  // Diretorias de Ensino únicas para o filtro
  const diretoriasUnicas = Array.from(
    new Set(escolas.map((e) => e.diretoria_ensino).filter(Boolean))
  ).sort();

  // Filtragem das escolas
  const escolasFiltradas = escolas.filter((e) => {
    // Busca por texto (nome ou INEP)
    const termo = busca.trim().toLowerCase();
    if (termo) {
      const matchNome = (e.nome || "").toLowerCase().includes(termo);
      const matchInep = (e.codigo_inep || "").toLowerCase().includes(termo);
      const matchDir = (e.diretoria_ensino || "").toLowerCase().includes(termo);
      if (!matchNome && !matchInep && !matchDir) return false;
    }

    // Filtro por Modalidade (ex: MEDIO_TECNICO, FUNDAMENTAL_I, etc.)
    if (modalidadeFiltro !== "TODAS") {
      if (!e.modalidades_ensino?.includes(modalidadeFiltro)) return false;
    }

    // Filtro por Status
    if (statusFiltro === "ATIVAS" && !e.ativo) return false;
    if (statusFiltro === "INATIVAS" && e.ativo) return false;

    // Filtro por Diretoria
    if (diretoriaFiltro !== "TODAS" && e.diretoria_ensino !== diretoriaFiltro) return false;

    return true;
  });

  function handleToggleAtivo(e, novoStatus) {
    startTransition(async () => {
      const res = await alternarStatusEscola(e.id, novoStatus);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Status da escola alterado.");
    });
  }

  return (
    <div className="space-y-6">
      {/* Barra de Ações Superior */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white">Escolas Cadastradas</h2>
          <p className="text-xs text-slate-400">
            {escolasFiltradas.length} {escolasFiltradas.length === 1 ? "escola encontrada" : "escolas encontradas"} (de {escolas.length} no total)
          </p>
        </div>

        <button
          type="button"
          onClick={() => setMostrarNovoForm(!mostrarNovoForm)}
          className="flex items-center justify-center gap-2 rounded-xl btn-primary px-4 py-2.5 text-sm"
        >
          {mostrarNovoForm ? (
            <>
              <X className="h-4 w-4" /> Cancelar
            </>
          ) : (
            <>
              <Plus className="h-4 w-4" /> Cadastrar Escola
            </>
          )}
        </button>
      </div>

      {/* Formulário de Cadastro de Nova Escola */}
      {mostrarNovoForm && (
        <div className="panel border-brand-500/30 bg-surface-overlay/80 p-5 sm:p-6 transition-all duration-200">
          <SectionHeader icon={School}>Nova Escola da Rede</SectionHeader>
          <ActionForm
            action={criarEscola}
            resetOnSuccess
            onSuccess={() => setMostrarNovoForm(false)}
            className="mt-4 grid gap-4 sm:grid-cols-2"
          >
            <Input name="nome" label="Nome da escola" required placeholder="EE Prof. João da Silva" />
            <Input name="codigo_inep" label="Código INEP" placeholder="35000000" />
            <Input
              name="diretoria_ensino"
              label="Diretoria de Ensino"
              placeholder="DE Centro-Sul"
            />
            <Input name="endereco" label="Endereço" placeholder="Rua Exemplo, 123" />
            <ModalidadesCheckboxes />
            <div className="flex items-center gap-3 sm:col-span-2">
              <button type="submit" className="btn-primary">
                Salvar Escola
              </button>
              <button
                type="button"
                onClick={() => setMostrarNovoForm(false)}
                className="rounded-xl border border-surface-border px-4 py-2.5 text-sm text-slate-400 hover:bg-surface-raised"
              >
                Cancelar
              </button>
            </div>
          </ActionForm>
        </div>
      )}

      {/* Painel de Filtros e Busca */}
      <div className="panel space-y-4 p-4">
        {/* Campo de Busca */}
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            autoComplete="off"
            data-lpignore="true"
            placeholder="Buscar por nome da escola, código INEP ou Diretoria…"
            className="w-full rounded-xl border border-surface-border bg-surface-overlay py-2.5 pl-10 pr-4 text-sm text-white placeholder:text-slate-500 outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4"
          />
        </div>

        {/* Tags de Filtro por Modalidade */}
        <div>
          <div className="mb-2 flex items-center gap-1.5 text-xs font-medium text-slate-400">
            <Filter className="h-3 w-3" />
            Filtrar por Modalidade de Ensino:
          </div>
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setModalidadeFiltro("TODAS")}
              className={`rounded-lg px-2.5 py-1 text-xs font-medium transition ${
                modalidadeFiltro === "TODAS"
                  ? "bg-brand-500 text-white shadow-sm"
                  : "bg-surface-overlay text-slate-400 hover:bg-surface-border hover:text-slate-200"
              }`}
            >
              Todas as Modalidades
            </button>
            {Object.entries(ETAPA_LABELS).map(([key, label]) => {
              const ativa = modalidadeFiltro === key;
              const isMedioTecnico = key === "MEDIO_TECNICO";
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setModalidadeFiltro(key)}
                  className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-xs font-medium transition ${
                    ativa
                      ? isMedioTecnico
                        ? "bg-amber-500 text-black shadow-sm font-semibold"
                        : "bg-brand-500 text-white shadow-sm"
                      : isMedioTecnico
                      ? "bg-amber-500/10 text-amber-300 border border-amber-500/20 hover:bg-amber-500/20"
                      : "bg-surface-overlay text-slate-400 hover:bg-surface-border hover:text-slate-200"
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Filtros secundários: Status e Diretoria */}
        <div className="flex flex-wrap items-center gap-3 pt-1 border-t border-surface-border/50 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400">Status:</span>
            <select
              value={statusFiltro}
              onChange={(e) => setStatusFiltro(e.target.value)}
              className="rounded-lg border border-surface-border bg-surface-overlay px-2.5 py-1 text-xs text-slate-200 outline-none focus:border-brand-500"
            >
              <option value="TODAS">Todas</option>
              <option value="ATIVAS">Ativas</option>
              <option value="INATIVAS">Inativas</option>
            </select>
          </div>

          {diretoriasUnicas.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Diretoria:</span>
              <select
                value={diretoriaFiltro}
                onChange={(e) => setDiretoriaFiltro(e.target.value)}
                className="rounded-lg border border-surface-border bg-surface-overlay px-2.5 py-1 text-xs text-slate-200 outline-none focus:border-brand-500 max-w-[200px] truncate"
              >
                <option value="TODAS">Todas as Diretorias</option>
                {diretoriasUnicas.map((dir) => (
                  <option key={dir} value={dir}>
                    {dir}
                  </option>
                ))}
              </select>
            </div>
          )}

          {(busca || modalidadeFiltro !== "TODAS" || statusFiltro !== "TODAS" || diretoriaFiltro !== "TODAS") && (
            <button
              type="button"
              onClick={() => {
                setBusca("");
                setModalidadeFiltro("TODAS");
                setStatusFiltro("TODAS");
                setDiretoriaFiltro("TODAS");
              }}
              className="ml-auto text-xs text-slate-400 hover:text-brand-400 underline"
            >
              Limpar filtros
            </button>
          )}
        </div>
      </div>

      {/* Lista de Escolas */}
      <div className="space-y-3">
        {escolasFiltradas.length > 0 ? (
          escolasFiltradas.map((e) => {
            const diretores = diretoresPorEscola[e.id] || [];
            const estaEditando = escolaEditandoId === e.id;

            return (
              <div
                key={e.id}
                className={`panel transition duration-150 ${
                  !e.ativo ? "opacity-75 border-slate-800" : ""
                }`}
              >
                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-base font-semibold text-white">{e.nome}</h3>
                      {e.ativo ? (
                        <span className="flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[11px] font-medium text-emerald-400 border border-emerald-500/20">
                          <CheckCircle2 className="h-3 w-3" /> Ativa
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 rounded-full bg-red-500/10 px-2 py-0.5 text-[11px] font-medium text-red-400 border border-red-500/20">
                          <XCircle className="h-3 w-3" /> Inativa
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400">
                      {e.diretoria_ensino && (
                        <span className="flex items-center gap-1">
                          <Building2 className="h-3 w-3 text-slate-500" />
                          {e.diretoria_ensino}
                        </span>
                      )}
                      {e.codigo_inep && (
                        <span className="flex items-center gap-1">
                          <FileText className="h-3 w-3 text-slate-500" />
                          INEP: {e.codigo_inep}
                        </span>
                      )}
                      {e.endereco && (
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3 text-slate-500" />
                          {e.endereco}
                        </span>
                      )}
                    </div>

                    {/* Tags de Modalidades de Ensino */}
                    {e.modalidades_ensino?.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {e.modalidades_ensino.map((m) => {
                          const isMedioTecnico = m === "MEDIO_TECNICO";
                          return (
                            <span
                              key={m}
                              className={`rounded-md px-2 py-0.5 text-[11px] font-medium ${
                                isMedioTecnico
                                  ? "bg-amber-500/15 text-amber-300 border border-amber-500/30"
                                  : "bg-brand-500/10 text-brand-400 border border-brand-500/20"
                              }`}
                            >
                              {ETAPA_LABELS[m] || m}
                            </span>
                          );
                        })}
                      </div>
                    )}

                    {/* Gestores / Diretores Vinculados */}
                    <div className="flex items-center gap-1.5 text-xs text-slate-300 pt-1">
                      <Users className="h-3.5 w-3.5 text-brand-400 shrink-0" />
                      <span className="text-slate-400">Gestores:</span>
                      {diretores.length > 0 ? (
                        <span className="font-medium text-slate-200">{diretores.join(", ")}</span>
                      ) : (
                        <span className="italic text-amber-400/80">Nenhum diretor/gestor vinculado ainda</span>
                      )}
                    </div>
                  </div>

                  {/* Ações da Escola */}
                  <div className="flex shrink-0 items-center gap-2 pt-2 sm:pt-0">
                    <button
                      type="button"
                      disabled={isPending}
                      onClick={() => handleToggleAtivo(e, !e.ativo)}
                      className={`rounded-xl border px-3 py-1.5 text-xs font-medium transition disabled:opacity-50 ${
                        e.ativo
                          ? "border-surface-border text-slate-300 hover:bg-surface-overlay hover:text-amber-400"
                          : "border-emerald-900 text-emerald-400 hover:bg-emerald-950/40"
                      }`}
                    >
                      {isPending ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : e.ativo ? (
                        "Desativar"
                      ) : (
                        "Ativar"
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => setEscolaEditandoId(estaEditando ? null : e.id)}
                      className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-medium transition ${
                        estaEditando
                          ? "border-brand-500 bg-brand-500/10 text-brand-400"
                          : "border-surface-border text-slate-300 hover:bg-surface-overlay hover:text-white"
                      }`}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                      {estaEditando ? "Fechar" : "Editar"}
                    </button>
                  </div>
                </div>

                {/* Formulário de Edição da Escola */}
                {estaEditando && (
                  <div className="mt-4 border-t border-surface-border pt-4">
                    <ActionForm
                      action={atualizarEscola}
                      successMessage="Escola atualizada."
                      onSuccess={() => setEscolaEditandoId(null)}
                      className="grid gap-4 rounded-xl bg-surface-overlay/80 p-4 sm:grid-cols-2"
                    >
                      <input type="hidden" name="id" value={e.id} />
                      <Input name="nome" label="Nome da escola" required defaultValue={e.nome} />
                      <Input name="codigo_inep" label="Código INEP" defaultValue={e.codigo_inep} />
                      <Input
                        name="diretoria_ensino"
                        label="Diretoria de Ensino"
                        defaultValue={e.diretoria_ensino}
                      />
                      <Input name="endereco" label="Endereço" defaultValue={e.endereco} />
                      <ModalidadesCheckboxes selecionadas={e.modalidades_ensino || []} />
                      <label className="flex items-center gap-2 text-sm text-slate-300">
                        <input
                          type="checkbox"
                          name="ativo"
                          defaultChecked={e.ativo}
                          className="h-4 w-4 rounded"
                        />
                        Escola ativa
                      </label>
                      <div className="flex items-center gap-2 sm:col-span-2">
                        <button type="submit" className="btn-primary-compact">
                          Salvar Alterações
                        </button>
                        <button
                          type="button"
                          onClick={() => setEscolaEditandoId(null)}
                          className="rounded-lg border border-surface-border px-3 py-1.5 text-xs text-slate-400 hover:bg-surface-raised"
                        >
                          Cancelar
                        </button>
                      </div>
                    </ActionForm>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="panel py-10 text-center">
            <School className="mx-auto h-8 w-8 text-slate-500 mb-2" />
            <p className="text-sm font-medium text-slate-300">Nenhuma escola encontrada com os filtros selecionados.</p>
            <p className="text-xs text-slate-500 mt-1">Tente remover os filtros ou buscar por outro termo.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function ModalidadesCheckboxes({ selecionadas = [] }) {
  return (
    <div className="sm:col-span-2">
      <span className="mb-1.5 block text-sm font-medium text-slate-300">
        Modalidades de ensino oferecidas
      </span>
      <div className="flex flex-wrap gap-x-4 gap-y-2">
        {Object.entries(ETAPA_LABELS).map(([value, label]) => {
          const isMedioTecnico = value === "MEDIO_TECNICO";
          return (
            <label
              key={value}
              className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs transition cursor-pointer ${
                isMedioTecnico
                  ? "border-amber-500/30 bg-amber-500/5 text-amber-300"
                  : "border-surface-border bg-surface-overlay text-slate-300 hover:border-slate-600"
              }`}
            >
              <input
                type="checkbox"
                name="modalidades_ensino"
                value={value}
                defaultChecked={selecionadas.includes(value)}
                className="h-4 w-4 rounded accent-brand-500"
              />
              <span className="font-medium">{label}</span>
            </label>
          );
        })}
      </div>
    </div>
  );
}

function Input({ name, label, required, placeholder, defaultValue, type = "text" }) {
  return (
    <label className="block text-sm">
      <span className="mb-1.5 block font-medium text-slate-300">{label}</span>
      <input
        name={name}
        type={type}
        required={required}
        placeholder={placeholder}
        defaultValue={defaultValue || ""}
        autoComplete="off"
        data-lpignore="true"
        className="w-full rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2.5 text-sm text-white outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4 placeholder:text-slate-500"
      />
    </label>
  );
}
