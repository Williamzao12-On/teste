export function Input({ name, label, required, placeholder, defaultValue, type = "text" }) {
  return (
    <label className="block text-sm">
      <span className="mb-1.5 block font-medium text-slate-300">{label}</span>
      <input
        name={name}
        type={type}
        required={required}
        placeholder={placeholder}
        defaultValue={defaultValue || ""}
        autoComplete="off"
        data-lpignore="true"
        className="w-full rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4"
      />
    </label>
  );
}

export function Select({ name, label, required, defaultValue, children }) {
  return (
    <label className="block text-sm">
      <span className="mb-1.5 block font-medium text-slate-300">{label}</span>
      <select
        name={name}
        required={required}
        defaultValue={defaultValue}
        className="w-full rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2.5 text-sm text-white outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4"
      >
        {children}
      </select>
    </label>
  );
}

export function SubmitButton({ label, compact, pending }) {
  return (
    <button
      type="submit"
      disabled={pending}
      className={cn(compact ? "btn-primary-compact" : "btn-primary", pending && "opacity-60")}
    >
      {pending ? "Enviando…" : label}
    </button>
  );
}

function cn(...classes) {
  return classes.filter(Boolean).join(" ");
}
