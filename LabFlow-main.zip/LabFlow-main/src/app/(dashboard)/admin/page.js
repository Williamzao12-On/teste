import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import AdminTabs from "./AdminTabs";

export default async function AdminPage() {
  const eu = await requireRole(["ADMIN"]);
  const supabase = createClient();
  const supabaseAdmin = createAdminClient();

  const [{ data: escolas }, { data: perfis }, { data: authData }, { data: recursos }] =
    await Promise.all([
      supabase.from("escolas").select("*").order("nome"),
      supabase
        .from("profiles")
        .select("id, nome_completo, email, role, escola_id, created_at")
        .order("nome_completo"),
      supabaseAdmin.auth.admin.listUsers({ perPage: 1000 }),
      supabase.from("recursos").select("id, status"),
    ]);

  const authById = Object.fromEntries((authData?.users || []).map((u) => [u.id, u]));

  const perfisComStatus = (perfis || []).map((p) => ({
    ...p,
    pendente: !authById[p.id]?.last_sign_in_at,
  }));

  // Mapa escola_id -> nomes de quem dirige/gerencia aquela escola
  const diretoresPorEscola = {};
  for (const p of perfisComStatus) {
    if (["DIRETOR", "GESTOR_ESCOLAR"].includes(p.role) && p.escola_id) {
      diretoresPorEscola[p.escola_id] ||= [];
      diretoresPorEscola[p.escola_id].push(p.nome_completo || p.email);
    }
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Painel Administrativo
          </h1>
          <p className="text-sm text-slate-400">
            Governança da rede, gestão de unidades escolares e controle de acessos institucionais.
          </p>
        </div>
      </header>

      <AdminTabs
        escolas={escolas || []}
        usuarios={perfisComStatus}
        recursos={recursos || []}
        diretoresPorEscola={diretoresPorEscola}
        currentUserId={eu.id}
      />
    </div>
  );
}
