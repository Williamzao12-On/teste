"use client";

import { useState } from "react";
import EscolasList from "./EscolasList";
import UsersTable from "./UsersTable";
import {
  LayoutDashboard,
  School,
  Users,
  Building2,
  CheckCircle2,
  Clock,
  Laptop,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  GraduationCap,
} from "lucide-react";

export default function AdminTabs({
  escolas = [],
  usuarios = [],
  recursos = [],
  diretoresPorEscola = {},
  currentUserId,
}) {
  const [tabAtiva, setTabAtiva] = useState("visao-geral"); // 'visao-geral' | 'escolas' | 'usuarios'

  // Cálculos de métricas
  const escolasAtivas = escolas.filter((e) => e.ativo).length;
  const pendentesConvite = usuarios.filter((u) => u.pendente).length;
  const aguardandoVinculo = usuarios.filter((u) => !u.escola_id && u.role !== "ADMIN").length;

  const totalDocentes = usuarios.filter((u) => ["DOCENTE", "DOCENTE_DS"].includes(u.role)).length;
  const totalGestores = usuarios.filter((u) => ["DIRETOR", "GESTOR_ESCOLAR"].includes(u.role)).length;
  const totalAdmins = usuarios.filter((u) => u.role === "ADMIN").length;

  const recursosDisponiveis = recursos.filter((r) => r.status === "DISPONIVEL").length;
  const recursosManutencao = recursos.filter((r) =>
    ["MANUTENCAO_PARCIAL", "MANUTENCAO_TOTAL"].includes(r.status)
  ).length;

  return (
    <div className="space-y-8">
      {/* Navegação de Abas do Painel Admin */}
      <div className="flex flex-wrap items-center gap-2 border-b border-surface-border pb-3">
        <button
          type="button"
          onClick={() => setTabAtiva("visao-geral")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition ${
            tabAtiva === "visao-geral"
              ? "bg-brand-500/15 text-brand-400 border border-brand-500/30 shadow-sm"
              : "text-slate-400 hover:bg-surface-overlay hover:text-slate-200"
          }`}
        >
          <LayoutDashboard className="h-4 w-4" />
          Visão Geral
        </button>

        <button
          type="button"
          onClick={() => setTabAtiva("escolas")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition ${
            tabAtiva === "escolas"
              ? "bg-brand-500/15 text-brand-400 border border-brand-500/30 shadow-sm"
              : "text-slate-400 hover:bg-surface-overlay hover:text-slate-200"
          }`}
        >
          <School className="h-4 w-4" />
          Escolas da Rede
          <span className="rounded-full bg-surface-raised px-2 py-0.5 text-xs text-slate-300 border border-surface-border">
            {escolas.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => setTabAtiva("usuarios")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition ${
            tabAtiva === "usuarios"
              ? "bg-brand-500/15 text-brand-400 border border-brand-500/30 shadow-sm"
              : "text-slate-400 hover:bg-surface-overlay hover:text-slate-200"
          }`}
        >
          <Users className="h-4 w-4" />
          Usuários & Convites
          <span className="rounded-full bg-surface-raised px-2 py-0.5 text-xs text-slate-300 border border-surface-border">
            {usuarios.length}
          </span>
          {(pendentesConvite > 0 || aguardandoVinculo > 0) && (
            <span className="h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
          )}
        </button>
      </div>

      {/* CONTEÚDO: Aba Visão Geral */}
      {tabAtiva === "visao-geral" && (
        <div className="space-y-8">
          {/* Alertas de Ação Rápida */}
          {aguardandoVinculo > 0 && (
            <div className="flex flex-col gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400">
                  <AlertTriangle className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-white">
                    {aguardandoVinculo} {aguardandoVinculo === 1 ? "usuário aguardando vínculo" : "usuários aguardando vínculo"}
                  </h4>
                  <p className="text-xs text-slate-300">
                    Contas que já fizeram login mas ainda não possuem uma escola vinculada.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setTabAtiva("usuarios")}
                className="flex items-center gap-1.5 self-start sm:self-auto rounded-xl bg-amber-500 px-3.5 py-2 text-xs font-semibold text-black hover:bg-amber-400 transition"
              >
                Revisar Acessos <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          )}

          {/* Grid de Indicadores Principais */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {/* Card: Escolas */}
            <div className="panel p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Escolas da Rede</span>
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-500/10 text-brand-400">
                  <School className="h-4 w-4" />
                </div>
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{escolas.length}</p>
                <p className="text-xs text-emerald-400 flex items-center gap-1 mt-1">
                  <CheckCircle2 className="h-3 w-3" />
                  {escolasAtivas} ativas no sistema
                </p>
              </div>
            </div>

            {/* Card: Usuários Totais */}
            <div className="panel p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Total de Usuários</span>
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-500/10 text-purple-400">
                  <Users className="h-4 w-4" />
                </div>
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{usuarios.length}</p>
                <p className="text-xs text-slate-400 mt-1">
                  {totalDocentes} docentes · {totalGestores} gestores
                </p>
              </div>
            </div>

            {/* Card: Convites Pendentes */}
            <div className="panel p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Convites Pendentes</span>
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/10 text-amber-400">
                  <Clock className="h-4 w-4" />
                </div>
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{pendentesConvite}</p>
                <p className="text-xs text-slate-400 mt-1">
                  Aguardando primeiro acesso
                </p>
              </div>
            </div>

            {/* Card: Recursos Físicos na Rede */}
            <div className="panel p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Recursos Registrados</span>
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/10 text-cyan-400">
                  <Laptop className="h-4 w-4" />
                </div>
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{recursos.length}</p>
                <p className="text-xs text-slate-400 mt-1">
                  {recursosDisponiveis} disponíveis · {recursosManutencao} em manutenção
                </p>
              </div>
            </div>
          </div>

          {/* Cards de Atalho e Estrutura */}
          <div className="grid gap-5 lg:grid-cols-2">
            {/* Atalho Escolas */}
            <div className="panel p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-gradient text-white shadow-glow">
                  <Building2 className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Unidades Escolares</h3>
                  <p className="text-xs text-slate-400">
                    Controle de escolas estaduais, diretorias de ensino e modalidades.
                  </p>
                </div>
              </div>

              <p className="text-sm text-slate-300">
                Configure as escolas participantes, habilite modalidades de ensino oferecidas
                (como Ensino Médio Técnico, Fundamental e Regular) e verifique os diretores responsáveis.
              </p>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setTabAtiva("escolas")}
                  className="btn-primary flex items-center gap-2 text-xs"
                >
                  Gerenciar Escolas <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Atalho Usuários */}
            <div className="panel p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  <ShieldCheck className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Acessos & Convites</h3>
                  <p className="text-xs text-slate-400">
                    Gestão de professores, equipes gestoras e administradores.
                  </p>
                </div>
              </div>

              <p className="text-sm text-slate-300">
                Convide novos diretores e professores por e-mail com vínculo automático, aprove
                cadastros pendentes e administre permissões institucionais com trava de segurança.
              </p>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setTabAtiva("usuarios")}
                  className="btn-primary flex items-center gap-2 text-xs"
                >
                  Gerenciar Usuários & Convites <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CONTEÚDO: Aba Escolas */}
      {tabAtiva === "escolas" && (
        <EscolasList escolas={escolas} diretoresPorEscola={diretoresPorEscola} />
      )}

      {/* CONTEÚDO: Aba Usuários */}
      {tabAtiva === "usuarios" && (
        <UsersTable
          usuarios={usuarios}
          escolas={escolas}
          currentUserId={currentUserId}
        />
      )}
    </div>
  );
}
