"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireRole } from "@/lib/auth";

export async function criarEscola(prevState, formData) {
  await requireRole(["ADMIN"]);
  const supabase = createClient();

  const nome = formData.get("nome")?.toString().trim();
  const codigo_inep = formData.get("codigo_inep")?.toString().trim() || null;
  const diretoria_ensino = formData.get("diretoria_ensino")?.toString().trim() || null;
  const endereco = formData.get("endereco")?.toString().trim() || null;
  const modalidades_ensino = formData.getAll("modalidades_ensino").map((v) => v.toString());

  if (!nome) return { error: "Informe o nome da escola." };

  const { error } = await supabase
    .from("escolas")
    .insert({ nome, codigo_inep, diretoria_ensino, endereco, modalidades_ensino });

  if (error) return { error: error.message };

  revalidatePath("/admin");
  return { success: `Escola "${nome}" cadastrada.` };
}

export async function atribuirEscolaEPapel(prevState, formData) {
  const eu = await requireRole(["ADMIN"]);
  const supabase = createClient();

  const userId = formData.get("user_id")?.toString();
  const escolaId = formData.get("escola_id")?.toString() || null;
  const role = formData.get("role")?.toString();

  if (!userId || !role) {
    return { error: "Selecione o usuário e o papel." };
  }

  // Trava de segurança: impede que o próprio Admin logado remova seu próprio papel
  if (userId === eu.id && role !== "ADMIN") {
    return { error: "Você não pode remover seu próprio papel de Administrador." };
  }

  if (role !== "ADMIN" && !escolaId) {
    return { error: "Selecione uma escola (obrigatório para esse papel)." };
  }

  const { error } = await supabase
    .from("profiles")
    .update({ escola_id: escolaId, role })
    .eq("id", userId);

  if (error) return { error: error.message };

  revalidatePath("/admin");
  return { success: "Vínculo atualizado." };
}

export async function alternarStatusEscola(id, novoStatus) {
  await requireRole(["ADMIN"]);
  const supabase = createClient();
  if (!id) return { error: "Escola inválida." };

  const { error } = await supabase
    .from("escolas")
    .update({ ativo: novoStatus })
    .eq("id", id);

  if (error) return { error: error.message };

  revalidatePath("/admin");
  return { success: `Escola ${novoStatus ? "ativada" : "desativada"} com sucesso.` };
}

export async function atualizarEscola(prevState, formData) {
  await requireRole(["ADMIN"]);
  const supabase = createClient();

  const id = formData.get("id")?.toString();
  const nome = formData.get("nome")?.toString().trim();
  const codigo_inep = formData.get("codigo_inep")?.toString().trim() || null;
  const diretoria_ensino = formData.get("diretoria_ensino")?.toString().trim() || null;
  const endereco = formData.get("endereco")?.toString().trim() || null;
  const ativo = formData.get("ativo") === "on";
  const modalidades_ensino = formData.getAll("modalidades_ensino").map((v) => v.toString());

  if (!id || !nome) return { error: "Dados inválidos." };

  const { error } = await supabase
    .from("escolas")
    .update({ nome, codigo_inep, diretoria_ensino, endereco, ativo, modalidades_ensino })
    .eq("id", id);

  if (error) return { error: error.message };

  revalidatePath("/admin");
  return { success: "Escola atualizada." };
}

export async function convidarUsuario(prevState, formData) {
  await requireRole(["ADMIN"]);

  const email = formData.get("email")?.toString().trim().toLowerCase();
  const nome = formData.get("nome")?.toString().trim() || null;
  const escolaId = formData.get("escola_id")?.toString() || null;
  const role = formData.get("role")?.toString() || "DOCENTE";

  if (!email) return { error: "Informe o e-mail." };
  if (role !== "ADMIN" && !escolaId) {
    return { error: "Selecione uma escola para esse papel." };
  }

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
  if (!siteUrl) {
    return {
      error: "NEXT_PUBLIC_SITE_URL não configurada no ambiente. Configure e tente de novo.",
    };
  }

  let supabaseAdmin;
  try {
    supabaseAdmin = createAdminClient();
  } catch (e) {
    return { error: `Falha ao criar client admin: ${e.message}` };
  }

  const { error } = await supabaseAdmin.auth.admin.inviteUserByEmail(email, {
    data: {
      full_name: nome,
      escola_id: escolaId,
      role,
    },
    redirectTo: `${siteUrl}/auth/callback`,
  });

  if (error) {
    if (error.message?.toLowerCase().includes("already been registered")) {
      return {
        error: "Esse e-mail já tem cadastro. Use a lista 'Todos os usuários' para vincular.",
      };
    }
    return { error: `Supabase: ${error.message}` };
  }

  revalidatePath("/admin");
  return { success: `Convite enviado para ${email}.`, email };
}

// =========================================================
// Excluir usuário / Reenviar convite
// Chamadas diretamente do client (não via <form action=...>),
// por isso recebem o userId puro, não FormData.
// =========================================================

export async function excluirUsuario(userId) {
  const eu = await requireRole(["ADMIN"]);

  if (!userId) return { error: "Usuário inválido." };
  if (userId === eu.id) {
    return { error: "Você não pode excluir a própria conta por aqui." };
  }

  const supabaseAdmin = createAdminClient();
  const { error } = await supabaseAdmin.auth.admin.deleteUser(userId);

  if (error) return { error: error.message };

  revalidatePath("/admin");
  return { success: "Usuário excluído." };
}

export async function reenviarConvite(userId) {
  await requireRole(["ADMIN"]);
  if (!userId) return { error: "Usuário inválido." };

  const supabase = createClient();
  const { data: alvo, error: fetchError } = await supabase
    .from("profiles")
    .select("email, nome_completo, escola_id, role")
    .eq("id", userId)
    .single();

  if (fetchError || !alvo) return { error: "Usuário não encontrado." };

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
  if (!siteUrl) return { error: "NEXT_PUBLIC_SITE_URL não configurada no ambiente." };

  const supabaseAdmin = createAdminClient();

  // O convite antigo (não confirmado) precisa ser removido antes de recriar,
  // senão o Supabase recusa com "already been registered".
  const { error: delError } = await supabaseAdmin.auth.admin.deleteUser(userId);
  if (delError) return { error: `Falha ao limpar convite antigo: ${delError.message}` };

  const { error: inviteError } = await supabaseAdmin.auth.admin.inviteUserByEmail(alvo.email, {
    data: {
      full_name: alvo.nome_completo,
      escola_id: alvo.escola_id,
      role: alvo.role,
    },
    redirectTo: `${siteUrl}/auth/callback`,
  });

  if (inviteError) return { error: inviteError.message };

  revalidatePath("/admin");
  return { success: `Convite reenviado para ${alvo.email}.` };
}
