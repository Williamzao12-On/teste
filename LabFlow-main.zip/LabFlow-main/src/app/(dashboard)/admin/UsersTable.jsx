"use client";

import { useState, useTransition } from "react";
import { excluirUsuario, reenviarConvite, atribuirEscolaEPapel } from "./actions";
import { Select } from "./FormFields";
import { ROLE_LABELS } from "@/lib/roles";
import { useToast } from "@/components/ToastProvider";
import ActionForm from "@/components/ActionForm";
import InviteForm from "./InviteForm";
import {
  Search,
  Trash2,
  Send,
  Clock,
  Loader2,
  Shield,
  UserCheck,
  UserX,
  Building2,
  Filter,
  UserPlus,
  X,
  AlertTriangle,
} from "lucide-react";

export default function UsersTable({ usuarios = [], escolas = [], currentUserId }) {
  const [busca, setBusca] = useState("");
  const [filtroAba, setFiltroAba] = useState("TODOS"); // 'TODOS' | 'AGUARDANDO_VINCULO' | 'PENDENTES'
  const [filtroRole, setFiltroRole] = useState("TODOS");
  const [filtroEscola, setFiltroEscola] = useState("TODAS");
  const [mostrarConvite, setMostrarConvite] = useState(false);
  const [usuarioParaExcluir, setUsuarioParaExcluir] = useState(null);
  const [isPending, startTransition] = useTransition();
  const toast = useToast();

  const pendentesConvite = usuarios.filter((u) => u.pendente);
  const aguardandoVinculo = usuarios.filter((u) => !u.escola_id && u.role !== "ADMIN");

  const filtrados = usuarios.filter((u) => {
    // Filtro por aba
    if (filtroAba === "PENDENTES" && !u.pendente) return false;
    if (filtroAba === "AGUARDANDO_VINCULO" && (u.escola_id || u.role === "ADMIN")) return false;

    // Filtro por papel
    if (filtroRole !== "TODOS" && u.role !== filtroRole) return false;

    // Filtro por escola
    if (filtroEscola !== "TODAS") {
      if (filtroEscola === "SEM_ESCOLA" && u.escola_id) return false;
      if (filtroEscola !== "SEM_ESCOLA" && u.escola_id !== filtroEscola) return false;
    }

    // Busca textual
    const termo = busca.trim().toLowerCase();
    if (!termo) return true;
    return (
      (u.nome_completo || "").toLowerCase().includes(termo) ||
      (u.email || "").toLowerCase().includes(termo)
    );
  });

  function handleConfirmarExclusao() {
    if (!usuarioParaExcluir) return;
    const alvo = usuarioParaExcluir;
    setUsuarioParaExcluir(null);

    startTransition(async () => {
      const res = await excluirUsuario(alvo.id);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Usuário excluído definitivamente.");
    });
  }

  function handleReenviar(u) {
    startTransition(async () => {
      const res = await reenviarConvite(u.id);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Convite reenviado com sucesso.");
    });
  }

  // Mapa de cores para badges de papel
  const roleBadges = {
    ADMIN: "bg-purple-500/15 text-purple-300 border-purple-500/30",
    DIRETOR: "bg-brand-500/15 text-brand-300 border-brand-500/30",
    GESTOR_ESCOLAR: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
    DOCENTE_DS: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
    DOCENTE: "bg-slate-500/15 text-slate-300 border-slate-500/30",
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho de Ações */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white">Gerenciamento de Usuários & Acessos</h2>
          <p className="text-xs text-slate-400">
            Controle centralizado de permissões, papéis e convites institucionais.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setMostrarConvite(!mostrarConvite)}
          className="flex items-center justify-center gap-2 rounded-xl btn-primary px-4 py-2.5 text-sm"
        >
          {mostrarConvite ? (
            <>
              <X className="h-4 w-4" /> Fechar Convite
            </>
          ) : (
            <>
              <UserPlus className="h-4 w-4" /> Convidar por E-mail
            </>
          )}
        </button>
      </div>

      {/* Formulário de Envio de Convite */}
      {mostrarConvite && (
        <div className="panel border-brand-500/30 bg-surface-overlay/80 p-5 sm:p-6 transition-all duration-200">
          <div className="mb-4">
            <h3 className="text-base font-semibold text-white">Novo Convite Institucional</h3>
            <p className="text-xs text-slate-400">
              O usuário receberá um e-mail com acesso direto vinculado à escola e papel selecionados.
            </p>
          </div>
          <InviteForm escolas={escolas} />
        </div>
      )}

      {/* Filtros e Abas */}
      <div className="panel space-y-4 p-4">
        {/* Sub-abas Rápidas */}
        <div className="flex flex-wrap gap-2 border-b border-surface-border pb-3">
          <button
            type="button"
            onClick={() => setFiltroAba("TODOS")}
            className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium transition ${
              filtroAba === "TODOS"
                ? "bg-brand-500 text-white shadow-sm"
                : "bg-surface-overlay text-slate-400 hover:text-slate-200"
            }`}
          >
            Todos os Usuários
            <span className="rounded-full bg-black/30 px-1.5 py-0.2 text-[10px]">
              {usuarios.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setFiltroAba("AGUARDANDO_VINCULO")}
            className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium transition ${
              filtroAba === "AGUARDANDO_VINCULO"
                ? "bg-amber-500 text-black font-semibold shadow-sm"
                : "bg-amber-500/10 text-amber-400 border border-amber-500/20 hover:bg-amber-500/20"
            }`}
          >
            Aguardando Vínculo
            <span className="rounded-full bg-black/20 px-1.5 py-0.2 text-[10px]">
              {aguardandoVinculo.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setFiltroAba("PENDENTES")}
            className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-medium transition ${
              filtroAba === "PENDENTES"
                ? "bg-blue-500 text-white shadow-sm"
                : "bg-surface-overlay text-slate-400 hover:text-slate-200"
            }`}
          >
            <Clock className="h-3 w-3" />
            Convites Pendentes
            <span className="rounded-full bg-black/30 px-1.5 py-0.2 text-[10px]">
              {pendentesConvite.length}
            </span>
          </button>
        </div>

        {/* Busca e Seletores de Filtro */}
        <div className="grid gap-3 sm:grid-cols-3">
          {/* Busca Textual */}
          <div className="relative sm:col-span-1">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              autoComplete="off"
              data-lpignore="true"
              placeholder="Buscar por nome ou e-mail…"
              className="w-full rounded-xl border border-surface-border bg-surface-overlay py-2 pl-9 pr-4 text-xs text-white placeholder:text-slate-500 outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4"
            />
          </div>

          {/* Filtro por Papel */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 shrink-0">Papel:</span>
            <select
              value={filtroRole}
              onChange={(e) => setFiltroRole(e.target.value)}
              className="w-full rounded-lg border border-surface-border bg-surface-overlay px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:border-brand-500"
            >
              <option value="TODOS">Todos os Papéis</option>
              {Object.entries(ROLE_LABELS).map(([value, label]) => (
                <option key={value} value={value}>
                  {label}
                </option>
              ))}
            </select>
          </div>

          {/* Filtro por Escola */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 shrink-0">Escola:</span>
            <select
              value={filtroEscola}
              onChange={(e) => setFiltroEscola(e.target.value)}
              className="w-full rounded-lg border border-surface-border bg-surface-overlay px-2.5 py-1.5 text-xs text-slate-200 outline-none focus:border-brand-500 truncate"
            >
              <option value="TODAS">Todas as Escolas</option>
              <option value="SEM_ESCOLA">Sem Escola Atribuída</option>
              {escolas.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.nome}
                </option>
              ))}
            </select>
          </div>
        </div>

        {(busca || filtroAba !== "TODOS" || filtroRole !== "TODOS" || filtroEscola !== "TODAS") && (
          <div className="flex justify-end pt-1">
            <button
              type="button"
              onClick={() => {
                setBusca("");
                setFiltroAba("TODOS");
                setFiltroRole("TODOS");
                setFiltroEscola("TODAS");
              }}
              className="text-xs text-slate-400 hover:text-brand-400 underline"
            >
              Limpar todos os filtros
            </button>
          </div>
        )}
      </div>

      {/* Lista de Usuários */}
      <div className="space-y-3">
        {filtrados.length ? (
          filtrados.map((u) => {
            const isSelf = u.id === currentUserId;
            const escolaDoUsuario = escolas.find((e) => e.id === u.escola_id);

            return (
              <div
                key={u.id}
                className="flex flex-col gap-3 rounded-xl border border-surface-border bg-surface-raised p-4 sm:flex-row sm:flex-wrap sm:items-center sm:justify-between transition hover:border-slate-700"
              >
                {/* Informações do Usuário */}
                <div className="min-w-[220px] flex-1 space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-medium text-slate-100">
                      {u.nome_completo || "(Nome não informado)"}
                    </p>

                    {isSelf && (
                      <span className="flex items-center gap-1 rounded-full bg-purple-500/20 px-2 py-0.5 text-[11px] font-semibold text-purple-300 border border-purple-500/30">
                        <Shield className="h-3 w-3" /> Você (Administrador)
                      </span>
                    )}

                    <span
                      className={`rounded-md border px-2 py-0.5 text-[11px] font-medium ${
                        roleBadges[u.role] || "bg-slate-500/10 text-slate-400"
                      }`}
                    >
                      {ROLE_LABELS[u.role] || u.role}
                    </span>

                    {u.pendente && (
                      <span className="flex shrink-0 items-center gap-1 rounded-full bg-amber-500/15 px-2 py-0.5 text-xs text-amber-400 border border-amber-500/30">
                        <Clock className="h-3 w-3" />
                        Convite pendente
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-400">{u.email}</p>

                  <div className="flex items-center gap-1 text-xs text-slate-400 pt-0.5">
                    <Building2 className="h-3 w-3 text-slate-500 shrink-0" />
                    {escolaDoUsuario ? (
                      <span className="text-slate-300 font-medium">{escolaDoUsuario.nome}</span>
                    ) : u.role === "ADMIN" ? (
                      <span className="text-purple-400 font-medium">Acesso Global (Sistema)</span>
                    ) : (
                      <span className="text-amber-400 italic">Pendente de atribuição de escola</span>
                    )}
                  </div>
                </div>

                {/* Formulário de Alteração de Vínculo / Papel */}
                <div className="flex flex-wrap items-center gap-2 pt-2 sm:pt-0">
                  <ActionForm
                    action={atribuirEscolaEPapel}
                    className="flex flex-wrap items-end gap-2"
                  >
                    <input type="hidden" name="user_id" value={u.id} />
                    <Select
                      name="escola_id"
                      label="Escola"
                      defaultValue={u.escola_id || ""}
                    >
                      <option value="">Nenhuma (só p/ ADMIN)</option>
                      {escolas?.map((e) => (
                        <option key={e.id} value={e.id}>
                          {e.nome}
                        </option>
                      ))}
                    </Select>

                    {isSelf ? (
                      <div className="block text-sm">
                        <span className="mb-1.5 block font-medium text-slate-400 text-xs">Papel</span>
                        <input
                          type="hidden"
                          name="role"
                          value="ADMIN"
                        />
                        <div className="rounded-xl border border-surface-border bg-surface-overlay/50 px-3.5 py-2 text-xs text-purple-300 font-medium">
                          Administrador (Fixo)
                        </div>
                      </div>
                    ) : (
                      <Select name="role" label="Papel" required defaultValue={u.role}>
                        <option value="DOCENTE">{ROLE_LABELS.DOCENTE}</option>
                        <option value="DOCENTE_DS">{ROLE_LABELS.DOCENTE_DS}</option>
                        <option value="GESTOR_ESCOLAR">{ROLE_LABELS.GESTOR_ESCOLAR}</option>
                        <option value="DIRETOR">{ROLE_LABELS.DIRETOR}</option>
                        <option value="ADMIN">{ROLE_LABELS.ADMIN}</option>
                      </Select>
                    )}

                    <button type="submit" className="btn-primary-compact">
                      Salvar
                    </button>
                  </ActionForm>

                  {/* Ações de Reenviar e Excluir */}
                  <div className="flex shrink-0 items-center gap-2 ml-auto sm:ml-2">
                    {u.pendente && (
                      <button
                        type="button"
                        disabled={isPending}
                        onClick={() => handleReenviar(u)}
                        title="Reenviar convite por e-mail"
                        className="flex h-9 w-9 items-center justify-center rounded-xl border border-surface-border text-slate-300 transition hover:bg-surface-overlay hover:text-white disabled:opacity-50"
                      >
                        {isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Send className="h-4 w-4" />
                        )}
                      </button>
                    )}

                    {!isSelf && (
                      <button
                        type="button"
                        disabled={isPending}
                        onClick={() => setUsuarioParaExcluir(u)}
                        title="Excluir usuário permanentemente"
                        className="flex h-9 w-9 items-center justify-center rounded-xl border border-red-900/60 text-red-400 transition hover:bg-red-950/40 hover:border-red-700 disabled:opacity-50"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="panel py-10 text-center">
            <UserX className="mx-auto h-8 w-8 text-slate-500 mb-2" />
            <p className="text-sm font-medium text-slate-300">Nenhum usuário encontrado com os filtros selecionados.</p>
            <p className="text-xs text-slate-500 mt-1">Tente ajustar o termo de busca ou filtros de papel/escola.</p>
          </div>
        )}
      </div>

      {/* Modal de Confirmação de Exclusão */}
      {usuarioParaExcluir && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-md panel border-red-900/50 bg-surface-raised p-6 shadow-2xl">
            <div className="flex items-center gap-3 text-red-400 mb-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-950/50 border border-red-900/50">
                <AlertTriangle className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">Confirmar Exclusão</h3>
            </div>
            <p className="text-sm text-slate-300 mb-4">
              Você está prestes a excluir permanentemente o usuário{" "}
              <strong className="text-white font-semibold">
                {usuarioParaExcluir.nome_completo || usuarioParaExcluir.email}
              </strong>
              . Essa ação não pode ser desfeita e removerá o login do sistema.
            </p>
            <div className="flex items-center justify-end gap-3 pt-2 border-t border-surface-border">
              <button
                type="button"
                onClick={() => setUsuarioParaExcluir(null)}
                className="rounded-xl border border-surface-border px-4 py-2 text-xs font-medium text-slate-300 hover:bg-surface-overlay"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmarExclusao}
                className="rounded-xl bg-red-600 px-4 py-2 text-xs font-medium text-white hover:bg-red-500 transition"
              >
                Sim, Excluir Usuário
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
