"use client";

import { useEffect, useRef } from "react";
import { useFormState, useFormStatus } from "react-dom";
import { convidarUsuario } from "./actions";
import { Input, Select, SubmitButton } from "./FormFields";
import { ROLE_LABELS } from "@/lib/roles";
import { useToast } from "@/components/ToastProvider";
import { AlertTriangle, CheckCircle2 } from "lucide-react";

const initialState = { error: null, success: false };

export default function InviteForm({ escolas }) {
  const [state, formAction] = useFormState(convidarUsuario, initialState);
  const toast = useToast();
  const lastHandled = useRef(null);

  useEffect(() => {
    if (state === initialState || state === lastHandled.current) return;
    lastHandled.current = state;
    if (state?.error) toast.error(state.error);
    else if (state?.success) toast.success(state.success);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return (
    <form action={formAction} className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {state?.error && (
        <p className="flex items-start gap-2 rounded-lg bg-red-950/40 px-3 py-2 text-sm text-red-400 lg:col-span-4">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          {state.error}
        </p>
      )}
      {state?.success && (
        <p className="flex items-start gap-2 rounded-lg bg-green-950/40 px-3 py-2 text-sm text-green-400 lg:col-span-4">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
          Convite enviado para {state.email}. Peça pra pessoa checar caixa de entrada e spam.
        </p>
      )}

      <Input name="nome" label="Nome (opcional)" placeholder="Maria Souza" />
      <Input
        name="email"
        label="E-mail"
        type="email"
        required
        placeholder="maria@educacao.sp.gov.br"
      />
      <Select name="escola_id" label="Escola">
        <option value="">Selecione…</option>
        {escolas?.map((e) => (
          <option key={e.id} value={e.id}>
            {e.nome}
          </option>
        ))}
      </Select>
      <Select name="role" label="Papel" required defaultValue="DIRETOR">
        <option value="DIRETOR">{ROLE_LABELS.DIRETOR}</option>
        <option value="GESTOR_ESCOLAR">{ROLE_LABELS.GESTOR_ESCOLAR}</option>
        <option value="DOCENTE">{ROLE_LABELS.DOCENTE}</option>
        <option value="DOCENTE_DS">{ROLE_LABELS.DOCENTE_DS}</option>
      </Select>

      <div className="lg:col-span-4">
        <SubmitBtn />
      </div>
    </form>
  );
}

function SubmitBtn() {
  const { pending } = useFormStatus();
  return <SubmitButton label="Enviar convite" pending={pending} />;
}
