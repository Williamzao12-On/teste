"use client";

import { useState, useTransition } from "react";
import ActionForm from "@/components/ActionForm";
import SectionHeader from "@/components/SectionHeader";
import { reportarIncidente, resolverIncidente } from "./actions";
import { useToast } from "@/components/ToastProvider";
import {
  AlertTriangle,
  CheckCircle2,
  Plus,
  Wrench,
  Clock,
  Laptop,
  Check,
  X,
  Loader2,
  Filter,
} from "lucide-react";

export default function IncidentesManager({
  incidentes = [],
  recursos = [],
  itensRecurso = [],
  profile,
}) {
  const [mostrarForm, setMostrarForm] = useState(false);
  const [recursoSelecionado, setRecursoSelecionado] = useState("");
  const [filtroStatus, setFiltroStatus] = useState("PENDENTES"); // 'PENDENTES' | 'RESOLVIDOS' | 'TODOS'
  const [isPending, startTransition] = useTransition();
  const toast = useToast();

  const isGestor = ["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"].includes(profile.role);

  // Itens do recurso selecionado no formulário
  const itensDoRecursoSelecionado = itensRecurso.filter(
    (i) => i.recurso_id === recursoSelecionado
  );
  const temItensNoBanco = itensDoRecursoSelecionado.length > 0;

  const filtrados = incidentes.filter((inc) => {
    if (filtroStatus === "PENDENTES" && inc.resolvido) return false;
    if (filtroStatus === "RESOLVIDOS" && !inc.resolvido) return false;
    return true;
  });

  const totalPendentes = incidentes.filter((i) => !i.resolvido).length;

  function handleResolver(inc) {
    startTransition(async () => {
      const res = await resolverIncidente(inc.id, inc.recurso_id);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Incidente resolvido.");
    });
  }

  return (
    <div className="space-y-6">
      {/* Barra de Ações Superior */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white">Registro de Zelo & Avarias</h2>
          <p className="text-xs text-slate-400">
            {totalPendentes} {totalPendentes === 1 ? "avaria pendente" : "avarias pendentes"} de manutenção
          </p>
        </div>

        <button
          type="button"
          onClick={() => setMostrarForm(!mostrarForm)}
          className="flex items-center justify-center gap-1.5 rounded-xl btn-primary px-4 py-2.5 text-xs font-semibold"
        >
          {mostrarForm ? <X className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
          {mostrarForm ? "Cancelar" : "Reportar Defeito"}
        </button>
      </div>

      {/* Formulário de Reporte de Avaria */}
      {mostrarForm && (
        <div className="panel border-amber-500/30 bg-surface-overlay/90 p-5 animate-fade-in space-y-4">
          <SectionHeader icon={Wrench}>Reportar Defeito em Equipamento</SectionHeader>
          <p className="text-xs text-slate-400">
            Ao reportar um defeito, o recurso entrará automaticamente em status de manutenção parcial.
          </p>

          <ActionForm
            action={reportarIncidente}
            resetOnSuccess
            onSuccess={() => { setMostrarForm(false); setRecursoSelecionado(""); }}
            className="grid gap-4 sm:grid-cols-2"
          >
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Recurso / Carrinho / Lab *
              </label>
              <select
                name="recurso_id"
                required
                value={recursoSelecionado}
                onChange={(e) => setRecursoSelecionado(e.target.value)}
                className="w-full rounded-xl border border-surface-border bg-surface-base px-3.5 py-2.5 text-xs text-white outline-none focus:border-brand-500"
              >
                <option value="">Selecione o recurso...</option>
                {recursos.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.nome}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Equipamento com defeito *
              </label>
              {temItensNoBanco ? (
                // Dropdown de itens cadastrados no banco
                <select
                  name="numero_equipamento"
                  required
                  className="w-full rounded-xl border border-surface-border bg-surface-base px-3.5 py-2.5 text-xs text-white outline-none focus:border-brand-500"
                >
                  <option value="">Selecione o equipamento...</option>
                  {itensDoRecursoSelecionado.map((item) => (
                    <option key={item.id} value={item.numero_patrimonio}>
                      {item.numero_patrimonio}
                      {item.descricao ? ` — ${item.descricao}` : ""}
                      {item.status !== "DISPONIVEL" ? " ⚠ em manutenção" : ""}
                    </option>
                  ))}
                </select>
              ) : (
                // Campo de texto livre (recurso sem itens cadastrados)
                <input
                  name="numero_equipamento"
                  type="text"
                  required
                  autoComplete="off"
                  data-lpignore="true"
                  placeholder="Ex: Notebook 07, Teclado 3, Cabo B"
                  className="w-full rounded-xl border border-surface-border bg-surface-base px-3.5 py-2.5 text-xs text-white outline-none focus:border-brand-500 placeholder:text-slate-500"
                />
              )}
              {recursoSelecionado && !temItensNoBanco && (
                <p className="mt-1 text-[10px] text-slate-500">
                  Dica: cadastre os itens individuais em Recursos para ter seleção precisa aqui.
                </p>
              )}
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Descrição do Problema *
              </label>
              <textarea
                name="descricao"
                required
                rows={3}
                autoComplete="off"
                data-lpignore="true"
                placeholder="Descreva o que ocorreu (ex: tela não liga, tecla quebrada, cabo de força rompido)..."
                className="w-full rounded-xl border border-surface-border bg-surface-base px-3.5 py-2.5 text-xs text-white outline-none focus:border-brand-500 placeholder:text-slate-500"
              />
            </div>

            <div className="flex items-center gap-2 sm:col-span-2">
              <button type="submit" className="btn-primary">
                Enviar Reporte
              </button>
              <button
                type="button"
                onClick={() => setMostrarForm(false)}
                className="rounded-xl border border-surface-border px-4 py-2 text-xs text-slate-400 hover:bg-surface-raised"
              >
                Cancelar
              </button>
            </div>
          </ActionForm>
        </div>
      )}

      {/* Filtros de Status */}
      <div className="flex items-center gap-2 border-b border-surface-border pb-3">
        <button
          type="button"
          onClick={() => setFiltroStatus("PENDENTES")}
          className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
            filtroStatus === "PENDENTES"
              ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
              : "text-slate-400 hover:text-slate-200"
          }`}
        >
          Abertos / Em Manutenção ({totalPendentes})
        </button>

        <button
          type="button"
          onClick={() => setFiltroStatus("RESOLVIDOS")}
          className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
            filtroStatus === "RESOLVIDOS"
              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
              : "text-slate-400 hover:text-slate-200"
          }`}
        >
          Resolvidos ({incidentes.length - totalPendentes})
        </button>

        <button
          type="button"
          onClick={() => setFiltroStatus("TODOS")}
          className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${
            filtroStatus === "TODOS"
              ? "bg-surface-overlay text-white"
              : "text-slate-400 hover:text-slate-200"
          }`}
        >
          Histórico Completo
        </button>
      </div>

      {/* Lista de Incidentes */}
      <div className="space-y-3">
        {filtrados.length > 0 ? (
          filtrados.map((inc) => {
            const dataFormatada = new Date(inc.created_at).toLocaleDateString("pt-BR", {
              day: "2-digit",
              month: "2-digit",
              year: "numeric",
              hour: "2-digit",
              minute: "2-digit",
            });

            return (
              <div
                key={inc.id}
                className={`panel p-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between transition ${
                  inc.resolvido
                    ? "opacity-70 border-surface-border/60"
                    : "border-amber-500/30 bg-amber-500/5"
                }`}
              >
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-bold text-white">
                      {inc.recurso?.nome || "Recurso"} — {inc.numero_equipamento}
                    </span>

                    {inc.resolvido ? (
                      <span className="flex items-center gap-1 rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-semibold text-emerald-300 border border-emerald-500/30">
                        <CheckCircle2 className="h-3 w-3" /> Resolvido
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 rounded-full bg-amber-500/20 px-2 py-0.5 text-[10px] font-semibold text-amber-300 border border-amber-500/30">
                        <AlertTriangle className="h-3 w-3" /> Manutenção Pendente
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-300">{inc.descricao}</p>

                  <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-0.5">
                    <span>Reportado por: {inc.reportado_por_usuario?.nome_completo || inc.reportado_por_usuario?.email || "Docente"}</span>
                    <span>·</span>
                    <span>{dataFormatada}</span>
                  </div>
                </div>

                {isGestor && !inc.resolvido && (
                  <button
                    type="button"
                    disabled={isPending}
                    onClick={() => handleResolver(inc)}
                    className="flex items-center gap-1.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3.5 py-2 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/20 transition disabled:opacity-50 self-start sm:self-auto"
                  >
                    {isPending ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Check className="h-3.5 w-3.5" />
                    )}
                    Marcar como Resolvido
                  </button>
                )}
              </div>
            );
          })
        ) : (
          <div className="panel py-12 text-center space-y-2">
            <CheckCircle2 className="mx-auto h-8 w-8 text-emerald-400" />
            <p className="text-sm font-semibold text-white">Nenhuma avaria pendente</p>
            <p className="text-xs text-slate-400">
              Todos os carrinhos e laboratórios estão em perfeito estado de funcionamento.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
