"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";

export async function reportarIncidente(prevState, formData) {
  const profile = await getCurrentProfile();
  if (!profile || !profile.escola_id) {
    return { error: "Usuário não vinculado a uma escola." };
  }

  const supabase = createClient();

  const recurso_id = formData.get("recurso_id")?.toString();
  const numero_equipamento = formData.get("numero_equipamento")?.toString().trim();
  const descricao = formData.get("descricao")?.toString().trim();
  const reserva_id = formData.get("reserva_id")?.toString() || null;

  if (!recurso_id || !numero_equipamento || !descricao) {
    return { error: "Informe o recurso, o número do equipamento e a descrição do defeito." };
  }

  const { error } = await supabase.from("incidentes").insert({
    recurso_id,
    numero_equipamento,
    descricao,
    reserva_id,
    reportado_por: profile.id,
    resolvido: false,
  });

  if (error) return { error: error.message };

  revalidatePath("/incidentes");
  revalidatePath("/gestor/recursos");
  revalidatePath("/reservas");
  revalidatePath("/");
  return { success: "Incidente reportado com sucesso. A equipe gestora foi notificada." };
}

export async function resolverIncidente(incidenteId, recursoId) {
  const profile = await getCurrentProfile();
  if (!profile) return { error: "Não autenticado." };

  const isGestor = ["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"].includes(profile.role);
  if (!isGestor) {
    return { error: "Apenas diretores e gestores podem resolver incidentes." };
  }

  const supabase = createClient();

  const { error } = await supabase
    .from("incidentes")
    .update({ resolvido: true })
    .eq("id", incidenteId);

  if (error) return { error: error.message };

  // Verifica se ainda existem incidentes não resolvidos para este recurso
  if (recursoId) {
    const { data: pendentes } = await supabase
      .from("incidentes")
      .select("id")
      .eq("recurso_id", recursoId)
      .eq("resolvido", false);

    // Se não há mais incidentes abertos, restaura o recurso para DISPONIVEL
    if (!pendentes || pendentes.length === 0) {
      await supabase
        .from("recursos")
        .update({ status: "DISPONIVEL" })
        .eq("id", recursoId)
        .eq("status", "MANUTENCAO_PARCIAL");
    }
  }

  revalidatePath("/incidentes");
  revalidatePath("/gestor/recursos");
  revalidatePath("/reservas");
  revalidatePath("/");
  return { success: "Incidente marcado como resolvido!" };
}
