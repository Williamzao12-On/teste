﻿import { getCurrentProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import IncidentesManager from "./IncidentesManager";
import { AlertTriangle } from "lucide-react";

export default async function IncidentesPage() {
  const profile = await getCurrentProfile();

  if (!profile?.escola_id && profile?.role !== "ADMIN") {
    return (
      <div className="panel p-6 border-amber-500/30 bg-amber-500/10 space-y-2">
        <div className="flex items-center gap-2 text-amber-400 font-semibold text-sm">
          <AlertTriangle className="h-5 w-5" />
          Escola não vinculada
        </div>
        <p className="text-xs text-slate-300">
          Você precisa estar vinculado a uma escola para acessar o livro de zelo e incidentes.
        </p>
      </div>
    );
  }

  const supabase = createClient();
  const escolaId = profile.escola_id;

  const [{ data: incidentes }, { data: recursos }, { data: itensRecurso }] = await Promise.all([
    supabase
      .from("incidentes")
      .select(
        "id, recurso_id, reserva_id, numero_equipamento, descricao, resolvido, created_at, recurso:recurso_id(id, nome, escola_id), reportado_por_usuario:reportado_por(id, nome_completo, email)"
      )
      .eq("recurso.escola_id", escolaId)
      .order("created_at", { ascending: false }),
    supabase.from("recursos").select("id, nome, tipo").eq("escola_id", escolaId).order("nome"),
    supabase
      .from("itens_recurso")
      .select("id, recurso_id, numero_patrimonio, descricao, status")
      .order("numero_patrimonio"),
  ]);

  return (
    <div className="space-y-6">
      <header>
        <div className="flex items-center gap-2 text-amber-400 text-xs font-semibold uppercase tracking-wider mb-1">
          <AlertTriangle className="h-4 w-4" />
          Zelo &amp; Manutencao
        </div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Livro de Incidentes</h1>
        <p className="text-sm text-slate-400">
          Reporte e acompanhe avarias em notebooks, cabos e salas para rapida manutencao tecnica.
        </p>
      </header>

      <IncidentesManager
        incidentes={incidentes || []}
        recursos={recursos || []}
        itensRecurso={itensRecurso || []}
        profile={profile}
      />
    </div>
  );
}