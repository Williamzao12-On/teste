"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";

export async function atualizarMeuPerfil(prevState, formData) {
  const profile = await getCurrentProfile();
  if (!profile) return { error: "Sessão expirada. Faça login novamente." };

  const nome_completo = formData.get("nome_completo")?.toString().trim() || null;
  const telefone_whatsapp = formData.get("telefone_whatsapp")?.toString().trim() || null;

  // Validação simples de formato — não trava por excesso de zelo, só evita
  // erros óbvios de digitação (letras, tamanho absurdo etc).
  if (telefone_whatsapp && !/^[\d\s()+-]{8,20}$/.test(telefone_whatsapp)) {
    return { error: "Número de WhatsApp inválido. Use só números, espaços e (), +, -." };
  }

  const supabase = createClient();

  // Nunca aceita campos além destes dois — email, role e escola_id continuam
  // fora do alcance do próprio usuário, mesmo que alguém tente injetar no
  // FormData por fora do formulário.
  const { error } = await supabase
    .from("profiles")
    .update({ nome_completo, telefone_whatsapp })
    .eq("id", profile.id);

  if (error) return { error: error.message };

  revalidatePath("/perfil");
  revalidatePath("/"); // a sidebar mostra o nome, então atualiza ali também
  return { success: "Perfil atualizado." };
}
