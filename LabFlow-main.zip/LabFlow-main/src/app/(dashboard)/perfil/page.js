import { getCurrentProfile, ROLE_LABELS } from "@/lib/auth";
import { atualizarMeuPerfil } from "./actions";
import ActionForm from "@/components/ActionForm";
import SectionHeader from "@/components/SectionHeader";
import { User, Mail, Phone, ShieldCheck, MessageCircle } from "lucide-react";

export default async function PerfilPage() {
  const profile = await getCurrentProfile();

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-white">Meu Perfil</h1>
        <p className="text-slate-400">Seus dados pessoais na plataforma.</p>
      </header>

      <section className="panel">
        <SectionHeader icon={User}>Dados pessoais</SectionHeader>

        <ActionForm
          action={atualizarMeuPerfil}
          successMessage="Perfil atualizado."
          className="grid gap-4 sm:grid-cols-2"
        >
          <Field label="Nome completo">
            <input
              name="nome_completo"
              type="text"
              defaultValue={profile?.nome_completo || ""}
              placeholder="Seu nome completo"
              className={inputClass}
            />
          </Field>

          <Field label="Número de WhatsApp (opcional)">
            <div className="relative">
              <MessageCircle className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
              <input
                name="telefone_whatsapp"
                type="tel"
                defaultValue={profile?.telefone_whatsapp || ""}
                placeholder="(11) 91234-5678"
                className={`${inputClass} pl-10`}
              />
            </div>
          </Field>

          <div className="sm:col-span-2">
            <button
              type="submit"
              className="btn-primary"
            >
              Salvar alterações
            </button>
          </div>
        </ActionForm>

        <p className="mt-4 flex items-start gap-2 text-xs text-slate-500">
          <MessageCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          O número de WhatsApp é opcional e será usado futuramente para notificações de reserva
          (o canal exato — WhatsApp ou aviso dentro do próprio site — ainda está em definição).
        </p>
      </section>

      <section className="panel">
        <SectionHeader icon={ShieldCheck}>Acesso</SectionHeader>

        <div className="space-y-3 text-sm">
          <InfoRow icon={Mail} label="E-mail" value={profile?.email} />
          <InfoRow
            icon={ShieldCheck}
            label="Papel"
            value={ROLE_LABELS[profile?.role] || profile?.role}
          />
          <InfoRow icon={User} label="Escola" value={profile?.escolas?.nome || "Não vinculado"} />
        </div>

        <p className="mt-4 text-xs text-slate-500">
          O e-mail é o seu identificador de login e não pode ser alterado por aqui. Se precisar
          trocar, fale com o Administrador do sistema.
        </p>
      </section>
    </div>
  );
}

const inputClass =
  "w-full rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2.5 text-sm text-white outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4";

function Field({ label, children }) {
  return (
    <label className="block text-sm">
      <span className="mb-1.5 block font-medium text-slate-300">{label}</span>
      {children}
    </label>
  );
}

function InfoRow({ icon: Icon, label, value }) {
  return (
    <div className="flex items-center gap-3 border-b border-surface-border pb-3 last:border-0 last:pb-0">
      <Icon className="h-4 w-4 shrink-0 text-slate-500" />
      <span className="w-20 shrink-0 text-slate-400">{label}</span>
      <span className="font-medium text-slate-100">{value}</span>
    </div>
  );
}
