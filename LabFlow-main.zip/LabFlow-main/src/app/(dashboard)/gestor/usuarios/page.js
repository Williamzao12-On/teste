import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { atualizarPapelDocente, convidarDocente } from "../actions";
import { Users2, UserPlus, Mail, ShieldCheck, X } from "lucide-react";
import GestorTabs from "../GestorTabs";
import { ROLE_LABELS } from "@/lib/roles";
import ActionForm from "@/components/ActionForm";
import SectionHeader from "@/components/SectionHeader";

export default async function UsuariosPage() {
  const profile = await requireRole(["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"]);
  const supabase = createClient();

  const { data: docentes } = await supabase
    .from("profiles")
    .select("*")
    .eq("escola_id", profile.escola_id)
    .neq("role", "ADMIN")
    .order("nome_completo");

  const ativos = docentes?.filter((d) => d.ativo !== false) ?? [];
  const inativos = docentes?.filter((d) => d.ativo === false) ?? [];

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-white">Usuários da Escola</h1>
        <p className="text-slate-400">
          Convide docentes e gerencie papéis e permissões da equipe.
        </p>
      </header>

      <GestorTabs current="usuarios" />

      {/* Painel de convite */}
      <section className="panel border-brand-500/20 bg-brand-600/5">
        <SectionHeader icon={UserPlus}>Convidar Docente / Gestor</SectionHeader>
        <p className="mb-4 text-xs text-slate-400">
          O convidado receberá um e-mail com link de acesso. A escola já fica vinculada automaticamente.
        </p>
        <ActionForm
          action={convidarDocente}
          resetOnSuccess
          className="grid gap-4 sm:grid-cols-3"
        >
          <label className="block text-sm">
            <span className="mb-1.5 block font-medium text-slate-300">Nome completo</span>
            <input
              name="nome"
              autoComplete="off"
              data-lpignore="true"
              placeholder="Maria da Silva"
              className="w-full rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2.5 text-sm text-white outline-none focus:border-brand-500"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1.5 block font-medium text-slate-300">E-mail *</span>
            <input
              name="email"
              type="email"
              required
              autoComplete="off"
              data-lpignore="true"
              placeholder="prof@escola.sp.gov.br"
              className="w-full rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2.5 text-sm text-white outline-none focus:border-brand-500"
            />
          </label>
          <label className="block text-sm">
            <span className="mb-1.5 block font-medium text-slate-300">Papel *</span>
            <select
              name="role"
              className="w-full rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2.5 text-sm text-white outline-none focus:border-brand-500"
            >
              <option value="DOCENTE">{ROLE_LABELS.DOCENTE}</option>
              <option value="DOCENTE_DS">{ROLE_LABELS.DOCENTE_DS}</option>
              <option value="GESTOR_ESCOLAR">{ROLE_LABELS.GESTOR_ESCOLAR}</option>
            </select>
          </label>
          <div className="sm:col-span-3">
            <button type="submit" className="btn-primary">
              <Mail className="inline h-4 w-4 mr-1.5 -mt-0.5" />
              Enviar Convite
            </button>
          </div>
        </ActionForm>
      </section>

      {/* Lista de usuários ativos */}
      <section className="panel">
        <SectionHeader icon={Users2}>
          Equipe ativa ({ativos.length})
        </SectionHeader>
        <div className="space-y-2">
          {ativos.length ? (
            ativos.map((d) => <DocenteRow key={d.id} docente={d} />)
          ) : (
            <p className="py-4 text-center text-sm text-slate-400">
              Nenhum usuário ativo. Convide o primeiro docente acima.
            </p>
          )}
        </div>
      </section>

      {/* Lista de usuários inativos (dobrado por padrão) */}
      {inativos.length > 0 && (
        <details className="panel group">
          <summary className="flex cursor-pointer items-center gap-2 text-sm font-medium text-slate-400 select-none">
            <X className="h-4 w-4" />
            Inativos ({inativos.length})
          </summary>
          <div className="mt-4 space-y-2">
            {inativos.map((d) => <DocenteRow key={d.id} docente={d} />)}
          </div>
        </details>
      )}
    </div>
  );
}

function DocenteRow({ docente: d }) {
  return (
    <ActionForm
      action={atualizarPapelDocente}
      successMessage="Docente atualizado."
      className="flex flex-col gap-3 rounded-xl border border-surface-border p-4 sm:flex-row sm:items-center hover:border-surface-border/80 transition"
    >
      <input type="hidden" name="id" value={d.id} />

      {/* Avatar / Iniciais */}
      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-600/20 text-sm font-bold text-brand-400 uppercase select-none">
        {(d.nome_completo || d.email || "?")[0]}
      </div>

      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-slate-100 truncate">
          {d.nome_completo || "(sem nome)"}
        </p>
        <p className="text-xs text-slate-400 truncate">{d.email}</p>
      </div>

      <div className="flex flex-wrap items-center gap-2">
        <select
          name="role"
          defaultValue={d.role}
          className="rounded-xl border border-surface-border bg-surface-overlay px-3 py-2 text-xs text-white"
        >
          <option value="DOCENTE">{ROLE_LABELS.DOCENTE}</option>
          <option value="DOCENTE_DS">{ROLE_LABELS.DOCENTE_DS}</option>
          <option value="GESTOR_ESCOLAR">{ROLE_LABELS.GESTOR_ESCOLAR}</option>
          <option value="DIRETOR">{ROLE_LABELS.DIRETOR}</option>
        </select>

        <label className="flex items-center gap-1.5 text-xs text-slate-400 whitespace-nowrap">
          <input
            type="checkbox"
            name="is_ds_authorized"
            defaultChecked={d.is_ds_authorized}
            className="h-4 w-4 rounded"
          />
          <ShieldCheck className="h-3.5 w-3.5" />
          Auth DS
        </label>

        <button type="submit" className="btn-primary-compact">
          Salvar
        </button>
      </div>
    </ActionForm>
  );
}