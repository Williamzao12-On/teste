"use client";

import { useState } from "react";
import { criarTurma } from "../actions";
import ActionForm from "@/components/ActionForm";
import {
  ETAPA_LABELS,
  SERIES_POR_ETAPA,
  precisaDescricaoLivre,
  placeholderDescricaoLivre,
} from "@/lib/etapas";

const TURNO_LABELS = { MANHA: "Manhã", TARDE: "Tarde", NOITE: "Noite", INTEGRAL: "Integral" };
const anoAtual = new Date().getFullYear();

export default function TurmaForm({ etapasDisponiveis }) {
  const [etapa, setEtapa] = useState(etapasDisponiveis[0] || "");
  const livre = precisaDescricaoLivre(etapa);
  const seriesFixas = SERIES_POR_ETAPA[etapa] || [];

  if (!etapasDisponiveis.length) {
    return (
      <p className="text-sm text-slate-400">
        Sua escola ainda não tem nenhuma modalidade de ensino configurada. Peça ao Administrador
        do sistema pra marcar isso no cadastro da escola antes de criar turmas.
      </p>
    );
  }

  return (
    <ActionForm
      action={criarTurma}
      successMessage="Turma cadastrada."
      className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5"
    >
      <Field label="Ano letivo">
        <input
          name="ano_letivo"
          type="number"
          defaultValue={anoAtual}
          required
          className={inputClass}
        />
      </Field>

      <Field label="Etapa">
        <select
          name="etapa"
          value={etapa}
          onChange={(e) => setEtapa(e.target.value)}
          required
          className={inputClass}
        >
          {etapasDisponiveis.map((value) => (
            <option key={value} value={value}>
              {ETAPA_LABELS[value]}
            </option>
          ))}
        </select>
      </Field>

      <Field label="Série" className={livre ? "lg:col-span-2" : ""}>
        {livre ? (
          <input
            name="serie"
            type="text"
            required
            placeholder={placeholderDescricaoLivre(etapa)}
            className={inputClass}
          />
        ) : (
          <select name="serie" required className={inputClass} defaultValue="">
            <option value="" disabled>
              Selecione…
            </option>
            {seriesFixas.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        )}
      </Field>

      <Field label={livre ? "Sala/Turma" : "Turma"}>
        <input
          name="identificador"
          type="text"
          required
          placeholder={livre ? "Sala 1" : "A"}
          className={inputClass}
        />
      </Field>

      <Field label="Turno">
        <select name="turno" required className={inputClass}>
          {Object.entries(TURNO_LABELS).map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </select>
      </Field>

      <div className="sm:col-span-2 lg:col-span-5">
        <button
          type="submit"
          className="btn-primary"
        >
          Cadastrar turma
        </button>
      </div>
    </ActionForm>
  );
}

const inputClass =
  "w-full rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2.5 text-sm text-white outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4";

function Field({ label, children, className = "" }) {
  return (
    <label className={`block text-sm ${className}`}>
      <span className="mb-1.5 block font-medium text-slate-300">{label}</span>
      {children}
    </label>
  );
}
