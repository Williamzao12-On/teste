import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { GraduationCap, ListChecks } from "lucide-react";
import GestorTabs from "../GestorTabs";
import { ETAPA_LABELS } from "@/lib/etapas";
import TurmaForm from "./TurmaForm";
import ToggleAtivoTurma from "./ToggleAtivoTurma";
import SectionHeader from "@/components/SectionHeader";

const TURNO_LABELS = { MANHA: "Manhã", TARDE: "Tarde", NOITE: "Noite", INTEGRAL: "Integral" };

export default async function TurmasPage() {
  const profile = await requireRole(["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"]);
  const supabase = createClient();

  const [{ data: escola }, { data: turmas }] = await Promise.all([
    supabase
      .from("escolas")
      .select("modalidades_ensino")
      .eq("id", profile.escola_id)
      .single(),
    supabase
      .from("turmas")
      .select("*")
      .eq("escola_id", profile.escola_id)
      .order("ano_letivo", { ascending: false })
      .order("serie"),
  ]);

  const etapasDisponiveis = escola?.modalidades_ensino || [];

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-white">Séries & Turmas</h1>
        <p className="text-slate-400">
          O &quot;destino&quot; de cada reserva. Recadastre a cada início de ano letivo.
        </p>
      </header>

      <GestorTabs current="turmas" />

      {/* Formulário */}
      <section className="panel">
        <SectionHeader icon={GraduationCap}>Cadastrar turma</SectionHeader>
        <TurmaForm etapasDisponiveis={etapasDisponiveis} />
      </section>

      {/* Lista */}
      <section className="panel">
        <SectionHeader icon={ListChecks}>
          Turmas cadastradas ({turmas?.length || 0})
        </SectionHeader>

        <div className="divide-y divide-surface-border">
          {turmas?.length ? (
            turmas.map((t) => (
              <div key={t.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="font-medium text-slate-100">
                    {t.serie} {t.identificador}
                    <span className="ml-2 text-xs font-normal text-slate-400">
                      {t.ano_letivo}
                    </span>
                  </p>
                  <p className="text-xs text-slate-400">
                    {ETAPA_LABELS[t.etapa]} · {TURNO_LABELS[t.turno]}
                  </p>
                </div>

                <ToggleAtivoTurma turmaId={t.id} ativo={t.ativo} />
              </div>
            ))
          ) : (
            <p className="py-4 text-sm text-slate-400">Nenhuma turma cadastrada ainda.</p>
          )}
        </div>
      </section>
    </div>
  );
}
