"use client";

import { useTransition } from "react";
import { alternarAtivoTurma } from "../actions";
import { useToast } from "@/components/ToastProvider";

export default function ToggleAtivoTurma({ turmaId, ativo }) {
  const [isPending, startTransition] = useTransition();
  const toast = useToast();

  function handleClick() {
    const formData = new FormData();
    formData.set("id", turmaId);
    formData.set("ativo", String(ativo));

    startTransition(async () => {
      const res = await alternarAtivoTurma(null, formData);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Turma atualizada.");
    });
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={isPending}
      className={
        ativo
          ? "rounded-full bg-green-500/15 px-3 py-1 text-xs font-medium text-green-400 disabled:opacity-50"
          : "rounded-full bg-surface-overlay px-3 py-1 text-xs font-medium text-slate-400 disabled:opacity-50"
      }
    >
      {ativo ? "Ativa" : "Inativa"}
    </button>
  );
}
