import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { criarRecurso } from "../actions";
import { Laptop, MonitorSmartphone, Lock, Info } from "lucide-react";
import GestorTabs from "../GestorTabs";
import StatusRecursoForm from "./StatusRecursoForm";
import { RecursoCard } from "./RecursoCard";
import ActionForm from "@/components/ActionForm";
import SectionHeader from "@/components/SectionHeader";

const TIPO_LABELS = {
  CARRINHO_NOTEBOOK: "Carrinho de Notebook",
  LABORATORIO_INFORMATICA: "Laboratório de Informática",
  TABLET: "Carrinho de Tablet",
  CHROMEBOOK: "Carrinho de Chromebook",
  OUTRO: "Outro",
};

export default async function RecursosPage() {
  const profile = await requireRole(["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"]);
  const supabase = createClient();

  const [{ data: recursos }, { data: itens }] = await Promise.all([
    supabase
      .from("recursos")
      .select("*")
      .eq("escola_id", profile.escola_id)
      .order("tipo")
      .order("nome"),
    supabase
      .from("itens_recurso")
      .select("*")
      .in(
        "recurso_id",
        // será []  se não houver recursos (evita erro)
        []
      ),
  ]);

  // Re-query itens filtrado pelos recursos da escola (query mais segura)
  let itensData = [];
  if (recursos && recursos.length > 0) {
    const recursoIds = recursos.map((r) => r.id);
    const { data } = await supabase
      .from("itens_recurso")
      .select("*")
      .in("recurso_id", recursoIds)
      .order("numero_patrimonio");
    itensData = data ?? [];
  }

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-white">Carrinhos &amp; Laboratórios</h1>
        <p className="text-slate-400">Recursos físicos disponíveis para reserva por horário.</p>
      </header>

      <GestorTabs current="recursos" />

      {/* Formulário de cadastro */}
      <section className="panel">
        <SectionHeader icon={Laptop}>Cadastrar novo recurso</SectionHeader>
        <ActionForm
          action={criarRecurso}
          successMessage="Recurso cadastrado."
          resetOnSuccess
          className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4"
        >
          <FieldSelect name="tipo" label="Tipo" required>
            {Object.entries(TIPO_LABELS).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </FieldSelect>

          <FieldInput name="nome" label="Nome / Identificação" required placeholder="Carrinho 01" />

          <FieldInput
            name="quantidade_itens"
            label="Qtd. total de equipamentos"
            type="number"
            min="1"
            defaultValue="1"
            required
          />

          <FieldInput
            name="localizacao"
            label="Localização (opcional)"
            placeholder="Sala de recursos / Bloco B"
          />

          <label className="flex items-center gap-2 text-sm text-slate-300 lg:col-span-4">
            <input type="checkbox" name="exclusivo_ds" className="h-4 w-4 rounded" />
            <Lock className="h-3.5 w-3.5" />
            Uso exclusivo do curso técnico de Desenvolvimento de Sistemas
          </label>

          <div className="lg:col-span-4">
            <button type="submit" className="btn-primary">
              Cadastrar recurso
            </button>
          </div>
        </ActionForm>
      </section>

      {/* Lista de recursos com itens modulares */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <SectionHeader icon={MonitorSmartphone}>
            Recursos cadastrados ({recursos?.length ?? 0})
          </SectionHeader>
          <div className="flex items-center gap-1.5 text-xs text-slate-500">
            <Info className="h-3.5 w-3.5" />
            Clique em &ldquo;Itens&rdquo; para gerenciar equipamentos individuais
          </div>
        </div>

        {recursos?.length ? (
          recursos.map((r) => (
            <RecursoCard key={r.id} recurso={r} itens={itensData} />
          ))
        ) : (
          <div className="panel py-12 text-center space-y-2">
            <MonitorSmartphone className="mx-auto h-8 w-8 text-slate-600" />
            <p className="text-sm font-semibold text-white">Nenhum recurso cadastrado ainda</p>
            <p className="text-xs text-slate-400">
              Adicione carrinhos de notebook, laboratórios ou outros recursos acima.
            </p>
          </div>
        )}
      </section>
    </div>
  );
}

function FieldInput({ name, label, required, placeholder, type = "text", min, defaultValue }) {
  return (
    <label className="block text-sm">
      <span className="mb-1.5 block font-medium text-slate-300">{label}</span>
      <input
        name={name}
        type={type}
        min={min}
        required={required}
        placeholder={placeholder}
        defaultValue={defaultValue}
        autoComplete="off"
        data-lpignore="true"
        className="w-full rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2.5 text-sm text-white outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4"
      />
    </label>
  );
}

function FieldSelect({ name, label, required, children }) {
  return (
    <label className="block text-sm">
      <span className="mb-1.5 block font-medium text-slate-300">{label}</span>
      <select
        name={name}
        required={required}
        className="w-full rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2.5 text-sm text-white outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4"
      >
        {children}
      </select>
    </label>
  );
}