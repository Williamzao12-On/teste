﻿"use client";

import { useState, useTransition } from "react";
import ActionForm from "@/components/ActionForm";
import { useToast } from "@/components/ToastProvider";
import {
  criarItemRecurso,
  excluirItemRecurso,
  atualizarStatusItem,
  editarRecurso,
  gerarItensEmLote,
  limparERegenerarItens,
} from "../actions";
import {
  Plus,
  X,
  Trash2,
  Wrench,
  CheckCircle2,
  Loader2,
  ChevronDown,
  ChevronUp,
  Package,
  Lock,
  PencilLine,
  Sparkles,
  RotateCcw,
} from "lucide-react";

const STATUS_LABELS = {
  DISPONIVEL: { label: "Disponível", color: "text-emerald-400 bg-emerald-500/10 border-emerald-500/30" },
  MANUTENCAO_PARCIAL: { label: "Manutenção Parcial", color: "text-amber-400 bg-amber-500/10 border-amber-500/30" },
  MANUTENCAO_TOTAL: { label: "Manutenção Total", color: "text-red-400 bg-red-500/10 border-red-500/30" },
  INATIVO: { label: "Inativo", color: "text-slate-400 bg-slate-500/10 border-slate-500/30" },
};

const TIPO_LABELS = {
  CARRINHO_NOTEBOOK: "Carrinho de Notebook",
  LABORATORIO_INFORMATICA: "Laboratório de Informática",
  TABLET: "Carrinho de Tablet",
  CHROMEBOOK: "Carrinho de Chromebook",
  OUTRO: "Outro",
};

const TIPOS_COM_ITENS = ["CARRINHO_NOTEBOOK", "TABLET", "CHROMEBOOK", "LABORATORIO_INFORMATICA", "OUTRO"];

export function RecursoCard({ recurso, itens = [] }) {
  const [expandido, setExpandido] = useState(false);
  const [editando, setEditando] = useState(false);
  const [adicionandoItem, setAdicionandoItem] = useState(false);
  const [isPending, startTransition] = useTransition();
  const toast = useToast();

  const temItens = TIPOS_COM_ITENS.includes(recurso.tipo);
  const itensDoRecurso = itens.filter((i) => i.recurso_id === recurso.id);
  const avariados = itensDoRecurso.filter((i) => i.status !== "DISPONIVEL").length;
  const st = STATUS_LABELS[recurso.status] ?? STATUS_LABELS.DISPONIVEL;
  const totalEsperado = recurso.quantidade_itens || 1;

  function handleExcluirItem(itemId) {
    startTransition(async () => {
      const res = await excluirItemRecurso(itemId);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success);
    });
  }

  function handleStatusItem(itemId, novoStatus) {
    startTransition(async () => {
      const res = await atualizarStatusItem(itemId, novoStatus);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success);
    });
  }

  function handleGerarItensEmLote() {
    startTransition(async () => {
      const res = await gerarItensEmLote(recurso.id);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success);
    });
  }

  function handleRegenerarItens() {
    if (!window.confirm(`Deseja reiniciar a numeração de 1 a ${totalEsperado}? Itens existentes serão recriados como disponíveis.`)) {
      return;
    }
    startTransition(async () => {
      const res = await limparERegenerarItens(recurso.id);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success);
    });
  }

  return (
    <div className="rounded-2xl border border-surface-border bg-surface-raised overflow-hidden">
      {/* Cabeçalho do recurso */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4">
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-semibold text-slate-100 text-sm">{recurso.nome}</span>
            {recurso.exclusivo_ds && (
              <span className="flex items-center gap-1 rounded-full bg-brand-500/10 px-2 py-0.5 text-[10px] font-semibold text-brand-400 border border-brand-500/30">
                <Lock className="h-2.5 w-2.5" /> Exclusivo DS
              </span>
            )}
            <span className={`rounded-full border px-2 py-0.5 text-[10px] font-semibold ${st.color}`}>
              {st.label}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {TIPO_LABELS[recurso.tipo]} · {totalEsperado} unid. total
            {recurso.localizacao ? ` · ${recurso.localizacao}` : ""}
          </p>
          {temItens && (
            <p className="text-[11px] text-slate-500 mt-0.5">
              {itensDoRecurso.length} de {totalEsperado} computadores cadastrados
              {avariados > 0 ? (
                <span className="text-amber-400 font-medium"> · {avariados} com defeito/manutenção</span>
              ) : (
                <span className="text-emerald-400 font-medium"> · todos em perfeito estado</span>
              )}
            </p>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setEditando(!editando)}
            className="rounded-lg border border-surface-border p-2 text-slate-400 hover:text-white hover:bg-surface-overlay transition"
            title="Editar recurso"
          >
            <PencilLine className="h-4 w-4" />
          </button>
          {temItens && (
            <button
              type="button"
              onClick={() => setExpandido(!expandido)}
              className="flex items-center gap-1.5 rounded-lg border border-surface-border px-3 py-2 text-xs font-medium text-slate-300 hover:text-white hover:bg-surface-overlay transition"
            >
              <Package className="h-3.5 w-3.5 text-brand-400" />
              Equipamentos ({itensDoRecurso.length})
              {expandido ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
            </button>
          )}
        </div>
      </div>

      {/* Formulário de edição inline */}
      {editando && (
        <div className="border-t border-surface-border bg-surface-overlay/50 p-4 space-y-3">
          <p className="text-xs font-semibold text-slate-300">Editar recurso</p>
          <ActionForm
            action={editarRecurso}
            resetOnSuccess
            onSuccess={() => setEditando(false)}
            className="grid gap-3 sm:grid-cols-3"
          >
            <input type="hidden" name="id" value={recurso.id} />
            <label className="block text-xs">
              <span className="mb-1 block text-slate-400">Nome / Identificação</span>
              <input
                name="nome"
                required
                autoComplete="off"
                data-lpignore="true"
                defaultValue={recurso.nome}
                className="w-full rounded-xl border border-surface-border bg-surface-base px-3 py-2 text-xs text-white outline-none focus:border-brand-500"
              />
            </label>
            <label className="block text-xs">
              <span className="mb-1 block text-slate-400">Qtd. de Equipamentos</span>
              <input
                name="quantidade_itens"
                type="number"
                min="1"
                autoComplete="off"
                data-lpignore="true"
                defaultValue={totalEsperado}
                className="w-full rounded-xl border border-surface-border bg-surface-base px-3 py-2 text-xs text-white outline-none focus:border-brand-500"
              />
            </label>
            <label className="block text-xs">
              <span className="mb-1 block text-slate-400">Localização</span>
              <input
                name="localizacao"
                autoComplete="off"
                data-lpignore="true"
                defaultValue={recurso.localizacao ?? ""}
                placeholder="Sala de recursos / Bloco B"
                className="w-full rounded-xl border border-surface-border bg-surface-base px-3 py-2 text-xs text-white outline-none focus:border-brand-500"
              />
            </label>
            <label className="flex items-center gap-2 text-xs text-slate-300 sm:col-span-3">
              <input
                type="checkbox"
                name="exclusivo_ds"
                defaultChecked={recurso.exclusivo_ds}
                className="h-4 w-4 rounded accent-brand-500"
              />
              <Lock className="h-3 w-3" />
              Uso exclusivo do curso técnico de Desenvolvimento de Sistemas
            </label>
            <div className="flex gap-2 sm:col-span-3">
              <button type="submit" className="btn-primary-compact">Salvar Alterações</button>
              <button
                type="button"
                onClick={() => setEditando(false)}
                className="rounded-xl border border-surface-border px-3 py-1.5 text-xs text-slate-400 hover:bg-surface-raised"
              >
                Cancelar
              </button>
            </div>
          </ActionForm>
        </div>
      )}

      {/* Painel de equipamentos individuais */}
      {temItens && expandido && (
        <div className="border-t border-surface-border bg-surface-overlay/30 p-4 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h4 className="text-xs font-semibold text-slate-200 uppercase tracking-wide">
                Lista de Equipamentos (1 a {totalEsperado})
              </h4>
              <p className="text-[11px] text-slate-400">
                Identificação individual para controle de manutenção e reserva modular.
              </p>
            </div>

            {/* Ações em Lote */}
            <div className="flex flex-wrap items-center gap-2">
              {itensDoRecurso.length < totalEsperado && (
                <button
                  type="button"
                  disabled={isPending}
                  onClick={handleGerarItensEmLote}
                  className="flex items-center gap-1.5 rounded-lg border border-brand-500/40 bg-brand-500/10 px-2.5 py-1.5 text-xs font-semibold text-brand-300 hover:bg-brand-500/20 transition disabled:opacity-50"
                  title="Gera os equipamentos faltantes automaticamente de 1 a N"
                >
                  {isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
                  Gerar 1 a {totalEsperado} Automaticamente
                </button>
              )}

              {itensDoRecurso.length > 0 && (
                <button
                  type="button"
                  disabled={isPending}
                  onClick={handleRegenerarItens}
                  className="flex items-center gap-1 rounded-lg border border-surface-border px-2.5 py-1.5 text-[11px] text-slate-400 hover:text-white hover:bg-surface-overlay transition disabled:opacity-50"
                  title="Limpa e recria a numeração sequencial de 1 a N"
                >
                  <RotateCcw className="h-3 w-3" />
                  Reiniciar Numeração
                </button>
              )}

              <button
                type="button"
                onClick={() => setAdicionandoItem(!adicionandoItem)}
                className="flex items-center gap-1 rounded-lg border border-surface-border px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white hover:bg-surface-overlay transition"
              >
                {adicionandoItem ? <X className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
                {adicionandoItem ? "Cancelar" : "Item Avulso"}
              </button>
            </div>
          </div>

          {/* Formulário de adicionar item avulso */}
          {adicionandoItem && (
            <ActionForm
              action={criarItemRecurso}
              resetOnSuccess
              onSuccess={() => setAdicionandoItem(false)}
              className="grid gap-2 sm:grid-cols-3 bg-surface-base rounded-xl p-3 border border-surface-border"
            >
              <input type="hidden" name="recurso_id" value={recurso.id} />
              <input
                name="numero_patrimonio"
                required
                autoComplete="off"
                data-lpignore="true"
                placeholder="Ex: Notebook 01, NB-15"
                className="col-span-1 rounded-xl border border-surface-border bg-surface-overlay px-3 py-2 text-xs text-white outline-none focus:border-brand-500 placeholder:text-slate-500"
              />
              <input
                name="descricao"
                autoComplete="off"
                data-lpignore="true"
                placeholder="Descrição opcional (ex: Slot 3)"
                className="col-span-1 rounded-xl border border-surface-border bg-surface-overlay px-3 py-2 text-xs text-white outline-none focus:border-brand-500 placeholder:text-slate-500"
              />
              <button type="submit" className="btn-primary-compact">
                Salvar Item
              </button>
            </ActionForm>
          )}

          {/* Grade de Itens */}
          {itensDoRecurso.length === 0 ? (
            <div className="rounded-xl border border-dashed border-surface-border p-6 text-center space-y-3">
              <Package className="mx-auto h-7 w-7 text-slate-600" />
              <p className="text-xs text-slate-400">
                Nenhum notebook cadastrado individualmente ainda neste carrinho.
              </p>
              <button
                type="button"
                disabled={isPending}
                onClick={handleGerarItensEmLote}
                className="inline-flex items-center gap-1.5 btn-primary text-xs"
              >
                {isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
                Numerar de 1 a {totalEsperado} Automaticamente
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2">
              {itensDoRecurso.map((item) => {
                const ist = STATUS_LABELS[item.status] ?? STATUS_LABELS.DISPONIVEL;
                const isManut = item.status !== "DISPONIVEL";

                return (
                  <div
                    key={item.id}
                    className={`flex flex-col justify-between rounded-xl border p-2.5 transition ${
                      isManut
                        ? "border-amber-500/40 bg-amber-500/10 text-amber-200"
                        : "border-surface-border bg-surface-base text-slate-200 hover:border-slate-700"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1">
                      <span className="text-xs font-bold truncate" title={item.numero_patrimonio}>
                        {item.numero_patrimonio}
                      </span>
                      <button
                        type="button"
                        disabled={isPending}
                        onClick={() => handleExcluirItem(item.id)}
                        title="Remover item"
                        className="rounded p-1 text-slate-500 hover:text-red-400 transition"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    </div>

                    <div className="mt-2 flex items-center justify-between gap-1 pt-1 border-t border-surface-border/40 text-[10px]">
                      <span className={`font-semibold ${ist.color.split(" ")[0]}`}>
                        {ist.label}
                      </span>

                      {isManut ? (
                        <button
                          type="button"
                          disabled={isPending}
                          onClick={() => handleStatusItem(item.id, "DISPONIVEL")}
                          title="Restaurar para disponível"
                          className="rounded p-1 text-emerald-400 hover:bg-emerald-500/20 transition"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        </button>
                      ) : (
                        <button
                          type="button"
                          disabled={isPending}
                          onClick={() => handleStatusItem(item.id, "MANUTENCAO_PARCIAL")}
                          title="Reportar manutenção neste item"
                          className="rounded p-1 text-slate-400 hover:text-amber-400 transition"
                        >
                          <Wrench className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default RecursoCard;