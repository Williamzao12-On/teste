"use client";

import { useTransition } from "react";
import { atualizarStatusRecurso } from "../actions";
import { useToast } from "@/components/ToastProvider";

const STATUS_STYLES = {
  DISPONIVEL: "bg-green-500/15 text-green-400",
  MANUTENCAO_PARCIAL: "bg-amber-500/15 text-amber-400",
  MANUTENCAO_TOTAL: "bg-red-500/15 text-red-400",
  INATIVO: "bg-surface-overlay text-slate-400",
};

export default function StatusRecursoForm({ recursoId, statusAtual }) {
  const [isPending, startTransition] = useTransition();
  const toast = useToast();

  function handleChange(e) {
    const status = e.target.value;
    const formData = new FormData();
    formData.set("id", recursoId);
    formData.set("status", status);

    startTransition(async () => {
      const res = await atualizarStatusRecurso(null, formData);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Status atualizado.");
    });
  }

  return (
    <select
      defaultValue={statusAtual}
      onChange={handleChange}
      disabled={isPending}
      className={`rounded-full border-0 px-3 py-1 text-xs font-medium disabled:opacity-50 ${STATUS_STYLES[statusAtual]}`}
    >
      <option value="DISPONIVEL">Disponível</option>
      <option value="MANUTENCAO_PARCIAL">Manutenção parcial</option>
      <option value="MANUTENCAO_TOTAL">Manutenção total</option>
      <option value="INATIVO">Inativo</option>
    </select>
  );
}
