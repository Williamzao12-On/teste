"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireRole } from "@/lib/auth";

export async function criarHorario(prevState, formData) {
  const profile = await requireRole(["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"]);
  const supabase = createClient();

  const turno = formData.get("turno")?.toString();
  const ordem = parseInt(formData.get("ordem")?.toString() || "1", 10);
  const label = formData.get("label")?.toString().trim();
  const hora_inicio = formData.get("hora_inicio")?.toString().trim();
  const hora_fim = formData.get("hora_fim")?.toString().trim();
  const is_intervalo = formData.get("is_intervalo") === "on";

  if (!turno || !label || !hora_inicio || !hora_fim) {
    return { error: "Preencha todos os campos obrigatórios." };
  }

  if (hora_inicio >= hora_fim) {
    return { error: "O horário de término deve ser posterior ao horário de início." };
  }

  const { error } = await supabase.from("grade_horarios").insert({
    escola_id: profile.escola_id,
    turno,
    ordem,
    label,
    hora_inicio,
    hora_fim,
    is_intervalo,
  });

  if (error) {
    if (error.message?.includes("unique_ordem_turno_escola")) {
      return {
        error: `Já existe um horário na ordem ${ordem} para o turno ${turno}. Escolha outra ordem.`,
      };
    }
    return { error: error.message };
  }

  revalidatePath("/gestor/horarios");
  revalidatePath("/reservas");
  return { success: `Horário "${label}" cadastrado.` };
}

export async function excluirHorario(id) {
  const profile = await requireRole(["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"]);
  const supabase = createClient();

  if (!id) return { error: "Horário inválido." };

  const { error } = await supabase
    .from("grade_horarios")
    .delete()
    .eq("id", id)
    .eq("escola_id", profile.escola_id);

  if (error) return { error: error.message };

  revalidatePath("/gestor/horarios");
  revalidatePath("/reservas");
  return { success: "Horário removido com sucesso." };
}

export async function gerarGradePadrao(turno) {
  const profile = await requireRole(["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"]);
  const supabase = createClient();

  if (!turno) return { error: "Turno não informado." };

  const grades = {
    MANHA: [
      { ordem: 1, label: "1ª Aula", hora_inicio: "07:00", hora_fim: "07:45", is_intervalo: false },
      { ordem: 2, label: "2ª Aula", hora_inicio: "07:45", hora_fim: "08:30", is_intervalo: false },
      { ordem: 3, label: "3ª Aula", hora_inicio: "08:30", hora_fim: "09:15", is_intervalo: false },
      { ordem: 4, label: "Intervalo", hora_inicio: "09:15", hora_fim: "09:35", is_intervalo: true },
      { ordem: 5, label: "4ª Aula", hora_inicio: "09:35", hora_fim: "10:20", is_intervalo: false },
      { ordem: 6, label: "5ª Aula", hora_inicio: "10:20", hora_fim: "11:05", is_intervalo: false },
      { ordem: 7, label: "6ª Aula", hora_inicio: "11:05", hora_fim: "11:50", is_intervalo: false },
    ],
    TARDE: [
      { ordem: 1, label: "1ª Aula", hora_inicio: "13:00", hora_fim: "13:45", is_intervalo: false },
      { ordem: 2, label: "2ª Aula", hora_inicio: "13:45", hora_fim: "14:30", is_intervalo: false },
      { ordem: 3, label: "3ª Aula", hora_inicio: "14:30", hora_fim: "15:15", is_intervalo: false },
      { ordem: 4, label: "Intervalo", hora_inicio: "15:15", hora_fim: "15:35", is_intervalo: true },
      { ordem: 5, label: "4ª Aula", hora_inicio: "15:35", hora_fim: "16:20", is_intervalo: false },
      { ordem: 6, label: "5ª Aula", hora_inicio: "16:20", hora_fim: "17:05", is_intervalo: false },
      { ordem: 7, label: "6ª Aula", hora_inicio: "17:05", hora_fim: "17:50", is_intervalo: false },
    ],
    NOITE: [
      { ordem: 1, label: "1ª Aula", hora_inicio: "19:00", hora_fim: "19:45", is_intervalo: false },
      { ordem: 2, label: "2ª Aula", hora_inicio: "19:45", hora_fim: "20:30", is_intervalo: false },
      { ordem: 3, label: "Intervalo", hora_inicio: "20:30", hora_fim: "20:45", is_intervalo: true },
      { ordem: 4, label: "3ª Aula", hora_inicio: "20:45", hora_fim: "21:30", is_intervalo: false },
      { ordem: 5, label: "4ª Aula", hora_inicio: "21:30", hora_fim: "22:15", is_intervalo: false },
      { ordem: 6, label: "5ª Aula", hora_inicio: "22:15", hora_fim: "23:00", is_intervalo: false },
    ],
    INTEGRAL: [
      { ordem: 1, label: "1ª Aula", hora_inicio: "07:30", hora_fim: "08:15", is_intervalo: false },
      { ordem: 2, label: "2ª Aula", hora_inicio: "08:15", hora_fim: "09:00", is_intervalo: false },
      { ordem: 3, label: "Intervalo Manhã", hora_inicio: "09:00", hora_fim: "09:20", is_intervalo: true },
      { ordem: 4, label: "3ª Aula", hora_inicio: "09:20", hora_fim: "10:05", is_intervalo: false },
      { ordem: 5, label: "4ª Aula", hora_inicio: "10:05", hora_fim: "10:50", is_intervalo: false },
      { ordem: 6, label: "Almoço", hora_inicio: "12:00", hora_fim: "13:00", is_intervalo: true },
      { ordem: 7, label: "5ª Aula", hora_inicio: "13:00", hora_fim: "13:45", is_intervalo: false },
      { ordem: 8, label: "6ª Aula", hora_inicio: "13:45", hora_fim: "14:30", is_intervalo: false },
      { ordem: 9, label: "7ª Aula", hora_inicio: "14:30", hora_fim: "15:15", is_intervalo: false },
    ],
  };

  const lista = grades[turno];
  if (!lista) return { error: "Turno não suportado para preenchimento automático." };

  // Remove os horários existentes deste turno antes de inserir a grade padrão
  await supabase
    .from("grade_horarios")
    .delete()
    .eq("escola_id", profile.escola_id)
    .eq("turno", turno);

  const payload = lista.map((item) => ({
    ...item,
    escola_id: profile.escola_id,
    turno,
  }));

  const { error } = await supabase.from("grade_horarios").insert(payload);

  if (error) return { error: error.message };

  revalidatePath("/gestor/horarios");
  revalidatePath("/reservas");
  return { success: `Grade padrão do turno ${turno} gerada com sucesso.` };
}
