import { requireRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import GestorTabs from "../GestorTabs";
import HorariosManager from "./HorariosManager";
import { Clock } from "lucide-react";

export default async function HorariosPage() {
  const profile = await requireRole(["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"]);
  const supabase = createClient();

  const { data: horarios } = await supabase
    .from("grade_horarios")
    .select("*")
    .eq("escola_id", profile.escola_id)
    .order("turno")
    .order("ordem");

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-white tracking-tight">Grade de Horários</h1>
        <p className="text-sm text-slate-400">
          Configure os períodos e horários de aula por turno da sua escola para habilitar as reservas.
        </p>
      </header>

      <GestorTabs current="horarios" />

      <HorariosManager horarios={horarios || []} />
    </div>
  );
}
