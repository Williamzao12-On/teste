"use client";

import { useState, useTransition } from "react";
import { criarHorario, excluirHorario, gerarGradePadrao } from "./actions";
import { useToast } from "@/components/ToastProvider";
import ActionForm from "@/components/ActionForm";
import SectionHeader from "@/components/SectionHeader";
import {
  Clock,
  Plus,
  Trash2,
  Sparkles,
  Coffee,
  BookOpen,
  Loader2,
  X,
  AlertCircle,
} from "lucide-react";

const TURNOS = [
  { key: "MANHA", label: "Manhã" },
  { key: "TARDE", label: "Tarde" },
  { key: "NOITE", label: "Noite" },
  { key: "INTEGRAL", label: "Integral" },
];

export default function HorariosManager({ horarios = [] }) {
  const [turnoAtivo, setTurnoAtivo] = useState("MANHA");
  const [mostrarNovoForm, setMostrarNovoForm] = useState(false);
  const [isPending, startTransition] = useTransition();
  const toast = useToast();

  const horariosDoTurno = horarios
    .filter((h) => h.turno === turnoAtivo)
    .sort((a, b) => a.ordem - b.ordem);

  function handleGerarPadrao() {
    if (
      horariosDoTurno.length > 0 &&
      !window.confirm(
        `Já existem horários cadastrados para o turno ${turnoAtivo}. Deseja substituir pela grade padrão oficial da rede estadual?`
      )
    ) {
      return;
    }

    startTransition(async () => {
      const res = await gerarGradePadrao(turnoAtivo);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Grade gerada com sucesso!");
    });
  }

  function handleExcluir(id) {
    startTransition(async () => {
      const res = await excluirHorario(id);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Horário removido.");
    });
  }

  // Próxima ordem sugerida para o formulário manual
  const proximaOrdem =
    horariosDoTurno.length > 0
      ? Math.max(...horariosDoTurno.map((h) => h.ordem)) + 1
      : 1;

  return (
    <div className="space-y-6">
      {/* Seletor de Turno */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-surface-border pb-3">
        <div className="flex gap-1.5 p-1 bg-surface-overlay/80 rounded-xl border border-surface-border">
          {TURNOS.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => {
                setTurnoAtivo(t.key);
                setMostrarNovoForm(false);
              }}
              className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition ${
                turnoAtivo === t.key
                  ? "bg-brand-600 text-white shadow-sm"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={isPending}
            onClick={handleGerarPadrao}
            className="flex items-center gap-1.5 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-xs font-semibold text-amber-300 hover:bg-amber-500/20 transition disabled:opacity-50"
          >
            {isPending ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Sparkles className="h-3.5 w-3.5 text-amber-400" />
            )}
            Gerar Grade Padrão
          </button>

          <button
            type="button"
            onClick={() => setMostrarNovoForm(!mostrarNovoForm)}
            className="flex items-center gap-1.5 rounded-xl btn-primary px-3 py-2 text-xs font-semibold"
          >
            {mostrarNovoForm ? <X className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
            {mostrarNovoForm ? "Cancelar" : "Novo Horário"}
          </button>
        </div>
      </div>

      {/* Formulário de Criação Manual de Horário */}
      {mostrarNovoForm && (
        <div className="panel border-brand-500/30 bg-surface-overlay/90 p-5 animate-fade-in">
          <SectionHeader icon={Clock}>
            Novo Horário — Turno {TURNOS.find((t) => t.key === turnoAtivo)?.label}
          </SectionHeader>

          <ActionForm
            action={criarHorario}
            resetOnSuccess
            onSuccess={() => setMostrarNovoForm(false)}
            className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-5"
          >
            <input type="hidden" name="turno" value={turnoAtivo} />

            <label className="block text-sm">
              <span className="mb-1.5 block font-medium text-slate-300 text-xs">Ordem (Posição)</span>
              <input
                name="ordem"
                type="number"
                min="1"
                max="20"
                required
                defaultValue={proximaOrdem}
                className="w-full rounded-xl border border-surface-border bg-surface-base px-3.5 py-2 text-xs text-white outline-none focus:border-brand-500"
              />
            </label>

            <label className="block text-sm">
              <span className="mb-1.5 block font-medium text-slate-300 text-xs">Identificação</span>
              <input
                name="label"
                type="text"
                required
                placeholder="Ex: 1ª Aula, Intervalo"
                defaultValue={proximaOrdem === 4 ? "Intervalo" : `${proximaOrdem}ª Aula`}
                className="w-full rounded-xl border border-surface-border bg-surface-base px-3.5 py-2 text-xs text-white outline-none focus:border-brand-500"
              />
            </label>

            <label className="block text-sm">
              <span className="mb-1.5 block font-medium text-slate-300 text-xs">Hora Início</span>
              <input
                name="hora_inicio"
                type="time"
                required
                className="w-full rounded-xl border border-surface-border bg-surface-base px-3.5 py-2 text-xs text-white outline-none focus:border-brand-500"
              />
            </label>

            <label className="block text-sm">
              <span className="mb-1.5 block font-medium text-slate-300 text-xs">Hora Término</span>
              <input
                name="hora_fim"
                type="time"
                required
                className="w-full rounded-xl border border-surface-border bg-surface-base px-3.5 py-2 text-xs text-white outline-none focus:border-brand-500"
              />
            </label>

            <div className="flex flex-col justify-end">
              <label className="flex items-center gap-2 rounded-xl border border-surface-border bg-surface-base p-2.5 cursor-pointer text-xs text-slate-300">
                <input
                  type="checkbox"
                  name="is_intervalo"
                  className="h-4 w-4 rounded accent-brand-500"
                />
                <span>É intervalo/recreio?</span>
              </label>
            </div>

            <div className="flex items-center gap-2 sm:col-span-2 lg:col-span-5 pt-2">
              <button type="submit" className="btn-primary">
                Salvar Horário
              </button>
              <button
                type="button"
                onClick={() => setMostrarNovoForm(false)}
                className="rounded-xl border border-surface-border px-4 py-2 text-xs text-slate-400 hover:bg-surface-raised"
              >
                Cancelar
              </button>
            </div>
          </ActionForm>
        </div>
      )}

      {/* Lista / Timeline de Horários */}
      <div className="space-y-3">
        {horariosDoTurno.length > 0 ? (
          <div className="grid gap-2">
            {horariosDoTurno.map((h) => {
              return (
                <div
                  key={h.id}
                  className={`flex items-center justify-between p-3.5 rounded-xl border transition ${
                    h.is_intervalo
                      ? "border-amber-500/20 bg-amber-500/5"
                      : "border-surface-border bg-surface-raised hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`flex h-8 w-8 items-center justify-center rounded-lg font-bold text-xs ${
                        h.is_intervalo
                          ? "bg-amber-500/15 text-amber-300"
                          : "bg-brand-600/15 text-brand-400"
                      }`}
                    >
                      {h.is_intervalo ? <Coffee className="h-4 w-4" /> : `${h.ordem}º`}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-white">{h.label}</span>
                        {h.is_intervalo && (
                          <span className="rounded bg-amber-500/20 px-1.5 py-0.2 text-[10px] font-semibold text-amber-300">
                            Intervalo
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400">
                        {h.hora_inicio?.slice(0, 5)} às {h.hora_fim?.slice(0, 5)}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={isPending}
                    onClick={() => handleExcluir(h.id)}
                    title="Remover horário"
                    className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition disabled:opacity-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="panel py-12 text-center space-y-3">
            <Clock className="mx-auto h-8 w-8 text-slate-500" />
            <div>
              <p className="text-sm font-semibold text-white">
                Nenhum horário cadastrado no turno {TURNOS.find((t) => t.key === turnoAtivo)?.label}
              </p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                A grade de horários é essencial para que os professores possam agendar os carrinhos e laboratórios sem choque de aula.
              </p>
            </div>
            <button
              type="button"
              onClick={handleGerarPadrao}
              className="inline-flex items-center gap-1.5 rounded-xl btn-primary px-4 py-2.5 text-xs font-semibold"
            >
              <Sparkles className="h-4 w-4" /> Gerar Grade Padrão Oficial (6 Aulas + Intervalo)
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
