"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireRole } from "@/lib/auth";

const GESTOR_ROLES = ["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"];

// =========================================================
// Recursos (carrinhos de notebook / laboratórios)
// =========================================================

function gerarListaItens(recursoId, quantidade, tipo, prefixoCustom) {
  let prefixo = prefixoCustom;
  if (!prefixo) {
    switch (tipo) {
      case "CARRINHO_NOTEBOOK":
        prefixo = "Notebook";
        break;
      case "TABLET":
        prefixo = "Tablet";
        break;
      case "CHROMEBOOK":
        prefixo = "Chromebook";
        break;
      case "LABORATORIO_INFORMATICA":
        prefixo = "Computador";
        break;
      default:
        prefixo = "Item";
        break;
    }
  }

  const padSize = quantidade >= 100 ? 3 : quantidade >= 10 ? 2 : 1;
  const itens = [];
  for (let i = 1; i <= quantidade; i++) {
    const num = String(i).padStart(padSize, "0");
    itens.push({
      recurso_id: recursoId,
      numero_patrimonio: `${prefixo} ${num}`,
      status: "DISPONIVEL",
    });
  }
  return itens;
}

export async function criarRecurso(prevState, formData) {
  const profile = await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const tipo = formData.get("tipo")?.toString();
  const nome = formData.get("nome")?.toString().trim();
  const quantidade_itens = Math.max(1, Number(formData.get("quantidade_itens") || 1));
  const localizacao = formData.get("localizacao")?.toString().trim() || null;
  const exclusivo_ds = formData.get("exclusivo_ds") === "on";

  if (!tipo || !nome) return { error: "Preencha tipo e nome do recurso." };

  const { data: novoRecurso, error } = await supabase
    .from("recursos")
    .insert({
      escola_id: profile.escola_id,
      tipo,
      nome,
      quantidade_itens,
      localizacao,
      exclusivo_ds,
    })
    .select("id, tipo, quantidade_itens")
    .single();

  if (error) return { error: error.message };

  // Gera automaticamente os equipamentos individuais de 1 a N
  if (quantidade_itens > 0) {
    const itens = gerarListaItens(novoRecurso.id, quantidade_itens, tipo);
    if (itens.length > 0) {
      await supabase.from("itens_recurso").insert(itens);
    }
  }

  revalidatePath("/gestor/recursos");
  return { success: `Recurso "${nome}" cadastrado com ${quantidade_itens} itens numerados automaticamente.` };
}

export async function atualizarStatusRecurso(prevState, formData) {
  await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const id = formData.get("id")?.toString();
  const status = formData.get("status")?.toString();

  const { error } = await supabase.from("recursos").update({ status }).eq("id", id);
  if (error) return { error: error.message };
  revalidatePath("/gestor/recursos");
  return { success: "Status atualizado." };
}

// =========================================================
// Turmas (séries)
// =========================================================

export async function criarTurma(prevState, formData) {
  const profile = await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const ano_letivo = Number(formData.get("ano_letivo"));
  const etapa = formData.get("etapa")?.toString();
  const serie = formData.get("serie")?.toString().trim();
  const identificador = formData.get("identificador")?.toString().trim();
  const turno = formData.get("turno")?.toString();

  if (!ano_letivo || !etapa || !serie || !identificador || !turno) {
    return { error: "Preencha todos os campos da turma." };
  }

  // Nunca confiar só no que o formulário mostrou — confirma no banco que essa
  // etapa está de fato entre as modalidades que o Admin configurou pra escola.
  const { data: escola } = await supabase
    .from("escolas")
    .select("modalidades_ensino")
    .eq("id", profile.escola_id)
    .single();

  if (!escola?.modalidades_ensino?.includes(etapa)) {
    return {
      error: "Essa etapa de ensino não está habilitada para sua escola. Fale com o Administrador.",
    };
  }

  const { error } = await supabase.from("turmas").insert({
    escola_id: profile.escola_id,
    ano_letivo,
    etapa,
    serie,
    identificador,
    turno,
  });

  if (error) return { error: error.message };
  revalidatePath("/gestor/turmas");
  return { success: "Turma cadastrada." };
}

export async function alternarAtivoTurma(prevState, formData) {
  await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const id = formData.get("id")?.toString();
  const ativo = formData.get("ativo") === "true";

  const { error } = await supabase.from("turmas").update({ ativo: !ativo }).eq("id", id);
  if (error) return { error: error.message };
  revalidatePath("/gestor/turmas");
  return { success: ativo ? "Turma marcada como inativa." : "Turma reativada." };
}

// =========================================================
// Docentes da escola
// =========================================================

export async function atualizarPapelDocente(prevState, formData) {
  await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const id = formData.get("id")?.toString();
  const role = formData.get("role")?.toString();
  const is_ds_authorized = formData.get("is_ds_authorized") === "on";

  if (role === "ADMIN") return { error: "Não é permitido atribuir este papel por aqui." };

  const { error } = await supabase
    .from("profiles")
    .update({ role, is_ds_authorized })
    .eq("id", id);

  if (error) return { error: error.message };
  revalidatePath("/gestor/usuarios");
  return { success: "Docente atualizado." };
}

// =========================================================
// Convidar docente (pelo Gestor — escola fixada automaticamente)
// =========================================================

export async function convidarDocente(prevState, formData) {
  const profile = await requireRole(GESTOR_ROLES);

  const email = formData.get("email")?.toString().trim().toLowerCase();
  const nome = formData.get("nome")?.toString().trim() || null;
  const role = formData.get("role")?.toString() || "DOCENTE";

  if (!email) return { error: "Informe o e-mail do docente." };
  if (!profile.escola_id) return { error: "Sua conta não está vinculada a uma escola." };

  // Gestores não podem convidar Admins nem outros Gestores de nível superior
  const papeisPermitidos = ["DOCENTE", "DOCENTE_DS", "GESTOR_ESCOLAR"];
  if (!papeisPermitidos.includes(role)) {
    return { error: "Você não tem permissão para convidar com esse papel." };
  }

  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL;
  if (!siteUrl) return { error: "NEXT_PUBLIC_SITE_URL não configurada no ambiente." };

  let supabaseAdmin;
  try {
    supabaseAdmin = createAdminClient();
  } catch (e) {
    return { error: `Falha ao inicializar cliente admin: ${e.message}` };
  }

  const { error } = await supabaseAdmin.auth.admin.inviteUserByEmail(email, {
    data: {
      full_name: nome,
      escola_id: profile.escola_id,
      role,
    },
    redirectTo: `${siteUrl}/auth/callback`,
  });

  if (error) {
    if (error.message?.toLowerCase().includes("already been registered")) {
      return { error: "Esse e-mail já tem cadastro. Peça ao Administrador para fazer o vínculo manual." };
    }
    return { error: `Supabase: ${error.message}` };
  }

  revalidatePath("/gestor/usuarios");
  return { success: `Convite enviado para ${email}.` };
}

// =========================================================
// Itens individuais do recurso (notebooks, tablets etc.)
// =========================================================

export async function criarItemRecurso(prevState, formData) {
  const profile = await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const recurso_id = formData.get("recurso_id")?.toString();
  const numero_patrimonio = formData.get("numero_patrimonio")?.toString().trim();
  const descricao = formData.get("descricao")?.toString().trim() || null;

  if (!recurso_id || !numero_patrimonio) {
    return { error: "Informe o recurso e o número de patrimônio." };
  }

  // Confirma que o recurso pertence à escola do gestor
  const { data: recurso } = await supabase
    .from("recursos")
    .select("escola_id")
    .eq("id", recurso_id)
    .single();

  if (!recurso || recurso.escola_id !== profile.escola_id) {
    return { error: "Recurso não encontrado nesta escola." };
  }

  const { error } = await supabase.from("itens_recurso").insert({
    recurso_id,
    numero_patrimonio,
    descricao,
  });

  if (error) {
    if (error.code === "23505") return { error: "Já existe um item com esse número de patrimônio neste recurso." };
    return { error: error.message };
  }

  revalidatePath("/gestor/recursos");
  return { success: `Item "${numero_patrimonio}" cadastrado.` };
}

export async function excluirItemRecurso(itemId) {
  await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const { error } = await supabase.from("itens_recurso").delete().eq("id", itemId);
  if (error) return { error: error.message };

  revalidatePath("/gestor/recursos");
  return { success: "Item removido." };
}

export async function atualizarStatusItem(itemId, novoStatus) {
  await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const { error } = await supabase
    .from("itens_recurso")
    .update({ status: novoStatus })
    .eq("id", itemId);

  if (error) return { error: error.message };
  revalidatePath("/gestor/recursos");
  return { success: "Status do item atualizado." };
}

export async function editarRecurso(prevState, formData) {
  const profile = await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const id = formData.get("id")?.toString();
  const nome = formData.get("nome")?.toString().trim();
  const quantidade_itens = Number(formData.get("quantidade_itens") || 0);
  const localizacao = formData.get("localizacao")?.toString().trim() || null;
  const exclusivo_ds = formData.get("exclusivo_ds") === "on";

  if (!id || !nome) return { error: "Dados inválidos." };

  const updatePayload = { nome, localizacao, exclusivo_ds };
  if (quantidade_itens > 0) {
    updatePayload.quantidade_itens = quantidade_itens;
  }

  const { error } = await supabase
    .from("recursos")
    .update(updatePayload)
    .eq("id", id)
    .eq("escola_id", profile.escola_id);

  if (error) return { error: error.message };
  revalidatePath("/gestor/recursos");
  return { success: "Recurso atualizado." };
}

export async function gerarItensEmLote(recursoId, prefixoCustom) {
  const profile = await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const { data: recurso, error: fetchErr } = await supabase
    .from("recursos")
    .select("id, tipo, quantidade_itens, escola_id")
    .eq("id", recursoId)
    .single();

  if (fetchErr || !recurso || recurso.escola_id !== profile.escola_id) {
    return { error: "Recurso não encontrado." };
  }

  const qtd = recurso.quantidade_itens || 1;
  const novosItens = gerarListaItens(recurso.id, qtd, recurso.tipo, prefixoCustom);

  // Insere ignorando duplicatas se já existirem alguns
  const { error } = await supabase
    .from("itens_recurso")
    .upsert(novosItens, { onConflict: "recurso_id,numero_patrimonio", ignoreDuplicates: true });

  if (error) return { error: error.message };

  revalidatePath("/gestor/recursos");
  return { success: `${qtd} itens gerados/atualizados com sucesso.` };
}

export async function limparERegenerarItens(recursoId, prefixoCustom) {
  const profile = await requireRole(GESTOR_ROLES);
  const supabase = createClient();

  const { data: recurso, error: fetchErr } = await supabase
    .from("recursos")
    .select("id, tipo, quantidade_itens, escola_id")
    .eq("id", recursoId)
    .single();

  if (fetchErr || !recurso || recurso.escola_id !== profile.escola_id) {
    return { error: "Recurso não encontrado." };
  }

  // Remove itens antigos
  await supabase.from("itens_recurso").delete().eq("recurso_id", recursoId);

  const qtd = recurso.quantidade_itens || 1;
  const novosItens = gerarListaItens(recurso.id, qtd, recurso.tipo, prefixoCustom);

  const { error } = await supabase.from("itens_recurso").insert(novosItens);
  if (error) return { error: error.message };

  revalidatePath("/gestor/recursos");
  return { success: `Numeração de 1 a ${qtd} regenerada com sucesso!` };
}

