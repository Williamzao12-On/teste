"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";

const TABS = [
  { key: "recursos", href: "/gestor/recursos", label: "Carrinhos & Laboratórios" },
  { key: "horarios", href: "/gestor/horarios", label: "Grade de Horários" },
  { key: "turmas", href: "/gestor/turmas", label: "Séries & Turmas" },
  { key: "usuarios", href: "/gestor/usuarios", label: "Docentes da Escola" },
];

export default function GestorTabs({ current }) {
  return (
    <div className="flex gap-1 overflow-x-auto border-b border-surface-border pb-px scrollbar-none">
      {TABS.map((tab) => (
        <Link
          key={tab.key}
          href={tab.href}
          className={cn(
            "shrink-0 whitespace-nowrap border-b-2 px-4 py-2.5 text-xs sm:text-sm font-medium transition",
            current === tab.key
              ? "border-brand-500 text-brand-400 font-semibold"
              : "border-transparent text-slate-400 hover:text-slate-200"
          )}
        >
          {tab.label}
        </Link>
      ))}
    </div>
  );
}
