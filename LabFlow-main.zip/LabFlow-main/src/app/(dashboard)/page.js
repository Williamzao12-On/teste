﻿import Link from "next/link";
import { getCurrentProfile } from "@/lib/auth";
import { ROLE_LABELS } from "@/lib/roles";
import { createClient } from "@/lib/supabase/server";
import { ETAPA_LABELS } from "@/lib/etapas";
import {
  Building2,
  ShieldCheck,
  Laptop,
  GraduationCap,
  Users,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ArrowRight,
  School,
  Sparkles,
  Plus,
  HelpCircle,
  FileCheck2,
} from "lucide-react";

export default async function HomePage() {
  const profile = await getCurrentProfile();

  if (!profile) return null;

  const supabase = createClient();
  const semEscola = !profile.escola_id && profile.role !== "ADMIN";
  const primeiroNome = profile.nome_completo?.split(" ")[0] || "Educador(a)";
  const hora = new Date().getHours();
  const saudacao = hora < 12 ? "Bom dia" : hora < 18 ? "Boa tarde" : "Boa noite";

  // Se for ADMIN: carrega dados de toda a rede
  // Se tiver escola: carrega dados específicos da sua escola
  let dadosAdmin = null;
  let dadosEscola = null;

  if (profile.role === "ADMIN") {
    const [{ data: escolas }, { data: perfis }, { data: recursos }, { data: turmas }] =
      await Promise.all([
        supabase
          .from("escolas")
          .select("id, nome, diretoria_ensino, ativo, modalidades_ensino")
          .order("nome"),
        supabase.from("profiles").select("id, role, escola_id"),
        supabase.from("recursos").select("id, status, tipo, quantidade_itens"),
        supabase.from("turmas").select("id, ativo"),
      ]);

    dadosAdmin = {
      escolas: escolas || [],
      perfis: perfis || [],
      recursos: recursos || [],
      turmas: turmas || [],
    };
  } else if (profile.escola_id) {
    const [{ data: escolaCompleta }, { data: recursos }, { data: turmas }, { data: docentes }] =
      await Promise.all([
        supabase.from("escolas").select("*").eq("id", profile.escola_id).maybeSingle(),
        supabase.from("recursos").select("*").eq("escola_id", profile.escola_id).order("nome"),
        supabase
          .from("turmas")
          .select("*")
          .eq("escola_id", profile.escola_id)
          .eq("ativo", true)
          .order("serie"),
        supabase
          .from("profiles")
          .select("id, nome_completo, email, role, is_ds_authorized")
          .eq("escola_id", profile.escola_id),
      ]);

    dadosEscola = {
      escola: escolaCompleta || profile.escolas,
      recursos: recursos || [],
      turmas: turmas || [],
      docentes: docentes || [],
    };
  }

  return (
    <div className="space-y-8">
      {/* Hero de Boas-Vindas */}
      <div className="panel overflow-hidden border-surface-border bg-surface-raised p-6 sm:p-8">
        <div
          className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full opacity-25 blur-3xl"
          style={{ backgroundImage: "linear-gradient(135deg, #4d7fff, #7a5cf0)" }}
        />
        <div
          className="pointer-events-none absolute -left-20 -bottom-20 h-48 w-48 rounded-full opacity-15 blur-3xl"
          style={{ backgroundImage: "linear-gradient(135deg, #e8873a, #4d7fff)" }}
        />

        <div className="relative flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1.5 rounded-full bg-brand-500/10 px-2.5 py-0.5 text-xs font-semibold text-brand-400 border border-brand-500/20">
                <Sparkles className="h-3 w-3" />
                {saudacao}, {primeiroNome}
              </span>
              <span className="rounded-full bg-surface-overlay px-2.5 py-0.5 text-xs font-medium text-slate-300 border border-surface-border">
                {ROLE_LABELS[profile.role]}
              </span>
            </div>

            <h1 className="text-2xl font-bold text-white tracking-tight sm:text-3xl">
              {profile.role === "ADMIN"
                ? "Centro de Controle da Rede"
                : profile.escolas?.nome || "Portal LabFlow"}
            </h1>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400">
              {profile.escolas?.nome && (
                <span className="flex items-center gap-1">
                  <Building2 className="h-3.5 w-3.5 text-slate-500" />
                  {profile.escolas.nome}
                </span>
              )}
              {dadosEscola?.escola?.diretoria_ensino && (
                <span className="flex items-center gap-1">
                  <School className="h-3.5 w-3.5 text-slate-500" />
                  {dadosEscola.escola.diretoria_ensino}
                </span>
              )}
              <span className="flex items-center gap-1">
                <ShieldCheck className="h-3.5 w-3.5 text-slate-500" />
                {profile.email}
              </span>
            </div>

            {/* Modalidades atendidas na escola */}
            {dadosEscola?.escola?.modalidades_ensino?.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-2">
                {dadosEscola.escola.modalidades_ensino.map((m) => {
                  const isMedioTecnico = m === "MEDIO_TECNICO";
                  return (
                    <span
                      key={m}
                      className={`rounded-md px-2 py-0.5 text-[11px] font-medium ${
                        isMedioTecnico
                          ? "bg-amber-500/15 text-amber-300 border border-amber-500/30"
                          : "bg-brand-500/10 text-brand-400 border border-brand-500/20"
                      }`}
                    >
                      {ETAPA_LABELS[m] || m}
                    </span>
                  );
                })}
              </div>
            )}
          </div>

          {/* Atalho rápido para ação principal */}
          {profile.role === "ADMIN" && (
            <Link
              href="/admin"
              className="flex items-center gap-2 self-start rounded-xl btn-primary px-4 py-2.5 text-xs font-semibold sm:self-auto"
            >
              Painel Admin <ArrowRight className="h-4 w-4" />
            </Link>
          )}

          {["DIRETOR", "GESTOR_ESCOLAR"].includes(profile.role) && (
            <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
              <Link
                href="/gestor/recursos"
                className="flex items-center gap-1.5 rounded-xl border border-surface-border bg-surface-overlay px-3.5 py-2 text-xs font-medium text-slate-200 hover:bg-surface-border transition"
              >
                <Laptop className="h-3.5 w-3.5 text-brand-400" /> Recursos
              </Link>
              <Link
                href="/gestor/turmas"
                className="flex items-center gap-1.5 rounded-xl btn-primary px-3.5 py-2 text-xs font-semibold"
              >
                <Plus className="h-3.5 w-3.5" /> Nova Turma
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* Alerta de Conta sem Escola */}
      {semEscola && (
        <div className="panel flex items-start gap-4 border-amber-500/40 bg-amber-500/10 p-5">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400">
            <AlertTriangle className="h-5 w-5" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-semibold text-white">
              Conta aguardando vínculo de escola
            </h3>
            <p className="text-sm text-slate-300">
              Seu acesso já foi criado, mas ainda não foi associado a nenhuma escola da rede.
              O Administrador do sistema ou a equipe gestora da sua unidade precisa liberar seu
              vínculo para habilitar o agendamento de recursos.
            </p>
            <p className="text-xs text-amber-300/80 pt-1">
              Assim que sua escola for definida, os carrinhos de notebook e laboratórios aparecerão
              aqui automaticamente.
            </p>
          </div>
        </div>
      )}

      {/* VISÃO DO ADMINISTRADOR */}
      {profile.role === "ADMIN" && dadosAdmin && (
        <div className="space-y-8">
          {/* Métricas Principais da Rede */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="panel p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Escolas na Rede</span>
                <School className="h-4 w-4 text-brand-400" />
              </div>
              <p className="text-2xl font-bold text-white">{dadosAdmin.escolas.length}</p>
              <p className="text-xs text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3" />
                {dadosAdmin.escolas.filter((e) => e.ativo).length} ativas
              </p>
            </div>

            <div className="panel p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Usuários Totais</span>
                <Users className="h-4 w-4 text-purple-400" />
              </div>
              <p className="text-2xl font-bold text-white">{dadosAdmin.perfis.length}</p>
              <p className="text-xs text-slate-400">
                {dadosAdmin.perfis.filter((p) => p.role.startsWith("DOCENTE")).length} docentes
              </p>
            </div>

            <div className="panel p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Recursos Cadastrados</span>
                <Laptop className="h-4 w-4 text-cyan-400" />
              </div>
              <p className="text-2xl font-bold text-white">{dadosAdmin.recursos.length}</p>
              <p className="text-xs text-slate-400">
                {dadosAdmin.recursos.filter((r) => r.status === "DISPONIVEL").length} disponíveis
              </p>
            </div>

            <div className="panel p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Turmas Ativas</span>
                <GraduationCap className="h-4 w-4 text-amber-400" />
              </div>
              <p className="text-2xl font-bold text-white">{dadosAdmin.turmas.length}</p>
              <p className="text-xs text-slate-400">Registradas na rede</p>
            </div>
          </div>

          {/* Cards de Acesso Rápido de Governança */}
          <div className="grid gap-5 sm:grid-cols-2">
            <Link
              href="/admin"
              className="panel group p-6 transition hover:border-brand-500/50 hover:bg-surface-overlay/80"
            >
              <div className="flex items-center justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/15 text-brand-400">
                  <Building2 className="h-5 w-5" />
                </div>
                <ArrowRight className="h-4 w-4 text-slate-500 transition group-hover:translate-x-1 group-hover:text-brand-400" />
              </div>
              <h3 className="mt-4 text-base font-bold text-white">Gestão de Escolas & Modalidades</h3>
              <p className="mt-1 text-xs text-slate-400">
                Cadastre novas unidades, gerencie modalidades (Ensino Médio Técnico, Fundamental, etc.) e configure equipes gestoras.
              </p>
            </Link>

            <Link
              href="/admin"
              className="panel group p-6 transition hover:border-purple-500/50 hover:bg-surface-overlay/80"
            >
              <div className="flex items-center justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-500/15 text-purple-400">
                  <Users className="h-5 w-5" />
                </div>
                <ArrowRight className="h-4 w-4 text-slate-500 transition group-hover:translate-x-1 group-hover:text-purple-400" />
              </div>
              <h3 className="mt-4 text-base font-bold text-white">Controle de Usuários & Convites</h3>
              <p className="mt-1 text-xs text-slate-400">
                Envie convites institucionais, aprove cadastros pendentes e atribua papéis com proteção contra auto-despromoção.
              </p>
            </Link>
          </div>
        </div>
      )}

      {/* VISÃO DO GESTOR ESCOLAR (DIRETOR / GESTOR) */}
      {["DIRETOR", "GESTOR_ESCOLAR"].includes(profile.role) && dadosEscola && (
        <div className="space-y-8">
          {/* Métricas Operacionais da Escola */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {/* Carrinhos */}
            <div className="panel p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Carrinhos de Notebook</span>
                <Laptop className="h-4 w-4 text-brand-400" />
              </div>
              <p className="text-2xl font-bold text-white">
                {dadosEscola.recursos.filter((r) => r.tipo === "CARRINHO_NOTEBOOK").length}
              </p>
              <p className="text-xs text-slate-400">
                {dadosEscola.recursos
                  .filter((r) => r.tipo === "CARRINHO_NOTEBOOK")
                  .reduce((acc, curr) => acc + (curr.quantidade_itens || 0), 0)}{" "}
                notebooks no total
              </p>
            </div>

            {/* Laboratórios */}
            <div className="panel p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Laboratórios de Informática</span>
                <Building2 className="h-4 w-4 text-cyan-400" />
              </div>
              <p className="text-2xl font-bold text-white">
                {dadosEscola.recursos.filter((r) => r.tipo === "LABORATORIO_INFORMATICA").length}
              </p>
              <p className="text-xs text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3" />
                {dadosEscola.recursos.filter(
                  (r) => r.tipo === "LABORATORIO_INFORMATICA" && r.status === "DISPONIVEL"
                ).length}{" "}
                disponíveis
              </p>
            </div>

            {/* Turmas */}
            <div className="panel p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Turmas Ativas</span>
                <GraduationCap className="h-4 w-4 text-amber-400" />
              </div>
              <p className="text-2xl font-bold text-white">{dadosEscola.turmas.length}</p>
              <p className="text-xs text-slate-400">Séries e turmas cadastradas</p>
            </div>

            {/* Docentes */}
            <div className="panel p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Corpo Docente</span>
                <Users className="h-4 w-4 text-purple-400" />
              </div>
              <p className="text-2xl font-bold text-white">
                {dadosEscola.docentes.filter((d) => d.role.startsWith("DOCENTE")).length}
              </p>
              <p className="text-xs text-slate-400">
                {dadosEscola.docentes.filter((d) => d.is_ds_authorized).length} autorizados DS
              </p>
            </div>
          </div>

          {/* Seção: Status dos Recursos Físicos da Escola */}
          <div className="panel space-y-5 p-6">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between border-b border-surface-border pb-4">
              <div>
                <h2 className="text-base font-bold text-white">Recursos Físicos da Unidade</h2>
                <p className="text-xs text-slate-400">
                  Visão em tempo real da disponibilidade dos equipamentos e salas.
                </p>
              </div>

              <Link
                href="/gestor/recursos"
                className="flex items-center gap-1.5 text-xs font-semibold text-brand-400 hover:underline"
              >
                Gerenciar Recursos <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            {dadosEscola.recursos.length > 0 ? (
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {dadosEscola.recursos.map((rec) => {
                  const isDisponivel = rec.status === "DISPONIVEL";
                  const isManutencao = ["MANUTENCAO_PARCIAL", "MANUTENCAO_TOTAL"].includes(
                    rec.status
                  );

                  return (
                    <div
                      key={rec.id}
                      className="flex flex-col justify-between rounded-xl border border-surface-border bg-surface-overlay/60 p-4 transition hover:border-slate-700"
                    >
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-semibold text-white truncate">
                            {rec.nome}
                          </span>
                          {isDisponivel ? (
                            <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-400 border border-emerald-500/20">
                              Disponível
                            </span>
                          ) : isManutencao ? (
                            <span className="rounded-full bg-amber-500/10 px-2 py-0.5 text-[10px] font-semibold text-amber-400 border border-amber-500/20">
                              Manutenção
                            </span>
                          ) : (
                            <span className="rounded-full bg-slate-500/10 px-2 py-0.5 text-[10px] font-medium text-slate-400">
                              Inativo
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-slate-400">
                          {rec.tipo === "CARRINHO_NOTEBOOK"
                            ? `${rec.quantidade_itens || 0} notebooks`
                            : "Laboratório Fixo"}
                        </p>

                        {rec.exclusivo_ds && (
                          <span className="inline-block rounded bg-amber-500/10 px-1.5 py-0.5 text-[10px] font-medium text-amber-300 border border-amber-500/20">
                            Exclusivo Ensino Técnico (DS)
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-8 text-center">
                <Laptop className="mx-auto h-8 w-8 text-slate-500 mb-2" />
                <p className="text-sm font-medium text-slate-300">
                  Nenhum recurso cadastrado nesta escola ainda.
                </p>
                <Link
                  href="/gestor/recursos"
                  className="mt-3 inline-flex items-center gap-1.5 rounded-xl btn-primary px-3.5 py-2 text-xs font-semibold"
                >
                  <Plus className="h-3.5 w-3.5" /> Cadastrar Primeiro Recurso
                </Link>
              </div>
            )}
          </div>
        </div>
      )}

      {/* VISÃO DO DOCENTE (PROFESSOR) */}
      {profile.role.startsWith("DOCENTE") && dadosEscola && (
        <div className="space-y-8">
          {/* Status dos Recursos para o Professor */}
          <div className="panel space-y-5 p-6">
            <div className="flex flex-col gap-1 border-b border-surface-border pb-4">
              <h2 className="text-base font-bold text-white">
                Recursos Disponíveis para Suas Aulas
              </h2>
              <p className="text-xs text-slate-400">
                Consulte o status e capacidade dos equipamentos da sua escola antes de preparar suas atividades.
              </p>
            </div>

            {dadosEscola.recursos.length > 0 ? (
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {dadosEscola.recursos.map((rec) => {
                  const isDisponivel = rec.status === "DISPONIVEL";
                  return (
                    <div
                      key={rec.id}
                      className="rounded-xl border border-surface-border bg-surface-overlay/50 p-4 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-500/10 text-brand-400">
                            {rec.tipo === "CARRINHO_NOTEBOOK" ? (
                              <Laptop className="h-4 w-4" />
                            ) : (
                              <Building2 className="h-4 w-4" />
                            )}
                          </div>
                          <span className="text-sm font-semibold text-white">{rec.nome}</span>
                        </div>
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${
                            isDisponivel
                              ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30"
                              : "bg-amber-500/15 text-amber-400 border border-amber-500/30"
                          }`}
                        >
                          {isDisponivel ? "Disponível" : "Em Manutenção"}
                        </span>
                      </div>

                      <p className="text-xs text-slate-400">
                        {rec.tipo === "CARRINHO_NOTEBOOK"
                          ? `Capacidade: ${rec.quantidade_itens || 0} notebooks`
                          : "Laboratório de Informática"}
                      </p>

                      {rec.exclusivo_ds && (
                        <div className="rounded bg-amber-500/10 px-2 py-1 text-[11px] text-amber-300 border border-amber-500/20">
                          {profile.is_ds_authorized || profile.role === "DOCENTE_DS"
                            ? "✓ Você possui autorização para este recurso técnico."
                            : "Acesso restrito ao curso técnico (DS)."}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-slate-400 py-4">
                Sua escola ainda não cadastrou os carrinhos e laboratórios no sistema.
              </p>
            )}
          </div>

          {/* Dicas e Protocolos de Zelo */}
          <div className="panel p-6 space-y-3 bg-surface-raised border-surface-border">
            <div className="flex items-center gap-2 text-brand-400">
              <FileCheck2 className="h-5 w-5" />
              <h3 className="text-sm font-bold text-white">Orientações de Uso & Zelo</h3>
            </div>
            <ul className="list-disc list-inside text-xs text-slate-300 space-y-1.5">
              <li>Confira a quantidade de notebooks ao retirar o carrinho da sala de guarda.</li>
              <li>Oriente os alunos quanto ao manuseio seguro dos equipamentos e carregadores.</li>
              <li>Ao final da aula, certifique-se de que todos os aparelhos foram reconectados às tomadas internas do carrinho.</li>
              <li>Caso identifique qualquer avaria ou teclado com defeito, reporte diretamente à gestão da escola.</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
