import { redirect } from "next/navigation";
import { getCurrentProfile } from "@/lib/auth";
import Sidebar from "@/components/Sidebar";
import BottomNav from "@/components/BottomNav";
import ToastProvider from "@/components/ToastProvider";

export default async function DashboardLayout({ children }) {
  const profile = await getCurrentProfile();

  if (!profile) {
    redirect("/login");
  }

  return (
    <ToastProvider>
      <div className="flex h-screen flex-col overflow-hidden lg:flex-row bg-surface-base">
        <Sidebar profile={profile} />
        <div className="flex-1 overflow-y-auto">
          <main className="mx-auto max-w-5xl px-4 py-5 sm:px-6 sm:py-8 pb-24 lg:pb-8">
            {children}
          </main>
        </div>
        <BottomNav profile={profile} />
      </div>
    </ToastProvider>
  );
}
