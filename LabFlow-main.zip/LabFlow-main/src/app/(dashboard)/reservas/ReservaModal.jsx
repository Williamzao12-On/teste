﻿"use client";

import { useState, useMemo } from "react";
import ActionForm from "@/components/ActionForm";
import { criarReserva } from "./actions";
import {
  CalendarDays,
  Laptop,
  Clock,
  X,
  Sliders,
  AlertTriangle,
  CheckCircle2,
  Package,
} from "lucide-react";

export default function ReservaModal({
  recurso,
  horario,
  dataSelecionada,
  turmas = [],
  professores = [],
  itens = [],
  onClose,
}) {
  const [isSubstituicao, setIsSubstituicao] = useState(false);

  // Itens deste recurso
  const itensDoRecurso = useMemo(() => {
    return itens.filter((i) => i.recurso_id === recurso?.id);
  }, [itens, recurso]);

  const temItens = itensDoRecurso.length > 0;
  const disponiveis = useMemo(
    () => itensDoRecurso.filter((i) => i.status === "DISPONIVEL"),
    [itensDoRecurso]
  );
  const emManutencao = useMemo(
    () => itensDoRecurso.filter((i) => i.status !== "DISPONIVEL"),
    [itensDoRecurso]
  );

  // Modos de seleção: 'TODOS' | 'FAIXA' | 'INDIVIDUAL'
  const [modoSelecao, setModoSelecao] = useState("TODOS");

  // Faixa do X ao Y
  const [faixaInicio, setFaixaInicio] = useState(disponiveis[0]?.numero_patrimonio || "");
  const [faixaFim, setFaixaFim] = useState(
    disponiveis[disponiveis.length - 1]?.numero_patrimonio || ""
  );

  // Seleção individual (Set de patrimônios)
  const [selecionadosManual, setSelecionadosManual] = useState(
    () => new Set(disponiveis.map((i) => i.numero_patrimonio))
  );

  // Computa a lista final de patrimônios selecionados
  const itensSelecionados = useMemo(() => {
    if (!temItens) return [];

    if (modoSelecao === "TODOS") {
      return disponiveis.map((i) => i.numero_patrimonio);
    }

    if (modoSelecao === "FAIXA") {
      if (!faixaInicio || !faixaFim) return [];
      const idxInicio = itensDoRecurso.findIndex((i) => i.numero_patrimonio === faixaInicio);
      const idxFim = itensDoRecurso.findIndex((i) => i.numero_patrimonio === faixaFim);

      if (idxInicio === -1 || idxFim === -1) return [];

      const minIdx = Math.min(idxInicio, idxFim);
      const maxIdx = Math.max(idxInicio, idxFim);

      // Pega todos no intervalo que estão DISPONÍVEIS
      return itensDoRecurso
        .slice(minIdx, maxIdx + 1)
        .filter((i) => i.status === "DISPONIVEL")
        .map((i) => i.numero_patrimonio);
    }

    if (modoSelecao === "INDIVIDUAL") {
      return Array.from(selecionadosManual);
    }

    return [];
  }, [modoSelecao, temItens, disponiveis, faixaInicio, faixaFim, itensDoRecurso, selecionadosManual]);

  // Resumo em texto para salvar e exibir no calendário
  const faixaTexto = useMemo(() => {
    if (!temItens) return null;
    const totalSel = itensSelecionados.length;
    if (totalSel === 0) return "Nenhum equipamento selecionado";

    if (modoSelecao === "TODOS") {
      return `Todos disponíveis (${totalSel} unid.)`;
    }

    if (modoSelecao === "FAIXA" && faixaInicio && faixaFim) {
      if (faixaInicio === faixaFim) {
        return `${faixaInicio} (1 unid.)`;
      }
      return `${faixaInicio} a ${faixaFim} (${totalSel} unid.)`;
    }

    if (totalSel <= 3) {
      return `${itensSelecionados.join(", ")} (${totalSel} unid.)`;
    }

    return `${itensSelecionados[0]} a ${itensSelecionados[totalSel - 1]} (${totalSel} unid.)`;
  }, [temItens, itensSelecionados, modoSelecao, faixaInicio, faixaFim]);

  function alternarItemManual(num) {
    setSelecionadosManual((prev) => {
      const next = new Set(prev);
      if (next.has(num)) next.delete(num);
      else next.add(num);
      return next;
    });
  }

  function selecionarTodos() {
    setSelecionadosManual(new Set(disponiveis.map((i) => i.numero_patrimonio)));
  }

  function desmarcarTodos() {
    setSelecionadosManual(new Set());
  }

  if (!recurso || !horario) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 overflow-y-auto animate-fade-in">
      <div className="w-full max-w-lg panel border-surface-border bg-surface-raised p-6 shadow-2xl space-y-5 my-auto max-h-[90vh] overflow-y-auto">
        {/* Cabeçalho */}
        <div className="flex items-center justify-between border-b border-surface-border pb-4">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-600/20 text-brand-400 border border-brand-500/30">
              <CalendarDays className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white leading-tight">Nova Reserva</h3>
              <p className="text-xs text-slate-400">
                Agendamento modular para aula
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-surface-overlay hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Resumo do Recurso e Horário */}
        <div className="grid grid-cols-2 gap-2 rounded-xl bg-surface-overlay/70 p-3 border border-surface-border/60 text-xs">
          <div>
            <span className="text-slate-500 font-medium block">Recurso</span>
            <span className="text-white font-semibold flex items-center gap-1 mt-0.5 truncate">
              <Laptop className="h-3.5 w-3.5 text-brand-400 shrink-0" />
              {recurso.nome}
            </span>
          </div>
          <div>
            <span className="text-slate-500 font-medium block">Horário</span>
            <span className="text-white font-semibold flex items-center gap-1 mt-0.5">
              <Clock className="h-3.5 w-3.5 text-brand-400 shrink-0" />
              {horario.label} ({horario.hora_inicio?.slice(0, 5)} - {horario.hora_fim?.slice(0, 5)})
            </span>
          </div>
        </div>

        {/* Formulário de Reserva */}
        <ActionForm
          action={criarReserva}
          onSuccess={onClose}
          className="space-y-4"
        >
          <input type="hidden" name="recurso_id" value={recurso.id} />
          <input type="hidden" name="horario_id" value={horario.id} />
          <input type="hidden" name="data_reserva" value={dataSelecionada} />
          <input
            type="hidden"
            name="itens_reservados"
            value={JSON.stringify(itensSelecionados)}
          />
          <input type="hidden" name="faixa_itens" value={faixaTexto || ""} />

          {/* Seleção de Turma */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Turma de Destino *
            </label>
            <select
              name="turma_id"
              required
              className="w-full rounded-xl border border-surface-border bg-surface-base py-2.5 px-3.5 text-xs text-white outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20"
            >
              <option value="">Selecione a turma...</option>
              {turmas.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.serie} {t.identificador} ({t.turno})
                </option>
              ))}
            </select>
            {turmas.length === 0 && (
              <p className="text-[11px] text-amber-400 mt-1">
                Nenhuma turma cadastrada na escola. Peça ao Gestor para cadastrar em Séries &amp; Turmas.
              </p>
            )}
          </div>

          {/* SEÇÃO MODULAR: ESCOLHA DE NOTEBOOKS DO CARRINHO */}
          {temItens && (
            <div className="rounded-xl border border-brand-500/30 bg-brand-500/5 p-3.5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-brand-300 flex items-center gap-1.5">
                  <Sliders className="h-3.5 w-3.5" />
                  Seleção Modular de Equipamentos
                </span>
                <span className="text-[11px] text-slate-400 font-medium">
                  {disponiveis.length} de {itensDoRecurso.length} disponíveis
                </span>
              </div>

              {/* Botões dos 3 Modos de Escolha */}
              <div className="grid grid-cols-3 gap-1.5 bg-surface-base p-1 rounded-xl border border-surface-border text-xs">
                <button
                  type="button"
                  onClick={() => setModoSelecao("TODOS")}
                  className={`py-1.5 px-2 rounded-lg font-semibold transition text-center ${
                    modoSelecao === "TODOS"
                      ? "bg-brand-500 text-white shadow-sm"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  Carrinho Todo
                </button>
                <button
                  type="button"
                  onClick={() => setModoSelecao("FAIXA")}
                  className={`py-1.5 px-2 rounded-lg font-semibold transition text-center ${
                    modoSelecao === "FAIXA"
                      ? "bg-brand-500 text-white shadow-sm"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  Do X ao Y
                </button>
                <button
                  type="button"
                  onClick={() => setModoSelecao("INDIVIDUAL")}
                  className={`py-1.5 px-2 rounded-lg font-semibold transition text-center ${
                    modoSelecao === "INDIVIDUAL"
                      ? "bg-brand-500 text-white shadow-sm"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  Manual
                </button>
              </div>

              {/* Modo: FAIXA DO X AO Y */}
              {modoSelecao === "FAIXA" && (
                <div className="grid grid-cols-2 gap-2 pt-1 animate-fade-in">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      Do equipamento:
                    </label>
                    <select
                      value={faixaInicio}
                      onChange={(e) => setFaixaInicio(e.target.value)}
                      className="w-full rounded-lg border border-surface-border bg-surface-base py-2 px-2.5 text-xs text-white outline-none focus:border-brand-500"
                    >
                      {itensDoRecurso.map((item) => (
                        <option
                          key={item.id}
                          value={item.numero_patrimonio}
                          disabled={item.status !== "DISPONIVEL"}
                        >
                          {item.numero_patrimonio}{" "}
                          {item.status !== "DISPONIVEL" ? "(Defeito)" : ""}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      Até o equipamento:
                    </label>
                    <select
                      value={faixaFim}
                      onChange={(e) => setFaixaFim(e.target.value)}
                      className="w-full rounded-lg border border-surface-border bg-surface-base py-2 px-2.5 text-xs text-white outline-none focus:border-brand-500"
                    >
                      {itensDoRecurso.map((item) => (
                        <option
                          key={item.id}
                          value={item.numero_patrimonio}
                          disabled={item.status !== "DISPONIVEL"}
                        >
                          {item.numero_patrimonio}{" "}
                          {item.status !== "DISPONIVEL" ? "(Defeito)" : ""}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              )}

              {/* Modo: SELEÇÃO MANUAL / CHIPS */}
              {modoSelecao === "INDIVIDUAL" && (
                <div className="space-y-2 pt-1 animate-fade-in">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">Clique para marcar/desmarcar:</span>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={selecionarTodos}
                        className="text-brand-400 hover:underline"
                      >
                        Marcar Todos
                      </button>
                      <span>·</span>
                      <button
                        type="button"
                        onClick={desmarcarTodos}
                        className="text-slate-400 hover:underline"
                      >
                        Limpar
                      </button>
                    </div>
                  </div>

                  <div className="max-h-36 overflow-y-auto grid grid-cols-4 sm:grid-cols-6 gap-1.5 p-1 bg-surface-base/60 rounded-xl border border-surface-border/50">
                    {itensDoRecurso.map((item) => {
                      const isManut = item.status !== "DISPONIVEL";
                      const isMarcado = selecionadosManual.has(item.numero_patrimonio);

                      if (isManut) {
                        return (
                          <div
                            key={item.id}
                            title={`${item.numero_patrimonio} - Em Manutenção (Indisponível)`}
                            className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-1 text-center text-[10px] text-amber-400/50 cursor-not-allowed opacity-60 truncate"
                          >
                            {item.numero_patrimonio}
                          </div>
                        );
                      }

                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => alternarItemManual(item.numero_patrimonio)}
                          className={`rounded-lg border p-1 text-center text-[10px] font-medium transition truncate ${
                            isMarcado
                              ? "border-brand-500 bg-brand-600/30 text-white font-bold"
                              : "border-surface-border bg-surface-overlay text-slate-400 hover:text-white"
                          }`}
                        >
                          {item.numero_patrimonio}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Resumo da seleção */}
              <div className="flex items-center justify-between text-xs pt-1 border-t border-brand-500/20">
                <span className="text-white font-semibold">
                  {itensSelecionados.length} computadores selecionados
                </span>
                <span className="text-brand-300 font-medium text-[11px] truncate max-w-[200px]" title={faixaTexto}>
                  {faixaTexto}
                </span>
              </div>

              {/* Aviso se houver itens avariados ignorados */}
              {emManutencao.length > 0 && (
                <div className="flex items-center gap-1.5 text-[11px] text-amber-400 bg-amber-500/10 p-2 rounded-lg border border-amber-500/20">
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                  <span>
                    {emManutencao.length} computador(es) em manutenção foram excluídos da reserva automaticamente.
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Disciplina */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Disciplina / Conteúdo (Opcional)
            </label>
            <input
              name="disciplina"
              type="text"
              autoComplete="off"
              data-lpignore="true"
              placeholder="Ex: Matemática, Robótica, Projeto Integrador..."
              className="w-full rounded-xl border border-surface-border bg-surface-base py-2.5 px-3.5 text-xs text-white outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 placeholder:text-slate-500"
            />
          </div>

          {/* Observações */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Observações (Opcional)
            </label>
            <input
              name="observacoes"
              type="text"
              autoComplete="off"
              data-lpignore="true"
              placeholder="Ex: Uso de softwares específicos, sala invertida..."
              className="w-full rounded-xl border border-surface-border bg-surface-base py-2.5 px-3.5 text-xs text-white outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-500/20 placeholder:text-slate-500"
            />
          </div>

          {/* Substituição de Aula */}
          <div className="pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
              <input
                type="checkbox"
                name="is_substituicao"
                checked={isSubstituicao}
                onChange={(e) => setIsSubstituicao(e.target.checked)}
                className="h-4 w-4 rounded accent-brand-500"
              />
              <span>É uma aula de substituição?</span>
            </label>

            {isSubstituicao && (
              <div className="mt-2.5 rounded-xl border border-surface-border bg-surface-overlay/50 p-3">
                <label className="block text-xs text-slate-400 mb-1">
                  Professor Titular Sendo Substituído:
                </label>
                <select
                  name="professor_substituto_id"
                  className="w-full rounded-lg border border-surface-border bg-surface-base py-2 px-3 text-xs text-white outline-none focus:border-brand-500"
                >
                  <option value="">Selecione o professor titular...</option>
                  {professores.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.nome_completo || p.email}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {/* Botões de Ação */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-surface-border">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl border border-surface-border px-4 py-2.5 text-xs font-medium text-slate-300 hover:bg-surface-overlay transition"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={turmas.length === 0 || (temItens && itensSelecionados.length === 0)}
              className="btn-primary"
            >
              Confirmar Reserva
            </button>
          </div>
        </ActionForm>
      </div>
    </div>
  );
}