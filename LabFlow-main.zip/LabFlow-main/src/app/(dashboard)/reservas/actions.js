"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentProfile } from "@/lib/auth";

export async function criarReserva(prevState, formData) {
  const profile = await getCurrentProfile();
  if (!profile || !profile.escola_id) {
    return { error: "Você precisa estar vinculado a uma escola para fazer reservas." };
  }

  const supabase = createClient();

  const recurso_id = formData.get("recurso_id")?.toString();
  const horario_id = formData.get("horario_id")?.toString();
  const data_reserva = formData.get("data_reserva")?.toString();
  const turma_id = formData.get("turma_id")?.toString();
  const disciplina = formData.get("disciplina")?.toString().trim() || null;
  const observacoes = formData.get("observacoes")?.toString().trim() || null;
  const is_substituicao = formData.get("is_substituicao") === "on";
  const professor_substituto_id =
    formData.get("professor_substituto_id")?.toString() || null;
  const faixa_itens = formData.get("faixa_itens")?.toString() || null;
  const itens_reservados_raw = formData.get("itens_reservados")?.toString();

  let itens_reservados = null;
  if (itens_reservados_raw) {
    try {
      itens_reservados = JSON.parse(itens_reservados_raw);
    } catch {
      itens_reservados = null;
    }
  }

  if (!recurso_id || !horario_id || !data_reserva || !turma_id) {
    return { error: "Selecione o recurso, horário, turma e data para a reserva." };
  }

  const { error } = await supabase.from("reservas").insert({
    escola_id: profile.escola_id,
    recurso_id,
    horario_id,
    data_reserva,
    turma_id,
    disciplina,
    observacoes,
    professor_id: profile.id,
    is_substituicao,
    professor_substituto_id: is_substituicao ? professor_substituto_id : null,
    status: "RESERVADO",
    itens_reservados,
    faixa_itens,
  });

  if (error) {
    if (error.message?.includes("unique_reserva_horario")) {
      return {
        error: "Este recurso já foi reservado por outro docente para este mesmo horário.",
      };
    }
    if (error.message?.includes("exclusivo para o curso de Desenvolvimento de Sistemas")) {
      return {
        error: "Este recurso é exclusivo para docentes do curso técnico em Desenvolvimento de Sistemas.",
      };
    }
    return { error: error.message };
  }

  revalidatePath("/reservas");
  revalidatePath("/");
  return { success: "Reserva confirmada com sucesso!" };
}

export async function cancelarReserva(reservaId) {
  const profile = await getCurrentProfile();
  if (!profile) return { error: "Não autenticado." };

  const supabase = createClient();

  // Busca a reserva para validar se o usuário é o dono ou gestor
  const { data: reserva, error: fetchErr } = await supabase
    .from("reservas")
    .select("id, professor_id, escola_id")
    .eq("id", reservaId)
    .single();

  if (fetchErr || !reserva) {
    return { error: "Reserva não encontrada." };
  }

  const isDono = reserva.professor_id === profile.id;
  const isGestor = ["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"].includes(profile.role);

  if (!isDono && !isGestor) {
    return { error: "Você só pode cancelar suas próprias reservas." };
  }

  const { error } = await supabase
    .from("reservas")
    .update({ status: "CANCELADO" })
    .eq("id", reservaId);

  if (error) return { error: error.message };

  revalidatePath("/reservas");
  revalidatePath("/");
  return { success: "Reserva cancelada com sucesso." };
}

export async function registrarCheckin(reservaId) {
  const profile = await getCurrentProfile();
  if (!profile) return { error: "Não autenticado." };

  const supabase = createClient();
  const { error } = await supabase
    .from("reservas")
    .update({ checkin_at: new Date().toISOString(), status: "EM_USO" })
    .eq("id", reservaId);

  if (error) return { error: error.message };

  revalidatePath("/reservas");
  revalidatePath("/");
  return { success: "Check-in realizado. Equipamento em uso." };
}

export async function registrarCheckout(reservaId) {
  const profile = await getCurrentProfile();
  if (!profile) return { error: "Não autenticado." };

  const supabase = createClient();
  const { error } = await supabase
    .from("reservas")
    .update({ checkout_at: new Date().toISOString(), status: "CONCLUIDO" })
    .eq("id", reservaId);

  if (error) return { error: error.message };

  revalidatePath("/reservas");
  revalidatePath("/");
  return { success: "Check-out realizado. Equipamento liberado." };
}
