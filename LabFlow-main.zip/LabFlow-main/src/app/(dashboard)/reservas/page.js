import { getCurrentProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import ReservasGrid from "./ReservasGrid";
import { CalendarDays, AlertTriangle } from "lucide-react";

export default async function ReservasPage() {
  const profile = await getCurrentProfile();

  if (!profile?.escola_id && profile?.role !== "ADMIN") {
    return (
      <div className="panel p-6 border-amber-500/30 bg-amber-500/10 space-y-2">
        <div className="flex items-center gap-2 text-amber-400 font-semibold text-sm">
          <AlertTriangle className="h-5 w-5" />
          Escola não vinculada
        </div>
        <p className="text-xs text-slate-300">
          Você precisa estar vinculado a uma escola para visualizar e agendar recursos.
          Solicite o vínculo à equipe gestora da sua unidade.
        </p>
      </div>
    );
  }

  const supabase = createClient();
  const escolaId = profile.escola_id;

  // Busca recursos, horários, turmas, professores, reservas ativas e itens individuais
  const [
    { data: recursos },
    { data: horarios },
    { data: turmas },
    { data: professores },
    { data: reservas },
    { data: itensRecurso },
  ] = await Promise.all([
    supabase.from("recursos").select("*").eq("escola_id", escolaId).order("nome"),
    supabase
      .from("grade_horarios")
      .select("*")
      .eq("escola_id", escolaId)
      .eq("ativo", true)
      .order("ordem"),
    supabase
      .from("turmas")
      .select("*")
      .eq("escola_id", escolaId)
      .eq("ativo", true)
      .order("serie"),
    supabase
      .from("profiles")
      .select("id, nome_completo, email")
      .eq("escola_id", escolaId)
      .order("nome_completo"),
    supabase
      .from("reservas")
      .select(
        "id, escola_id, recurso_id, horario_id, professor_id, data_reserva, status, turma_id, disciplina, observacoes, faixa_itens, itens_reservados, professor:professor_id(id, nome_completo, email), turmas:turma_id(id, serie, identificador)"
      )
      .eq("escola_id", escolaId)
      .neq("status", "CANCELADO"),
    supabase
      .from("itens_recurso")
      .select("id, recurso_id, numero_patrimonio, descricao, status")
      .order("numero_patrimonio"),
  ]);

  return (
    <div className="space-y-6">
      <header>
        <div className="flex items-center gap-2 text-brand-400 text-xs font-semibold uppercase tracking-wider mb-1">
          <CalendarDays className="h-4 w-4" />
          Agendamento Oficial
        </div>
        <h1 className="text-2xl font-bold text-white tracking-tight">Grade de Reservas</h1>
        <p className="text-sm text-slate-400">
          Reserve carrinhos de notebooks e laboratórios de informática por dia e horário sem choque de agenda.
        </p>
      </header>

      <ReservasGrid
        recursos={recursos || []}
        horarios={horarios || []}
        reservas={reservas || []}
        turmas={turmas || []}
        professores={professores || []}
        itensRecurso={itensRecurso || []}
        profile={profile}
      />
    </div>
  );
}
