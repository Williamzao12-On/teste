"use client";

import { useState, useTransition } from "react";
import ReservaModal from "./ReservaModal";
import { cancelarReserva, registrarCheckin, registrarCheckout } from "./actions";
import { useToast } from "@/components/ToastProvider";
import {
  CalendarDays,
  Clock,
  Laptop,
  Building2,
  Lock,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Coffee,
  Plus,
  Trash2,
  Play,
  CheckCheck,
  ChevronLeft,
  ChevronRight,
  Filter,
  Loader2,
} from "lucide-react";

const TURNOS = [
  { key: "MANHA", label: "Manhã" },
  { key: "TARDE", label: "Tarde" },
  { key: "NOITE", label: "Noite" },
  { key: "INTEGRAL", label: "Integral" },
];

export default function ReservasGrid({
  recursos = [],
  horarios = [],
  reservas = [],
  turmas = [],
  professores = [],
  itensRecurso = [],
  profile,
}) {
  // Data de hoje padrão YYYY-MM-DD
  const hojeStr = new Date().toISOString().split("T")[0];
  const [dataSelecionada, setDataSelecionada] = useState(hojeStr);
  const [turnoAtivo, setTurnoAtivo] = useState("MANHA");
  const [modalData, setModalData] = useState(null); // { recurso, horario }
  const [isPending, startTransition] = useTransition();
  const toast = useToast();

  const isGestor = ["DIRETOR", "GESTOR_ESCOLAR", "ADMIN"].includes(profile.role);
  const isDsAuthorized = profile.is_ds_authorized || profile.role === "DOCENTE_DS";

  // Horários do turno selecionado
  const horariosDoTurno = horarios
    .filter((h) => h.turno === turnoAtivo)
    .sort((a, b) => a.ordem - b.ordem);

  // Mapa rápido de reservas: "recursoId_horarioId"
  const reservasMap = {};
  for (const r of reservas) {
    if (r.data_reserva === dataSelecionada && r.status !== "CANCELADO") {
      reservasMap[`${r.recurso_id}_${r.horario_id}`] = r;
    }
  }

  // Navegação de datas (anterior / próximo)
  function mudarDia(delta) {
    const d = new Date(dataSelecionada + "T00:00:00");
    d.setDate(d.getDate() + delta);
    setDataSelecionada(d.toISOString().split("T")[0]);
  }

  function handleCancelar(reservaId) {
    if (!window.confirm("Deseja realmente cancelar esta reserva?")) return;
    startTransition(async () => {
      const res = await cancelarReserva(reservaId);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Reserva cancelada.");
    });
  }

  function handleCheckin(reservaId) {
    startTransition(async () => {
      const res = await registrarCheckin(reservaId);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Check-in realizado!");
    });
  }

  function handleCheckout(reservaId) {
    startTransition(async () => {
      const res = await registrarCheckout(reservaId);
      if (res?.error) toast.error(res.error);
      else toast.success(res?.success || "Check-out realizado!");
    });
  }

  // Formatação bonita da data
  const dataFormatada = new Date(dataSelecionada + "T00:00:00").toLocaleDateString(
    "pt-BR",
    {
      weekday: "long",
      day: "2-digit",
      month: "long",
      year: "numeric",
    }
  );

  return (
    <div className="space-y-6">
      {/* Barra de Controle: Data e Turno */}
      <div className="panel space-y-4 p-4 sm:p-5">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          {/* Navegador de Data */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => mudarDia(-1)}
              title="Dia anterior"
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-surface-border bg-surface-overlay text-slate-300 hover:text-white transition"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>

            <div className="relative">
              <input
                type="date"
                value={dataSelecionada}
                onChange={(e) => setDataSelecionada(e.target.value)}
                className="rounded-xl border border-surface-border bg-surface-overlay px-3 py-1.5 text-xs sm:text-sm font-semibold text-white outline-none focus:border-brand-500"
              />
            </div>

            <button
              type="button"
              onClick={() => mudarDia(1)}
              title="Próximo dia"
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-surface-border bg-surface-overlay text-slate-300 hover:text-white transition"
            >
              <ChevronRight className="h-4 w-4" />
            </button>

            {dataSelecionada !== hojeStr && (
              <button
                type="button"
                onClick={() => setDataSelecionada(hojeStr)}
                className="text-xs font-semibold text-brand-400 hover:underline ml-1"
              >
                Hoje
              </button>
            )}
          </div>

          {/* Seletor de Turno */}
          <div className="flex items-center gap-1.5 p-1 bg-surface-overlay rounded-xl border border-surface-border self-start sm:self-auto">
            {TURNOS.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => setTurnoAtivo(t.key)}
                className={`rounded-lg px-3 py-1 text-xs font-semibold transition ${
                  turnoAtivo === t.key
                    ? "bg-brand-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-slate-200"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400 capitalize pt-1 border-t border-surface-border/50">
          <CalendarDays className="h-3.5 w-3.5 text-brand-400 shrink-0" />
          <span>{dataFormatada}</span>
        </div>
      </div>

      {/* Grade de Reservas */}
      {horariosDoTurno.length === 0 ? (
        <div className="panel py-12 text-center space-y-3">
          <Clock className="mx-auto h-8 w-8 text-slate-500" />
          <h3 className="text-sm font-semibold text-white">
            Nenhum horário cadastrado para o turno {TURNOS.find((t) => t.key === turnoAtivo)?.label}
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            A equipe gestora precisa cadastrar os períodos de aula em &quot;Grade de Horários&quot; para que os recursos possam ser agendados.
          </p>
        </div>
      ) : recursos.length === 0 ? (
        <div className="panel py-12 text-center space-y-3">
          <Laptop className="mx-auto h-8 w-8 text-slate-500" />
          <h3 className="text-sm font-semibold text-white">Nenhum recurso cadastrado</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Não há carrinhos de notebook ou laboratórios registrados nesta escola.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {/* Visualização Desktop (Tabela / Matriz de Horários) */}
          <div className="hidden lg:block overflow-x-auto rounded-2xl border border-surface-border bg-surface-raised">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-surface-border bg-surface-overlay/80 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  <th className="p-3.5 min-w-[200px] border-r border-surface-border">Recurso</th>
                  {horariosDoTurno.map((h) => (
                    <th
                      key={h.id}
                      className={`p-3 text-center border-r border-surface-border/60 min-w-[130px] ${
                        h.is_intervalo ? "bg-amber-500/5 text-amber-300" : ""
                      }`}
                    >
                      <span className="block text-slate-200">{h.label}</span>
                      <span className="text-[10px] text-slate-500 font-normal">
                        {h.hora_inicio?.slice(0, 5)} - {h.hora_fim?.slice(0, 5)}
                      </span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-surface-border text-xs">
                {recursos.map((rec) => {
                  const isBloqueado = rec.status !== "DISPONIVEL";
                  const isDsBloqueado = rec.exclusivo_ds && !isDsAuthorized;

                  return (
                    <tr key={rec.id} className="hover:bg-surface-overlay/30 transition">
                      {/* Coluna do Recurso */}
                      <td className="p-3.5 border-r border-surface-border">
                        <div className="flex items-center gap-2">
                          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-surface-overlay text-brand-400 shrink-0">
                            {rec.tipo === "CARRINHO_NOTEBOOK" ? (
                              <Laptop className="h-4 w-4" />
                            ) : (
                              <Building2 className="h-4 w-4" />
                            )}
                          </div>
                          <div>
                            <span className="font-semibold text-white block truncate max-w-[180px]">
                              {rec.nome}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {rec.tipo === "CARRINHO_NOTEBOOK"
                                ? `${rec.quantidade_itens || 0} notebooks`
                                : "Laboratório"}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Células de Horários */}
                      {horariosDoTurno.map((h) => {
                        if (h.is_intervalo) {
                          return (
                            <td
                              key={h.id}
                              className="p-2 border-r border-surface-border/60 bg-amber-500/5 text-center text-slate-500"
                            >
                              <Coffee className="h-4 w-4 mx-auto opacity-40 text-amber-400" />
                            </td>
                          );
                        }

                        if (isBloqueado) {
                          return (
                            <td
                              key={h.id}
                              className="p-2 border-r border-surface-border/60 text-center bg-red-950/10"
                            >
                              <span className="text-[10px] text-red-400 font-medium">
                                Manutenção
                              </span>
                            </td>
                          );
                        }

                        if (isDsBloqueado) {
                          return (
                            <td
                              key={h.id}
                              className="p-2 border-r border-surface-border/60 text-center bg-surface-overlay/30"
                            >
                              <span className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
                                <Lock className="h-3 w-3" /> Exclusivo DS
                              </span>
                            </td>
                          );
                        }

                        const reserva = reservasMap[`${rec.id}_${h.id}`];

                        if (reserva) {
                          const isMinha = reserva.professor_id === profile.id;
                          const nomeProf =
                            reserva.professor?.nome_completo ||
                            reserva.professor?.email?.split("@")[0];

                          return (
                            <td
                              key={h.id}
                              className={`p-2 border-r border-surface-border/60 ${
                                isMinha
                                  ? "bg-brand-600/15 border-l-2 border-l-brand-500"
                                  : "bg-surface-overlay/80"
                              }`}
                            >
                              <div className="space-y-1">
                                <span className="font-semibold text-white block truncate text-[11px]">
                                  {nomeProf}
                                </span>
                                {reserva.turmas && (
                                  <span className="block text-[10px] text-brand-300 font-medium truncate">
                                    {reserva.turmas.serie} {reserva.turmas.identificador}
                                  </span>
                                )}
                                {reserva.faixa_itens && (
                                  <span className="block text-[10px] text-amber-300/90 font-medium truncate" title={reserva.faixa_itens}>
                                    {reserva.faixa_itens}
                                  </span>
                                )}

                                {(isMinha || isGestor) && (
                                  <div className="flex items-center gap-1 pt-1">
                                    {reserva.status === "RESERVADO" && isMinha && (
                                      <button
                                        type="button"
                                        onClick={() => handleCheckin(reserva.id)}
                                        title="Check-in (Em uso)"
                                        className="text-[10px] text-emerald-400 hover:underline"
                                      >
                                        Check-in
                                      </button>
                                    )}
                                    {reserva.status === "EM_USO" && isMinha && (
                                      <button
                                        type="button"
                                        onClick={() => handleCheckout(reserva.id)}
                                        title="Check-out (Finalizar)"
                                        className="text-[10px] text-cyan-400 hover:underline"
                                      >
                                        Check-out
                                      </button>
                                    )}
                                    <button
                                      type="button"
                                      onClick={() => handleCancelar(reserva.id)}
                                      title="Cancelar reserva"
                                      className="text-[10px] text-red-400 hover:underline ml-auto"
                                    >
                                      Cancelar
                                    </button>
                                  </div>
                                )}
                              </div>
                            </td>
                          );
                        }

                        // Slot Livre: Botão de Reservar
                        return (
                          <td
                            key={h.id}
                            className="p-2 border-r border-surface-border/60 text-center"
                          >
                            <button
                              type="button"
                              onClick={() => setModalData({ recurso: rec, horario: h })}
                              className="w-full py-2 rounded-lg border border-dashed border-surface-border text-[11px] font-semibold text-slate-400 hover:border-brand-500 hover:bg-brand-500/10 hover:text-brand-300 transition"
                            >
                              + Reservar
                            </button>
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Visualização Mobile (Cards Responsivos de Recursos) */}
          <div className="lg:hidden space-y-4">
            {recursos.map((rec) => {
              const isBloqueado = rec.status !== "DISPONIVEL";
              const isDsBloqueado = rec.exclusivo_ds && !isDsAuthorized;

              return (
                <div key={rec.id} className="panel p-4 space-y-3">
                  <div className="flex items-center justify-between border-b border-surface-border pb-2.5">
                    <div className="flex items-center gap-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-surface-overlay text-brand-400 shrink-0">
                        {rec.tipo === "CARRINHO_NOTEBOOK" ? (
                          <Laptop className="h-4 w-4" />
                        ) : (
                          <Building2 className="h-4 w-4" />
                        )}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">{rec.nome}</h4>
                        <p className="text-[10px] text-slate-400">
                          {rec.tipo === "CARRINHO_NOTEBOOK"
                            ? `${rec.quantidade_itens || 0} notebooks`
                            : "Laboratório"}
                        </p>
                      </div>
                    </div>

                    {isBloqueado ? (
                      <span className="rounded-full bg-red-500/15 px-2 py-0.5 text-[10px] font-semibold text-red-400">
                        Manutenção
                      </span>
                    ) : isDsBloqueado ? (
                      <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] font-medium text-slate-400 flex items-center gap-1">
                        <Lock className="h-3 w-3" /> DS
                      </span>
                    ) : (
                      <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-semibold text-emerald-400">
                        Ativo
                      </span>
                    )}
                  </div>

                  {/* Slots de Horários no Mobile */}
                  <div className="grid grid-cols-2 gap-2">
                    {horariosDoTurno.map((h) => {
                      if (h.is_intervalo) return null;

                      const reserva = reservasMap[`${rec.id}_${h.id}`];
                      const isMinha = reserva && reserva.professor_id === profile.id;

                      if (reserva) {
                        return (
                          <div
                            key={h.id}
                            className={`p-2.5 rounded-xl border text-xs space-y-1 ${
                              isMinha
                                ? "border-brand-500 bg-brand-600/15"
                                : "border-surface-border bg-surface-overlay"
                            }`}
                          >
                            <div className="flex items-center justify-between text-[10px]">
                              <span className="font-semibold text-brand-400">{h.label}</span>
                              <span className="text-slate-500">{h.hora_inicio?.slice(0, 5)}</span>
                            </div>
                            <p className="text-xs font-semibold text-white truncate">
                              {reserva.professor?.nome_completo || reserva.professor?.email}
                            </p>
                            {reserva.turmas && (
                              <p className="text-[10px] text-slate-300 truncate">
                                {reserva.turmas.serie} {reserva.turmas.identificador}
                              </p>
                            )}
                            {reserva.faixa_itens && (
                              <p className="text-[10px] text-amber-300/90 font-medium truncate" title={reserva.faixa_itens}>
                                {reserva.faixa_itens}
                              </p>
                            )}

                            {(isMinha || isGestor) && (
                              <button
                                type="button"
                                onClick={() => handleCancelar(reserva.id)}
                                className="text-[10px] text-red-400 hover:underline pt-1 block"
                              >
                                Cancelar
                              </button>
                            )}
                          </div>
                        );
                      }

                      return (
                        <button
                          key={h.id}
                          type="button"
                          disabled={isBloqueado || isDsBloqueado}
                          onClick={() => setModalData({ recurso: rec, horario: h })}
                          className="p-2.5 rounded-xl border border-dashed border-surface-border text-left hover:border-brand-500 hover:bg-brand-500/10 transition disabled:opacity-40"
                        >
                          <div className="flex items-center justify-between text-[10px] text-slate-400">
                            <span>{h.label}</span>
                            <span>{h.hora_inicio?.slice(0, 5)}</span>
                          </div>
                          <span className="text-xs font-semibold text-slate-200 flex items-center gap-1 mt-1">
                            <Plus className="h-3 w-3 text-brand-400" /> Reservar
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Modal de Confirmação de Reserva */}
      {modalData && (
        <ReservaModal
          recurso={modalData.recurso}
          horario={modalData.horario}
          dataSelecionada={dataSelecionada}
          turmas={turmas}
          professores={professores}
          itens={itensRecurso}
          onClose={() => setModalData(null)}
        />
      )}
    </div>
  );
}
