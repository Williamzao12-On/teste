"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";
import {
  Mail,
  Lock,
  Link2,
  Loader2,
  ArrowRight,
  LayoutGrid,
  MailCheck,
} from "lucide-react";

// URL canônica do site — definida uma vez via env, nunca via window.location.origin
// (isso evita cair em URLs de preview/deploy pessoal da Vercel durante o teste).
function getCallbackUrl() {
  const base = process.env.NEXT_PUBLIC_SITE_URL || window.location.origin;
  return `${base}/auth/callback`;
}

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const supabase = createClient();
  const searchParams = useSearchParams();

  const [tab, setTab] = useState("senha"); // 'senha' | 'link'
  const [linkEnviado, setLinkEnviado] = useState(false);

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(searchParams.get("error") || "");

  function switchTab(nextTab) {
    setTab(nextTab);
    setErrorMsg("");
    setLinkEnviado(false);
  }

  async function handleGoogleLogin() {
    setErrorMsg("");
    setLoading(true);
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: getCallbackUrl(),
        queryParams: {
          // Restringe ao domínio institucional, se aplicável na sua rede
          hd: "educacao.sp.gov.br",
        },
      },
    });
    if (error) {
      setErrorMsg("Não foi possível iniciar o login com Google. Tente novamente.");
      setLoading(false);
    }
    // Em caso de sucesso o navegador é redirecionado, então não é necessário
    // setLoading(false) aqui.
  }

  async function handleLoginComSenha(e) {
    e.preventDefault();
    setErrorMsg("");
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password: senha,
    });

    setLoading(false);
    if (error) {
      setErrorMsg("E-mail ou senha inválidos.");
      return;
    }
    window.location.href = "/";
  }

  async function handleEnviarLinkMagico(e) {
    e.preventDefault();
    setErrorMsg("");
    setLoading(true);

    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        shouldCreateUser: true,
        emailRedirectTo: getCallbackUrl(),
      },
    });

    setLoading(false);
    if (error) {
      setErrorMsg("Não foi possível enviar o link. Verifique o e-mail digitado.");
      return;
    }
    setLinkEnviado(true);
  }

  return (
    <main className="relative flex min-h-screen">
      {/* Painel de marca — só aparece em telas largas, é aqui que mora a
          identidade visual de verdade, não só cor e fonte */}
      <aside className="relative hidden w-[44%] shrink-0 overflow-hidden border-r border-surface-border bg-surface-raised lg:flex lg:flex-col lg:justify-between lg:p-12">
        <div
          className="pointer-events-none absolute -left-24 -top-24 h-96 w-96 rounded-full opacity-30 blur-3xl"
          style={{ backgroundImage: "linear-gradient(135deg, #4d7fff, #7a5cf0)" }}
        />
        <div
          className="pointer-events-none absolute -bottom-32 -right-16 h-80 w-80 rounded-full opacity-20 blur-3xl"
          style={{ backgroundImage: "linear-gradient(135deg, #e8873a, #4d7fff)" }}
        />

        <div className="relative flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-brand-gradient text-white shadow-glow">
            <LayoutGrid className="h-5 w-5" />
          </div>
          <span className="text-lg font-bold text-white">LabFlow</span>
        </div>

        <div className="relative">
          <SchedulingIllustration />
          <h2 className="mt-8 max-w-sm text-2xl font-bold leading-snug text-white">
            Carrinhos e laboratórios, reservados sem choque de horário.
          </h2>
          <p className="mt-3 max-w-sm text-sm text-slate-400">
            Cada recurso da escola, cada turma, cada horário — num só lugar, com trava automática
            contra duplo agendamento.
          </p>
        </div>

        <p className="relative text-xs text-slate-500">
          Rede Estadual de Ensino de São Paulo — SEDUC/SP
        </p>
      </aside>

      {/* Formulário */}
      <div className="relative flex flex-1 items-center justify-center px-4 py-10">
        <div
          className="pointer-events-none absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-20 blur-3xl lg:hidden"
          style={{ backgroundImage: "linear-gradient(135deg, #4d7fff, #7a5cf0)" }}
        />

        <div className="relative w-full max-w-md">
          {/* Cabeçalho / marca — só no mobile, no desktop já tem o painel */}
          <div className="mb-10 flex flex-col items-center gap-3 text-center lg:hidden">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand-gradient text-white shadow-glow">
              <LayoutGrid className="h-7 w-7" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">LabFlow</h1>
              <p className="mt-1 text-sm text-slate-400">
                Reserva de carrinhos e laboratórios da sua escola
              </p>
            </div>
          </div>

        {/* Card */}
        <div className="panel p-7 shadow-2xl shadow-black/40 sm:p-8">
          {/* Botão Google — sempre visível no topo */}
          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={loading}
            className="flex w-full items-center justify-center gap-3 rounded-xl border border-surface-border bg-surface-overlay px-4 py-3 text-sm font-medium text-slate-200 transition hover:bg-surface-border disabled:opacity-60"
          >
            <GoogleIcon />
            Entrar com Google (Institucional)
          </button>

          <div className="my-7 flex items-center gap-3">
            <div className="h-px flex-1 bg-surface-border" />
            <span className="text-xs uppercase tracking-wide text-slate-500">ou</span>
            <div className="h-px flex-1 bg-surface-border" />
          </div>

          {/* Tabs: Senha vs Código OTP */}
          <div className="mb-6 grid grid-cols-2 gap-1 rounded-xl bg-surface-overlay p-1.5">
            <TabButton
              active={tab === "senha"}
              onClick={() => switchTab("senha")}
              icon={<Lock className="h-4 w-4" />}
              label="Senha"
            />
            <TabButton
              active={tab === "link"}
              onClick={() => switchTab("link")}
              icon={<Link2 className="h-4 w-4" />}
              label="Link por e-mail"
            />
          </div>

          {/* Mensagens */}
          {errorMsg && (
            <p className="mb-5 rounded-lg bg-red-950/40 px-3 py-2.5 text-sm text-red-400">
              {errorMsg}
            </p>
          )}

          {/* Formulário: Login com Senha */}
          {tab === "senha" && (
            <form onSubmit={handleLoginComSenha} className="space-y-5">
              <FieldEmail email={email} setEmail={setEmail} />
              <FieldSenha senha={senha} setSenha={setSenha} />
              <SubmitButton loading={loading} label="Entrar" />
            </form>
          )}

          {/* Formulário: Enviar link mágico */}
          {tab === "link" && !linkEnviado && (
            <form onSubmit={handleEnviarLinkMagico} className="space-y-5">
              <FieldEmail email={email} setEmail={setEmail} />
              <SubmitButton loading={loading} label="Enviar link de acesso" />
            </form>
          )}

          {/* Confirmação: link enviado */}
          {tab === "link" && linkEnviado && (
            <div className="space-y-5 text-center">
              <div className="flex flex-col items-center gap-2 rounded-xl bg-brand-500/10 px-4 py-7">
                <MailCheck className="h-8 w-8 text-brand-500" />
                <p className="text-sm font-medium text-brand-400">
                  Enviamos um link de acesso para
                </p>
                <p className="text-sm font-semibold text-slate-100">{email}</p>
                <p className="text-xs text-slate-400">
                  Abra seu e-mail neste mesmo aparelho e toque no link para entrar.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setLinkEnviado(false)}
                className="w-full text-center text-xs text-slate-400 underline-offset-2 hover:underline"
              >
                Reenviar link / trocar e-mail
              </button>
            </div>
          )}
        </div>

        <p className="mt-7 text-center text-xs text-slate-500 lg:hidden">
          Rede Estadual de Ensino de São Paulo — SEDUC/SP
        </p>
      </div>
      </div>
    </main>
  );
}

// =========================================================
// Subcomponentes
// =========================================================

function TabButton({ active, onClick, icon, label }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex items-center justify-center gap-1.5 rounded-md py-2 text-sm font-medium transition",
        active
          ? "bg-surface-raised text-brand-400 shadow-sm"
          : "text-slate-400 hover:text-slate-200"
      )}
    >
      {icon}
      {label}
    </button>
  );
}

function FieldEmail({ email, setEmail }) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium text-slate-300">
        E-mail institucional
      </label>
      <div className="relative">
        <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        <input
          type="email"
          placeholder="seu.email@escola.sp.gov.br"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="w-full rounded-xl border border-surface-border bg-surface-overlay py-3 pl-10 pr-4 text-sm text-white outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4"
        />
      </div>
    </div>
  );
}

function FieldSenha({ senha, setSenha }) {
  return (
    <div>
      <label className="mb-2 block text-sm font-medium text-slate-300">Senha</label>
      <div className="relative">
        <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
        <input
          type="password"
          placeholder="••••••••"
          value={senha}
          onChange={(e) => setSenha(e.target.value)}
          required
          className="w-full rounded-xl border border-surface-border bg-surface-overlay py-3 pl-10 pr-4 text-sm text-white outline-none ring-brand-500/40 transition focus:border-brand-500 focus:ring-4"
        />
      </div>
    </div>
  );
}

function SubmitButton({ loading, label }) {
  return (
    <button
      type="submit"
      disabled={loading}
      className="flex w-full items-center justify-center gap-2 rounded-xl btn-primary py-3"
    >
      {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4" />}
      {label}
    </button>
  );
}

function SchedulingIllustration() {
  return (
    <svg
      width="280"
      height="140"
      viewBox="0 0 280 140"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="opacity-90"
    >
      {/* Grade de horários — pontos representando slots, alguns "reservados" */}
      {Array.from({ length: 5 }).map((_, row) =>
        Array.from({ length: 8 }).map((_, col) => {
          const reservado = (row === 1 && col === 3) || (row === 3 && col === 5) || (row === 2 && col === 1);
          return (
            <circle
              key={`${row}-${col}`}
              cx={16 + col * 18}
              cy={16 + row * 20}
              r={reservado ? 5 : 3}
              fill={reservado ? "url(#gradDot)" : "#26324a"}
            />
          );
        })
      )}

      {/* Carrinho de notebook estilizado */}
      <g transform="translate(178, 60)">
        <rect x="0" y="0" width="72" height="46" rx="8" stroke="url(#gradStroke)" strokeWidth="2" />
        <rect x="10" y="10" width="20" height="14" rx="2" stroke="#4d7fff" strokeWidth="1.5" />
        <rect x="36" y="10" width="20" height="14" rx="2" stroke="#4d7fff" strokeWidth="1.5" />
        <line x1="10" y1="34" x2="56" y2="34" stroke="#4d7fff" strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="14" cy="52" r="4" fill="#26324a" />
        <circle cx="58" cy="52" r="4" fill="#26324a" />
      </g>

      <defs>
        <linearGradient id="gradDot" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#4d7fff" />
          <stop offset="1" stopColor="#7a5cf0" />
        </linearGradient>
        <linearGradient id="gradStroke" x1="0" y1="0" x2="1" y2="1">
          <stop stopColor="#4d7fff" />
          <stop offset="1" stopColor="#e8873a" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function GoogleIcon() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 24 24">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
      />
    </svg>
  );
}
