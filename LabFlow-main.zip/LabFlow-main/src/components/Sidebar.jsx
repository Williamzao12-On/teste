"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Building2,
  Laptop,
  Users2,
  GraduationCap,
  LogOut,
  ShieldCheck,
  CalendarDays,
  User,
  Menu,
  X,
  Clock,
  AlertTriangle,
  FileCheck2,
} from "lucide-react";

export default function Sidebar({ profile }) {
  const pathname = usePathname();
  const supabase = createClient();
  const [openDrawer, setOpenDrawer] = useState(false);

  const isAdmin = profile?.role === "ADMIN";
  const isGestor = profile?.role === "DIRETOR" || profile?.role === "GESTOR_ESCOLAR";

  useEffect(() => {
    setOpenDrawer(false);
  }, [pathname]);

  async function handleLogout() {
    await supabase.auth.signOut();
    window.location.href = "/login";
  }

  // Grupos de navegação para Desktop e Drawer Mobile
  const grupos = [
    {
      titulo: "Principal",
      links: [
        { href: "/", label: "Início", icon: LayoutDashboard, exact: true },
        { href: "/reservas", label: "Grade de Reservas", icon: CalendarDays },
        { href: "/incidentes", label: "Zelo & Incidentes", icon: AlertTriangle },
      ],
    },
    {
      titulo: "Gestão da Escola",
      mostrar: isGestor || isAdmin,
      links: [
        { href: "/gestor/recursos", label: "Carrinhos & Labs", icon: Laptop },
        { href: "/gestor/horarios", label: "Grade de Horários", icon: Clock },
        { href: "/gestor/turmas", label: "Séries & Turmas", icon: GraduationCap },
        { href: "/gestor/usuarios", label: "Docentes da Escola", icon: Users2 },
      ],
    },
    {
      titulo: "Administração",
      mostrar: isAdmin,
      links: [
        { href: "/admin", label: "Controle da Rede", icon: ShieldCheck },
      ],
    },
  ];

  return (
    <>
      {/* Barra superior Mobile: Compacta, Institucional e Limpa */}
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-surface-border bg-surface-raised/80 backdrop-blur-md px-4 pt-[env(safe-area-inset-top)] lg:hidden">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-white shadow-sm font-bold text-xs">
            LF
          </div>
          <div className="overflow-hidden">
            <span className="block text-xs font-bold text-white leading-tight truncate">
              {profile?.escolas?.nome || "LabFlow SEDUC"}
            </span>
            <span className="block text-[10px] text-slate-400 font-medium truncate">
              {profile?.role === "ADMIN"
                ? "Administração Geral"
                : profile?.escolas?.diretoria_ensino || "Rede Estadual"}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setOpenDrawer(true)}
          aria-label="Abrir menu completo"
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-surface-border bg-surface-overlay text-slate-300 active:scale-95"
        >
          <Menu className="h-4 w-4" />
        </button>
      </header>

      {/* Drawer Mobile (apenas para opções completas / logout) */}
      {openDrawer && (
        <div
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm lg:hidden animate-fade-in"
          onClick={() => setOpenDrawer(false)}
        >
          <div
            className="fixed inset-y-0 right-0 w-72 max-w-[85vw] border-l border-surface-border bg-surface-raised p-5 shadow-2xl flex flex-col justify-between"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              <div className="flex items-center justify-between border-b border-surface-border pb-4 mb-4">
                <div className="flex items-center gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-brand-600 text-white font-bold text-xs">
                    LF
                  </div>
                  <span className="text-sm font-bold text-white">Menu LabFlow</span>
                </div>
                <button
                  type="button"
                  onClick={() => setOpenDrawer(false)}
                  className="rounded-lg p-1.5 text-slate-400 hover:bg-surface-overlay"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-4">
                {grupos
                  .filter((g) => g.mostrar !== false)
                  .map((g) => (
                    <div key={g.titulo} className="space-y-1">
                      <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 px-2">
                        {g.titulo}
                      </span>
                      {g.links.map((link) => {
                        const Icon = link.icon;
                        const active = link.exact
                          ? pathname === link.href
                          : pathname.startsWith(link.href);
                        return (
                          <Link
                            key={link.href}
                            href={link.href}
                            className={cn(
                              "flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium transition",
                              active
                                ? "bg-brand-600/15 text-brand-400 font-semibold"
                                : "text-slate-300 hover:bg-surface-overlay"
                            )}
                          >
                            <Icon className="h-4 w-4 shrink-0 text-slate-400" />
                            {link.label}
                          </Link>
                        );
                      })}
                    </div>
                  ))}
              </div>
            </div>

            <div className="border-t border-surface-border pt-4">
              <Link
                href="/perfil"
                className="flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium text-slate-300 hover:bg-surface-overlay mb-1"
              >
                <User className="h-4 w-4 text-slate-400" />
                Meu Perfil
              </Link>
              <button
                type="button"
                onClick={handleLogout}
                className="flex w-full items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium text-red-400 hover:bg-red-500/10"
              >
                <LogOut className="h-4 w-4" />
                Sair da Conta
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sidebar Desktop: Estilo Linear / Minimalista / Utilitário */}
      <aside className="hidden lg:flex lg:flex-col lg:w-64 lg:shrink-0 border-r border-surface-border bg-surface-raised h-screen">
        {/* Identidade da Escola no Topo */}
        <div className="flex flex-col gap-1 border-b border-surface-border px-5 py-5">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-white font-bold text-sm shadow-sm">
              LF
            </div>
            <div>
              <span className="block text-sm font-bold text-white tracking-tight">LabFlow</span>
              <span className="block text-[10px] text-slate-400 font-medium">Gestão SEDUC/SP</span>
            </div>
          </div>

          {profile?.escolas?.nome && (
            <div className="mt-3 flex items-center gap-1.5 rounded-lg border border-surface-border bg-surface-overlay/80 px-2.5 py-1.5 text-xs text-slate-300">
              <Building2 className="h-3.5 w-3.5 text-brand-400 shrink-0" />
              <span className="truncate font-medium">{profile.escolas.nome}</span>
            </div>
          )}
        </div>

        {/* Navegação por Grupos */}
        <nav className="flex-1 space-y-6 overflow-y-auto px-3 py-5">
          {grupos
            .filter((g) => g.mostrar !== false)
            .map((g) => (
              <div key={g.titulo} className="space-y-1">
                <span className="block text-[11px] font-semibold uppercase tracking-wider text-slate-500 px-3 mb-1">
                  {g.titulo}
                </span>

                {g.links.map((link) => {
                  const Icon = link.icon;
                  const active = link.exact
                    ? pathname === link.href
                    : pathname.startsWith(link.href);

                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      className={cn(
                        "flex items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-medium transition",
                        active
                          ? "bg-brand-600/15 text-brand-400 font-semibold"
                          : "text-slate-400 hover:bg-surface-overlay hover:text-slate-200"
                      )}
                    >
                      <Icon className={cn("h-4 w-4 shrink-0", active ? "text-brand-400" : "text-slate-500")} />
                      {link.label}
                    </Link>
                  );
                })}
              </div>
            ))}
        </nav>

        {/* Card do Usuário no Rodapé */}
        <div className="border-t border-surface-border p-3">
          <div className="flex items-center justify-between rounded-xl bg-surface-overlay/60 p-2.5 border border-surface-border/60">
            <Link
              href="/perfil"
              className="flex items-center gap-2.5 min-w-0 flex-1 hover:opacity-80 transition"
            >
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-slate-800 text-slate-200 font-semibold text-xs border border-slate-700">
                {(profile?.nome_completo || profile?.email || "U")[0].toUpperCase()}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-semibold text-white">
                  {profile?.nome_completo || profile?.email}
                </p>
                <p className="truncate text-[10px] text-slate-400 font-medium">
                  {profile?.role}
                </p>
              </div>
            </Link>

            <button
              type="button"
              onClick={handleLogout}
              title="Sair do sistema"
              className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
