export default function SectionHeader({ icon: Icon, children, className = "" }) {
  return (
    <div className={`mb-4 flex items-center gap-3 ${className}`}>
      <div className="panel-icon">
        <Icon className="h-5 w-5" />
      </div>
      <h2 className="text-lg font-semibold text-white">{children}</h2>
    </div>
  );
}
