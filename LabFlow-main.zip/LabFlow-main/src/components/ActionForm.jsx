"use client";

import { useEffect, useRef } from "react";
import { useFormState } from "react-dom";
import { useToast } from "./ToastProvider";

const initialState = { error: null, success: null };

/**
 * Substitui um <form action={minhaServerAction}> simples.
 * A Server Action passada em `action` precisa aceitar (prevState, formData)
 * e devolver { error: "..." } ou { success: "..." } (ou { success: true }
 * + a prop `successMessage` aqui como mensagem padrão).
 */
export default function ActionForm({
  action,
  successMessage,
  resetOnSuccess = false,
  className,
  children,
}) {
  const [state, formAction] = useFormState(action, initialState);
  const toast = useToast();
  const formRef = useRef(null);
  const lastHandled = useRef(null);

  useEffect(() => {
    if (state === initialState || state === lastHandled.current) return;
    lastHandled.current = state;

    if (state?.error) {
      toast.error(state.error);
    } else if (state?.success) {
      toast.success(typeof state.success === "string" ? state.success : successMessage || "Salvo com sucesso.");
      if (resetOnSuccess) formRef.current?.reset();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return (
    <form
      ref={formRef}
      action={formAction}
      className={className}
      autoComplete="off"
      data-lpignore="true"
    >
      {children}
    </form>
  );
}
