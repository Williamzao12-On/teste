"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import {
  CalendarDays,
  Laptop,
  LayoutDashboard,
  GraduationCap,
  ShieldCheck,
  User,
} from "lucide-react";

export default function BottomNav({ profile }) {
  const pathname = usePathname();

  const isAdmin = profile?.role === "ADMIN";
  const isGestor = profile?.role === "DIRETOR" || profile?.role === "GESTOR_ESCOLAR";

  // Itens da barra inferior configurados conforme o papel
  const items = [
    {
      href: "/reservas",
      label: "Reservas",
      icon: CalendarDays,
      show: true,
    },
    {
      href: isGestor || isAdmin ? "/gestor/recursos" : "/",
      label: "Recursos",
      icon: Laptop,
      show: true,
      activeMatch: (p) => p.startsWith("/gestor/recursos"),
    },
    {
      href: "/",
      label: "Início",
      icon: LayoutDashboard,
      show: true,
      exact: true,
    },
    {
      href: isAdmin ? "/admin" : "/gestor/turmas",
      label: isAdmin ? "Admin" : "Turmas",
      icon: isAdmin ? ShieldCheck : GraduationCap,
      show: isAdmin || isGestor,
      activeMatch: (p) => p.startsWith("/gestor/turmas") || p.startsWith("/admin"),
    },
    {
      href: "/perfil",
      label: "Perfil",
      icon: User,
      show: true,
      activeMatch: (p) => p.startsWith("/perfil"),
    },
  ].filter((i) => i.show);

  return (
    <nav
      aria-label="Navegação mobile"
      className="fixed bottom-0 inset-x-0 z-40 border-t border-surface-border bg-surface-raised/95 backdrop-blur-md pb-[max(0.5rem,env(safe-area-inset-bottom))] pt-1.5 px-2 lg:hidden"
    >
      <div className="flex items-center justify-around max-w-md mx-auto">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = item.exact
            ? pathname === item.href
            : item.activeMatch
            ? item.activeMatch(pathname)
            : pathname.startsWith(item.href);

          return (
            <Link
              key={item.href + item.label}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center flex-1 py-1.5 px-1 rounded-xl transition-all select-none active:scale-95",
                isActive
                  ? "text-brand-400 font-semibold"
                  : "text-slate-400 hover:text-slate-200"
              )}
            >
              <div
                className={cn(
                  "flex items-center justify-center h-7 w-11 rounded-full transition-all mb-0.5",
                  isActive && "bg-brand-500/15"
                )}
              >
                <Icon className={cn("h-5 w-5 transition-transform", isActive && "scale-110")} />
              </div>
              <span className="text-[10px] leading-tight tracking-tight">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
